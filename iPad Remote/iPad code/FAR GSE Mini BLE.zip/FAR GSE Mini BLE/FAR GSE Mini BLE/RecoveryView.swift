//
//  RecoveryView.swift
//  FAR Biprop Remote
//
//  Created by Brinker, Mike on 3/27/21.
//


import Foundation
import AVFoundation
import UIKit

class RecoveryView: UIViewController {
    
    
    
    
    
    @IBOutlet weak var labelSafetyPad: UILabel!
    @IBOutlet weak var labelSafetyLox: UILabel!
    @IBOutlet weak var labelSafetyFuel: UILabel!
    @IBOutlet weak var labelSafetyHelium: UILabel!
    @IBOutlet weak var labelOxSafety: UILabel!
    @IBOutlet weak var labelFuelSafety: UILabel!
    @IBOutlet weak var labelPressureSafety: UILabel!
    @IBOutlet weak var labelStatus: UILabel!
    @IBOutlet weak var imageArmedIcon: UIImageView!
    @IBOutlet weak var buttonOn: UIButton!
    @IBOutlet weak var buttonOff: UIButton!
    @IBOutlet weak var switchPower: UISwitch!
    @IBOutlet weak var imagePower: UIImageView!
    @IBOutlet weak var labelPower: UILabel!
    @IBOutlet weak var labelRocketConnect: UILabel!
    @IBOutlet weak var labelAltimeterBarmed: UILabel!
    @IBOutlet weak var labelAltimeterAarmed: UILabel!
    @IBOutlet weak var labelCounter: UILabel!
    @IBOutlet weak var labelCounterClock: UILabel!
    @IBOutlet weak var labelRadioTimer: UILabel!
    @IBOutlet weak var labelSafetyPRS: UILabel!
    @IBOutlet weak var labelSafetyPRSvalue: UILabel!
    @IBOutlet weak var buttonErrors: UIButton!
    @IBOutlet weak var imageNoSync: UIImageView!
    @IBOutlet weak var imageAltA: UIImageView!
    
    
    var player: AVAudioPlayer?
    var timerOne: Timer?
    var clockCountdown: Bool = false
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        labelStatus.text = ""
        //housekeeping timer
        timerOne = Timer.scheduledTimer(timeInterval: 0.25, target: self, selector: #selector(self.housekeepingTimer), userInfo: nil, repeats: true)
        refreshView()
        refreshData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(false)
        
        if(padConfig.recoveryArmA == 1) {
            imageAltA.image = UIImage(named: "proton-1")
        } else {
            imageAltA.image = UIImage(named: "telemega")
            labelAltimeterAarmed.text = "Check Telemega Remote"
        }
        refreshView()
        refreshData()

        
    }

    
    @objc func housekeepingTimer() {
        if(working.viewRecoveryRefreshData) {refreshData()}
        if(working.viewRecoveryRefreshScreen) {refreshView()}
        
        // clear status
        if(working.statusTimeout < Date() && labelStatus.text != "") {
             labelStatus.text = ""
         }
         //update status
        if(working.statusTimeout > Date()) {
             labelStatus.text = working.status
         }
        //countdown clock
        if(clockCountdown) {
            updateClock()
        }
        radioLast() // update radio last counter
        
        if(errors.errorCount > 0) {
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
    }

    //===================================  REFRESH HERE ================================================
    
    func radioLast() {
        
        if(working.firstContact) {
            let theDiff: Int = getDateDiff(start: working.radioLastClock, end: Date())
            labelRadioTimer.text = String(theDiff)
        } else {
            labelRadioTimer.text = String("N/A")
        }
    }
    func getDateDiff(start: Date, end: Date) -> Int  {
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([Calendar.Component.second], from: start, to: end)
        let seconds = dateComponents.second
        return Int(seconds!)
    }
    
    func refreshView() {
        labelOxSafety.text = configuration.oxTankName
        labelFuelSafety.text = configuration.fuelTankName
        labelPressureSafety.text = configuration.pressureTankName
        labelSafetyPRS.text = configuration.rspareTankName
        working.viewRecoveryRefreshScreen = false
    }
    
    func refreshData() {
        
        // ---------------- Standard Header
        if(padStatus.padHot) {
            labelSafetyPad.text = "HOT"
            labelSafetyPad.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        } else {
            labelSafetyPad.text = "SAFE"
            labelSafetyPad.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.padArmed) {
            imageArmedIcon.image = UIImage(named: "armed")
        } else {
            imageArmedIcon.image = UIImage(named: "disarm2")
        }
        if(errors.errorCount > 0) {
            buttonErrors.setTitle(" ", for: .normal)
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
        if(padConfig.updated == 1) {
            imageNoSync.isHidden = true
        } else {
            imageNoSync.isHidden = false
        }
        // ---------------- end standard header
        
        updatePressure()
        // Recovery Data
        if(padStatus.recoveryPower) {
            labelPower.text = "ON"
            imagePower.image = UIImage(named: "good")
            
            if(padConfig.recoveryArmA == 1) {
                if(padStatus.altimeterAarmed) {
                    labelAltimeterAarmed.text = "ARMED"
                    labelAltimeterAarmed.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
                } else {
                    labelAltimeterAarmed.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
                    if(working.recoveryStartup > Date()) { // just waking up
                        labelAltimeterAarmed.text = "WARMING UP"
                    } else {
                        labelAltimeterAarmed.text = "DISARMED"
                    }
                }
            } else {
                labelAltimeterAarmed.text = "Check Telemega Remote"
                labelAltimeterAarmed.textColor = UIColor(red: 0, green: 0, blue: 255/255, alpha: 1)
            }
            
            if(padConfig.recoveryArmB == 1) {
                if(padStatus.altimeterBarmed) {
                    labelAltimeterBarmed.text = "ARMED"
                    labelAltimeterBarmed.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
                } else {
                    labelAltimeterBarmed.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
                    if(working.recoveryStartup > Date()) { // just waking up
                        labelAltimeterBarmed.text = "WARMING UP"
                    } else {
                        labelAltimeterBarmed.text = "DISARMED"
                    }
                }
            } else {
                labelAltimeterBarmed.text = "ARM CHECK DISABLED"
                labelAltimeterBarmed.textColor = UIColor(red: 0, green: 0, blue: 255/255, alpha: 1)
            }
            
            if(!padStatus.altimeterAarmed || !padStatus.altimeterBarmed) {
                if(working.recoveryStartup > Date()) {
                    labelCounter.isHidden = false
                    labelCounterClock.isHidden = false
                    // countdown clock
                    updateClock()
                    clockCountdown = true
                } else {
                    labelCounter.isHidden = true
                    labelCounterClock.isHidden = true
                    clockCountdown = false
                }
            } else {
                labelCounter.isHidden = true
                labelCounterClock.isHidden = true
                clockCountdown = false
            }
         } else {
            labelPower.text = "OFF"
            imagePower.image = UIImage(named: "closed")
            labelAltimeterAarmed.text = "n/a"
            labelAltimeterBarmed.text = "n/a"
            labelAltimeterAarmed.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
            labelAltimeterBarmed.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
            labelCounter.isHidden = true
            labelCounterClock.isHidden = true
        }
        labelRocketConnect.text = connectDisconnect(theState: padStatus.rocketConnected)
        labelRocketConnect.textColor = redGreen(theState: padStatus.rocketConnected)
        
        working.viewRecoveryRefreshData = false
    }
    
    func updateClock() {
        let theDiff: Int = getDateDiff(start: Date(), end: working.recoveryStartup)
        let (h,m,s) = secondsToHoursMinutesSeconds(seconds: theDiff)
        var displayClock: String = ""
        if(m == 0) {
            displayClock = "0:"
        } else {
            displayClock = "\(String(format: "%01d", m))" + ":"
        }
        displayClock = displayClock + "\(String(format: "%02d", s))"
        labelCounterClock.text = displayClock
    }
    
    func updatePressure() {
        
        // =====================================   Standard header
        if(padConfig.POXenabled == 1){
            labelSafetyLox.isHidden = false
            labelOxSafety.isHidden = false
        } else {
            labelSafetyLox.isHidden = true
            labelOxSafety.isHidden = true
        }
        if(padStatus.pressureOne == 99999) {
            labelSafetyLox.text = String("ERR")
        } else {
            labelSafetyLox.text = String(padStatus.pressureOne)
        }
        if(padStatus.pressureOne > padConfig.POXalarm || padStatus.pressureOne == 99999) {
            labelSafetyLox.textColor = .red
        } else {
            labelSafetyLox.textColor = .black
        }
        //-----
        if(padConfig.PFLenabled == 1){
            labelSafetyFuel.isHidden = false
            labelFuelSafety.isHidden = false
        } else {
            labelSafetyFuel.isHidden = true
            labelFuelSafety.isHidden = true
        }
        if(padStatus.pressureTwo == 99999) {
            labelSafetyFuel.text = String("ERR")
        } else {
            labelSafetyFuel.text = String(padStatus.pressureTwo)
        }
        if(padStatus.pressureTwo > padConfig.PFLalarm || padStatus.pressureTwo == 99999) {
            labelSafetyFuel.textColor = .red
        } else {
            labelSafetyFuel.textColor = .black
        }
        //------
        if(padConfig.PPSenabled == 1){
            labelSafetyHelium.isHidden = false
            labelPressureSafety.isHidden = false
        } else {
            labelSafetyHelium.isHidden = true
            labelPressureSafety.isHidden = true
        }
        if(padStatus.pressureThree == 99999) {
            labelSafetyHelium.text = String("ERR")
        } else {
            labelSafetyHelium.text = String(padStatus.pressureThree)
        }
        if(padStatus.pressureThree > padConfig.PPSalarm || padStatus.pressureThree == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        if(padConfig.PRSenabled == 1){
            labelSafetyPRS.isHidden = false
            labelSafetyPRSvalue.isHidden = false
        } else {
            labelSafetyPRS.isHidden = true
            labelSafetyPRSvalue.isHidden = true
        }
        if(padStatus.pressureFour == 99999) {
            labelSafetyPRSvalue.text = String("ERR")
        } else {
            labelSafetyPRSvalue.text = String(padStatus.pressureFour)
        }
        if(padStatus.pressureFour > padConfig.PRSalarm || padStatus.pressureFour == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        
        //====== END HEADER
    }

   
    
    func greenRed(theState: Bool) -> UIColor {  // 1 red, 0 green
        if(theState) {
           return UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        } else {
            return UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
    }
    func redGreen(theState: Bool) -> UIColor {  // 0 red, 1 green
        if(theState) {
            return UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        } else {
            return UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        }
    }
    func noYes(theState: Bool) -> String {
        if(theState) {
           return "yes"
        } else {
            return "no"
        }
    }
    
    func connectDisconnect(theState: Bool) -> String {
        if(theState) {
           return "connected"
        } else {
            return "disconnected"
        }
    }
    
    
    @IBAction func buttonPowerOnAction(_ sender: Any) {
        if(switchPower.isOn) {
            working.radioMessage = "#RON,33,!"
            working.radioSend = true
            working.status = "Sent Recovery On Request..."
            labelPower.text = "Pending"
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            switchPower.isOn = false
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonPowerOffAction(_ sender: Any) {
        
        if(switchPower.isOn) {
            working.radioMessage = "#ROFF,33,!"
            working.radioSend = true
            working.status = "Sent Recovery Off Request..."
            labelPower.text = "Pending"
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            switchPower.isOn = false
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonErrorsAction(_ sender: Any) {
        tabBarController?.selectedIndex = 5
    }
    
    
    @IBAction func buttonStatus(_ sender: Any) {
        working.radioMessage = "#S,033,!"
        working.radioSend = true
        working.status = "Sent Status Request..."
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
    }
    
    func denySend() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "You must unlock the safety before sending the request", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    

    func secondsToHoursMinutesSeconds (seconds : Int) -> (Int, Int, Int) {
      return (seconds / 3600, (seconds % 3600) / 60, (seconds % 3600) % 60)
    }
    
}


