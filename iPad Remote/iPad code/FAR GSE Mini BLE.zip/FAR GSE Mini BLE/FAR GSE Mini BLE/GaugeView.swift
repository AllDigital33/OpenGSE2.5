//
//  GaugeView.swift
//  FAR Biprop Remote
//
//  Created by Brinker, Mike on 3/27/21.
//
import UIKit
import Foundation



class gaugeSubView1: UIView {
    
    var gaugeMax: Int = padConfig.POXrange {
        didSet {
            print("Gauge Changed")
            setUp()
        }
    }
    var gaugeAlarm: Int = padConfig.POXalarm
    var theMajors: Int = padConfig.POXrange / 100
    var theIncrement: Int = 100
    
    var gaugeName: String = "" {
        didSet {
            
        }
    }
    
    let nameLabel = UILabel()
    var outerBezelColor = UIColor(red: 0, green: 0.5, blue: 1, alpha: 1)
    var outerBezelWidth: CGFloat = 10

    var innerBezelColor = UIColor.white
    var innerBezelWidth: CGFloat = 5

    var insideColor = UIColor.white
    
    var segmentWidth: CGFloat = 10
    var theGreen = UIColor(red: 27/255, green: 244/255, blue: 5/255, alpha: 1)
    var theRed = UIColor(red: 196/255, green: 0/255, blue: 12/255, alpha: 1)
    var theYellow = UIColor(red: 255/255, green: 253/255, blue: 0/255, alpha: 1)
    //var segmentColors = [UIColor(red: 0.7, green: 0, blue: 0, alpha: 1), UIColor(red: 0, green: 0.5, blue: 0, alpha: 1), UIColor(red: 0, green: 0.5, blue: 0, alpha: 1), UIColor(red: 0, green: 0.5, blue: 0, alpha: 1), UIColor(red: 0.7, green: 0, blue: 0, alpha: 1)]
    //var segmentColors = [UIColor(red: 0, green: 0.5, blue: 0, alpha: 1), UIColor(red: 0.7, green: 0, blue: 0, alpha: 1)]
    var segmentColors = [UIColor]()
    
    
    var totalAngle: CGFloat = 270
    var rotation: CGFloat = -135
    
    var majorTickColor = UIColor.black
    var majorTickWidth: CGFloat = 2
    var majorTickLength: CGFloat = 25

    var minorTickColor = UIColor.black.withAlphaComponent(0.5)
    var minorTickWidth: CGFloat = 1
    var minorTickLength: CGFloat = 20
    var minorTickCount = 3
    
    var outerCenterDiscColor = UIColor(white: 0.9, alpha: 1)
    var outerCenterDiscWidth: CGFloat = 35
    var innerCenterDiscColor1 = UIColor(red: 10/255, green: 96/255, blue: 255/255, alpha: 1)
    var innerCenterDiscColor2 = UIColor(red: 255, green: 0, blue: 0, alpha: 1)
    var innerCenterDiscColor = UIColor(red: 10/255, green: 96/255, blue: 255/255, alpha: 1)
    var innerCenterDiscWidth: CGFloat = 25
    
    var needleColor = UIColor(red: 10/255, green: 96/255, blue: 255/255, alpha: 1)
    var needleWidth: CGFloat = 4
    let needle = UIView()
    
    let needleDisc = UIView()
    
    let valueLabel = UILabel()
    var valueFont = UIFont.systemFont(ofSize: 35, weight: .bold)
    var valueColor = UIColor.black
    
    
    
    var value: Int = 0 {
        didSet {
            
            // update the value label to show the exact number
            if(value == 99999) {
                valueLabel.text = "ERR"
            } else {
                valueLabel.text = String(value)
            }

            // figure out where the needle is, between 0 and 1
            var tempValue = Int(Float(Float(value)/Float(gaugeMax)) * 100)
            if(tempValue > 100) {tempValue = 105}
            if(tempValue < 0) {tempValue = 0}
            let needlePosition = CGFloat(tempValue) / 100

            // create a lerp from the start angle (rotation) through to the end angle (rotation + totalAngle)
            let lerpFrom = rotation
            let lerpTo = rotation + totalAngle
            
            if(value > gaugeAlarm) {
                needle.backgroundColor = UIColor(red: 255, green: 0, blue: 0, alpha: 1)
                nameLabel.textColor = UIColor(red: 255, green: 0, blue: 0, alpha: 1)
                innerCenterDiscColor = innerCenterDiscColor2
                setNeedsDisplay()
            } else {
                needle.backgroundColor = needleColor
                nameLabel.textColor = .black
                innerCenterDiscColor = innerCenterDiscColor1
                setNeedsDisplay()
            }

            // lerp from the start to the end position, based on the needle's position
            let needleRotation = lerpFrom + (lerpTo - lerpFrom) * needlePosition
            needle.transform = CGAffineTransform(rotationAngle: deg2rad(needleRotation))
        }
    }
    
    override func draw(_ rect: CGRect) {
        
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        //drawBackground(in: rect, context: ctx)
        drawSegments(in: rect, context: ctx)
        drawTicks(in: rect, context: ctx)
        drawCenterDisc(in: rect, context: ctx)
        
    }
    
    
    
    func drawBackground(in rect: CGRect, context ctx: CGContext) {
        // draw the outer bezel as the largest circle
        outerBezelColor.set()
        ctx.fillEllipse(in: rect)

        // move in a little on each edge, then draw the inner bezel
        let innerBezelRect = rect.insetBy(dx: outerBezelWidth, dy: outerBezelWidth)
        innerBezelColor.set()
        ctx.fillEllipse(in: innerBezelRect)

        // finally, move in some more and draw the inside of our gauge
        let insideRect = innerBezelRect.insetBy(dx: innerBezelWidth, dy: innerBezelWidth)
        insideColor.set()
        ctx.fillEllipse(in: insideRect)
    }
    

    
    func deg2rad(_ number: CGFloat) -> CGFloat {
        return number * .pi / 180
    }
    
    func drawSegments(in rect: CGRect, context ctx: CGContext) {
        // 1: Save the current drawing configuration
        ctx.saveGState()

        // 2: Move to the center of our drawing rectangle and rotate so that we're pointing at the start of the first segment
        ctx.translateBy(x: rect.midX, y: rect.midY)
        ctx.rotate(by: deg2rad(rotation) - (.pi / 2))

        // 3: Set up the user's line width
        ctx.setLineWidth(segmentWidth)

        // 4: Calculate the size of each segment in the total gauge
        //let segmentAngle = deg2rad(totalAngle / CGFloat(segmentColors.count))
        let segmentAngle = deg2rad(totalAngle / 100.0)

        // 5: Calculate how wide the segment arcs should be
        let segmentRadius = (((rect.width - segmentWidth) / 2) - outerBezelWidth) - innerBezelWidth

        // 6: Draw each segment
        //for (index, segment) in segmentColors.enumerated() {
          for index in 1...100 {
            // figure out where the segment starts in our arc
            let start = CGFloat(index) * segmentAngle

            // activate its color
            //segment.set()
            if (index <= Int((Float(Float(configuration.minSafePressure) / Float(gaugeMax)) * Float(100)))) {
                ctx.setStrokeColor(theGreen.cgColor)
            }
            if (index > Int((Float(Float(configuration.minSafePressure) / Float(gaugeMax)) * Float(100))) && index <= Int((Float(Float(gaugeAlarm) / Float(gaugeMax)) * Float(100)))) {
                ctx.setStrokeColor(theYellow.cgColor)
            }
            if (index > Int((Float(Float(gaugeAlarm) / Float(gaugeMax)) * Float(100)))) {
                ctx.setStrokeColor(theRed.cgColor)
            }
            

            // add a path for the segment
            ctx.addArc(center: .zero, radius: segmentRadius, startAngle: start, endAngle: start + segmentAngle, clockwise: false)

            // and stroke it using the activated color
            ctx.drawPath(using: .stroke)
        }

        // 7: Reset the graphics state
        ctx.restoreGState()
    }
    
    func drawTicks(in rect: CGRect, context ctx: CGContext) {
        // save our clean graphics state
        ctx.saveGState()
        ctx.translateBy(x: rect.midX, y: rect.midY)
        ctx.rotate(by: deg2rad(rotation) - (.pi / 2))

        //let segmentAngle = deg2rad(totalAngle / CGFloat(segmentColors.count))
        let segmentAngle = deg2rad(totalAngle / CGFloat(theMajors))

        let segmentRadius = (((rect.width - segmentWidth) / 2) - outerBezelWidth) - innerBezelWidth

        // save the graphics state where we've moved to the center and rotated towards the start of the first segment
        ctx.saveGState()

        // draw major ticks
        ctx.setLineWidth(majorTickWidth)
        majorTickColor.set()
        
        let majorEnd = segmentRadius + (segmentWidth / 2)
        let majorStart = majorEnd - majorTickLength
        
        //for _ in 0 ... segmentColors.count {
        for _ in 0 ... theMajors {
            ctx.move(to: CGPoint(x: majorStart, y: 0))
            ctx.addLine(to: CGPoint(x: majorEnd, y: 0))
            ctx.drawPath(using: .stroke)
            ctx.rotate(by: segmentAngle)
        }
        


        // go back to the state we had before we drew the major ticks
        ctx.restoreGState()

        // save it again, because we're about to draw the minor ticks
        ctx.saveGState()

        // draw minor ticks
        ctx.setLineWidth(minorTickWidth)
        minorTickColor.set()

        let minorEnd = segmentRadius + (segmentWidth / 2)
        let minorStart = minorEnd - minorTickLength
        let minorTickSize = segmentAngle / CGFloat(minorTickCount + 1)
        
        //for _ in 0 ..< segmentColors.count {
        for _ in 0 ..< theMajors {
            ctx.rotate(by: minorTickSize)

            for _ in 0 ..< minorTickCount {
                ctx.move(to: CGPoint(x: minorStart, y: 0))
                ctx.addLine(to: CGPoint(x: minorEnd, y: 0))
                ctx.drawPath(using: .stroke)
                ctx.rotate(by: minorTickSize)
            }
        }
        
        
        // go back to the graphics state where we've moved to the center and rotated towards the start of the first segment
        ctx.restoreGState()

        // go back to the original graphics state
        ctx.restoreGState()
    }
    
    func drawCenterDisc(in rect: CGRect, context ctx: CGContext) {
        ctx.saveGState()
        ctx.translateBy(x: rect.midX, y: rect.midY)

        let outerCenterRect = CGRect(x: -outerCenterDiscWidth / 2, y: -outerCenterDiscWidth / 2, width: outerCenterDiscWidth, height: outerCenterDiscWidth)
        outerCenterDiscColor.set()
        ctx.fillEllipse(in: outerCenterRect)

        let innerCenterRect = CGRect(x: -innerCenterDiscWidth / 2, y: -innerCenterDiscWidth / 2, width: innerCenterDiscWidth, height: innerCenterDiscWidth)
        innerCenterDiscColor.set()
        ctx.fillEllipse(in: innerCenterRect)
        ctx.restoreGState()
    }
    
    
    func drawSegmentValues() {
        
        // Dynamically draw the value labels around the outside of the circle on the major ticks. Thank you cGPT :)
        
        print("Segments")
        var theX = [Int]()
        var theY = [Int]()
        theX.removeAll()
        theY.removeAll()
        theMajors = padConfig.POXrange / 100
        if (theMajors <= 10) {
            theIncrement = 100
        }
        if (theMajors > 10 && theMajors <= 20) {
            theMajors = Int(theMajors / 2)
            theIncrement = 200
        }
        if (theMajors > 20) {
            theMajors = Int(theMajors / 3)
            theIncrement = 300
        }
        
        let numberOfFields = theMajors + 1
        let circleCenter = CGPoint(x: 109, y: 105)
        let circleRadius: CGFloat = 68
        let startAngle: CGFloat = 2.16 //2.094  Radians!
        let angleRange: CGFloat = 5.06

        let textPositions = calculateTextPositions(numberOfFields: numberOfFields, circleCenter: circleCenter, circleRadius: circleRadius, startAngle: startAngle, angleRange: angleRange)
        
        
        var theCount = 0
        for index in 0 ..< (theMajors + 1) {
            //let tLabel = UILabel(frame: CGRect(x: theX[index], y: theY[index], width: 40, height: 25))
            let tLabel = UILabel(frame: textPositions[index])
            tLabel.font = UIFont.systemFont(ofSize: 18)
            tLabel.textColor = UIColor.black
            tLabel.text = String(theCount)
            addSubview(tLabel)
            theCount += theIncrement
        }

        
        let lPSI = UILabel(frame: CGRect(x: 112, y: 80, width: 40, height: 25))
        lPSI.font = UIFont.systemFont(ofSize: 18)
        lPSI.textColor = UIColor.black
        lPSI.text = "psi"
        addSubview(lPSI)
        
    }
    
    func eraseAll() {
            layer.contents = nil
           for subview in subviews {
                subview.removeFromSuperview()
            }
        }
    
    
    func calculateTextPositions(numberOfFields: Int, circleCenter: CGPoint, circleRadius: CGFloat, startAngle: CGFloat, angleRange: CGFloat) -> [CGRect] {
        var textPositions: [CGRect] = []
        let angleIncrement = angleRange / CGFloat(numberOfFields - 1)
        
        for i in 0..<numberOfFields {
            let angle = startAngle + CGFloat(i) * angleIncrement
            let x = circleCenter.x + cos(angle) * circleRadius
            let y = circleCenter.y + sin(angle) * circleRadius
            let position = CGRect(x: x, y: y, width: 60, height: 25)
            textPositions.append(position)
        }
        
        return textPositions
    }
    
    
    func setNameLabel() {
        // setup the name of the Gauge
        nameLabel.text = gaugeName
        

    }
    
    func setUp() {
        print("setup")
        segmentColors = [theGreen, theGreen, theGreen, theGreen, theRed]
        
        needle.backgroundColor = needleColor
        needle.translatesAutoresizingMaskIntoConstraints = false

        // make the needle a third of our height
        needle.bounds = CGRect(x: 0, y: 0, width: needleWidth, height: bounds.height / 3)

        // align it so that it is positioned and rotated from the bottom center
        needle.layer.anchorPoint = CGPoint(x: 0.5, y: 1)

        // now center the needle over our center point
        needle.center = CGPoint(x: bounds.midX, y: bounds.midY)
        addSubview(needle)
        
        // this is the value label setup
        
        valueLabel.font = valueFont
        valueLabel.text = "0"
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(valueLabel)

        NSLayoutConstraint.activate([
            valueLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            valueLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -75)
        ])
        
        // set name label
        
        nameLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        nameLabel.text = gaugeName
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(nameLabel)

        NSLayoutConstraint.activate([
            nameLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            nameLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -28)
        ])
        
        drawSegmentValues()
        
        value = 220
        
        
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUp()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setUp()
    }
    
 
    
    
    
}


//============================================================================   Gauge View 2 ====================================================================================

class gaugeSubView2: UIView {
    
    var gaugeMax: Int = padConfig.PFLrange {
        didSet {
            print("Gauge Changed")
            setUp()
        }
    }
    var gaugeAlarm: Int = padConfig.PFLalarm
    var theMajors: Int = padConfig.PFLrange / 100
    var theIncrement: Int = 100
    
    var gaugeName: String = "" {
        didSet {
            
        }
    }
    
    let nameLabel = UILabel()
    var outerBezelColor = UIColor(red: 0, green: 0.5, blue: 1, alpha: 1)
    var outerBezelWidth: CGFloat = 10

    var innerBezelColor = UIColor.white
    var innerBezelWidth: CGFloat = 5

    var insideColor = UIColor.white
    
    var segmentWidth: CGFloat = 10
    var theGreen = UIColor(red: 27/255, green: 244/255, blue: 5/255, alpha: 1)
    var theRed = UIColor(red: 196/255, green: 0/255, blue: 12/255, alpha: 1)
    var theYellow = UIColor(red: 255/255, green: 253/255, blue: 0/255, alpha: 1)
    //var segmentColors = [UIColor(red: 0.7, green: 0, blue: 0, alpha: 1), UIColor(red: 0, green: 0.5, blue: 0, alpha: 1), UIColor(red: 0, green: 0.5, blue: 0, alpha: 1), UIColor(red: 0, green: 0.5, blue: 0, alpha: 1), UIColor(red: 0.7, green: 0, blue: 0, alpha: 1)]
    //var segmentColors = [UIColor(red: 0, green: 0.5, blue: 0, alpha: 1), UIColor(red: 0.7, green: 0, blue: 0, alpha: 1)]
    var segmentColors = [UIColor]()
    
    
    var totalAngle: CGFloat = 270
    var rotation: CGFloat = -135
    
    var majorTickColor = UIColor.black
    var majorTickWidth: CGFloat = 2
    var majorTickLength: CGFloat = 25

    var minorTickColor = UIColor.black.withAlphaComponent(0.5)
    var minorTickWidth: CGFloat = 1
    var minorTickLength: CGFloat = 20
    var minorTickCount = 3
    
    var outerCenterDiscColor = UIColor(white: 0.9, alpha: 1)
    var outerCenterDiscWidth: CGFloat = 35
    var innerCenterDiscColor1 = UIColor(red: 10/255, green: 96/255, blue: 255/255, alpha: 1)
    var innerCenterDiscColor2 = UIColor(red: 255, green: 0, blue: 0, alpha: 1)
    var innerCenterDiscColor = UIColor(red: 10/255, green: 96/255, blue: 255/255, alpha: 1)
    var innerCenterDiscWidth: CGFloat = 25
    
    var needleColor = UIColor(red: 10/255, green: 96/255, blue: 255/255, alpha: 1)
    var needleWidth: CGFloat = 4
    let needle = UIView()
    
    let needleDisc = UIView()
    
    let valueLabel = UILabel()
    var valueFont = UIFont.systemFont(ofSize: 35, weight: .bold)
    var valueColor = UIColor.black
    
    
    
    var value: Int = 0 {
        didSet {
            
            // update the value label to show the exact number
            if(value == 99999) {
                valueLabel.text = "ERR"
            } else {
                valueLabel.text = String(value)
            }

            // figure out where the needle is, between 0 and 1
            var tempValue = Int(Float(Float(value)/Float(gaugeMax)) * 100)
            if(tempValue > 100) {tempValue = 105}
            if(tempValue < 0) {tempValue = 0}
            let needlePosition = CGFloat(tempValue) / 100

            // create a lerp from the start angle (rotation) through to the end angle (rotation + totalAngle)
            let lerpFrom = rotation
            let lerpTo = rotation + totalAngle
            
            if(value > gaugeAlarm) {
                needle.backgroundColor = UIColor(red: 255, green: 0, blue: 0, alpha: 1)
                nameLabel.textColor = UIColor(red: 255, green: 0, blue: 0, alpha: 1)
                innerCenterDiscColor = innerCenterDiscColor2
                setNeedsDisplay()
            } else {
                needle.backgroundColor = needleColor
                nameLabel.textColor = .black
                innerCenterDiscColor = innerCenterDiscColor1
                setNeedsDisplay()
            }

            // lerp from the start to the end position, based on the needle's position
            let needleRotation = lerpFrom + (lerpTo - lerpFrom) * needlePosition
            needle.transform = CGAffineTransform(rotationAngle: deg2rad(needleRotation))
        }
    }
    
    override func draw(_ rect: CGRect) {
        
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        //drawBackground(in: rect, context: ctx)
        drawSegments(in: rect, context: ctx)
        drawTicks(in: rect, context: ctx)
        drawCenterDisc(in: rect, context: ctx)
        
    }
    
    
    
    func drawBackground(in rect: CGRect, context ctx: CGContext) {
        // draw the outer bezel as the largest circle
        outerBezelColor.set()
        ctx.fillEllipse(in: rect)

        // move in a little on each edge, then draw the inner bezel
        let innerBezelRect = rect.insetBy(dx: outerBezelWidth, dy: outerBezelWidth)
        innerBezelColor.set()
        ctx.fillEllipse(in: innerBezelRect)

        // finally, move in some more and draw the inside of our gauge
        let insideRect = innerBezelRect.insetBy(dx: innerBezelWidth, dy: innerBezelWidth)
        insideColor.set()
        ctx.fillEllipse(in: insideRect)
    }
    

    
    func deg2rad(_ number: CGFloat) -> CGFloat {
        return number * .pi / 180
    }
    
    func drawSegments(in rect: CGRect, context ctx: CGContext) {
        // 1: Save the current drawing configuration
        ctx.saveGState()

        // 2: Move to the center of our drawing rectangle and rotate so that we're pointing at the start of the first segment
        ctx.translateBy(x: rect.midX, y: rect.midY)
        ctx.rotate(by: deg2rad(rotation) - (.pi / 2))

        // 3: Set up the user's line width
        ctx.setLineWidth(segmentWidth)

        // 4: Calculate the size of each segment in the total gauge
        //let segmentAngle = deg2rad(totalAngle / CGFloat(segmentColors.count))
        let segmentAngle = deg2rad(totalAngle / 100.0)

        // 5: Calculate how wide the segment arcs should be
        let segmentRadius = (((rect.width - segmentWidth) / 2) - outerBezelWidth) - innerBezelWidth

        // 6: Draw each segment
        //for (index, segment) in segmentColors.enumerated() {
          for index in 1...100 {
            // figure out where the segment starts in our arc
            let start = CGFloat(index) * segmentAngle

            // activate its color
            //segment.set()
            if (index <= Int((Float(Float(configuration.minSafePressure) / Float(gaugeMax)) * Float(100)))) {
                ctx.setStrokeColor(theGreen.cgColor)
            }
            if (index > Int((Float(Float(configuration.minSafePressure) / Float(gaugeMax)) * Float(100))) && index <= Int((Float(Float(gaugeAlarm) / Float(gaugeMax)) * Float(100)))) {
                ctx.setStrokeColor(theYellow.cgColor)
            }
            if (index > Int((Float(Float(gaugeAlarm) / Float(gaugeMax)) * Float(100)))) {
                ctx.setStrokeColor(theRed.cgColor)
            }
            

            // add a path for the segment
            ctx.addArc(center: .zero, radius: segmentRadius, startAngle: start, endAngle: start + segmentAngle, clockwise: false)

            // and stroke it using the activated color
            ctx.drawPath(using: .stroke)
        }

        // 7: Reset the graphics state
        ctx.restoreGState()
    }
    
    func drawTicks(in rect: CGRect, context ctx: CGContext) {
        // save our clean graphics state
        ctx.saveGState()
        ctx.translateBy(x: rect.midX, y: rect.midY)
        ctx.rotate(by: deg2rad(rotation) - (.pi / 2))

        //let segmentAngle = deg2rad(totalAngle / CGFloat(segmentColors.count))
        let segmentAngle = deg2rad(totalAngle / CGFloat(theMajors))

        let segmentRadius = (((rect.width - segmentWidth) / 2) - outerBezelWidth) - innerBezelWidth

        // save the graphics state where we've moved to the center and rotated towards the start of the first segment
        ctx.saveGState()

        // draw major ticks
        ctx.setLineWidth(majorTickWidth)
        majorTickColor.set()
        
        let majorEnd = segmentRadius + (segmentWidth / 2)
        let majorStart = majorEnd - majorTickLength
        
        //for _ in 0 ... segmentColors.count {
        for _ in 0 ... theMajors {
            ctx.move(to: CGPoint(x: majorStart, y: 0))
            ctx.addLine(to: CGPoint(x: majorEnd, y: 0))
            ctx.drawPath(using: .stroke)
            ctx.rotate(by: segmentAngle)
        }
        


        // go back to the state we had before we drew the major ticks
        ctx.restoreGState()

        // save it again, because we're about to draw the minor ticks
        ctx.saveGState()

        // draw minor ticks
        ctx.setLineWidth(minorTickWidth)
        minorTickColor.set()

        let minorEnd = segmentRadius + (segmentWidth / 2)
        let minorStart = minorEnd - minorTickLength
        let minorTickSize = segmentAngle / CGFloat(minorTickCount + 1)
        
        //for _ in 0 ..< segmentColors.count {
        for _ in 0 ..< theMajors {
            ctx.rotate(by: minorTickSize)

            for _ in 0 ..< minorTickCount {
                ctx.move(to: CGPoint(x: minorStart, y: 0))
                ctx.addLine(to: CGPoint(x: minorEnd, y: 0))
                ctx.drawPath(using: .stroke)
                ctx.rotate(by: minorTickSize)
            }
        }
        
        
        // go back to the graphics state where we've moved to the center and rotated towards the start of the first segment
        ctx.restoreGState()

        // go back to the original graphics state
        ctx.restoreGState()
    }
    
    func drawCenterDisc(in rect: CGRect, context ctx: CGContext) {
        ctx.saveGState()
        ctx.translateBy(x: rect.midX, y: rect.midY)

        let outerCenterRect = CGRect(x: -outerCenterDiscWidth / 2, y: -outerCenterDiscWidth / 2, width: outerCenterDiscWidth, height: outerCenterDiscWidth)
        outerCenterDiscColor.set()
        ctx.fillEllipse(in: outerCenterRect)

        let innerCenterRect = CGRect(x: -innerCenterDiscWidth / 2, y: -innerCenterDiscWidth / 2, width: innerCenterDiscWidth, height: innerCenterDiscWidth)
        innerCenterDiscColor.set()
        ctx.fillEllipse(in: innerCenterRect)
        ctx.restoreGState()
    }
    
    
    func drawSegmentValues() {
        
        // Dynamically draw the value labels around the outside of the circle on the major ticks. Thank you cGPT :)
        
        print("Segments")
        var theX = [Int]()
        var theY = [Int]()
        theX.removeAll()
        theY.removeAll()
        theMajors = padConfig.PFLrange / 100
        if (theMajors <= 10) {
            theIncrement = 100
        }
        if (theMajors > 10 && theMajors <= 20) {
            theMajors = Int(theMajors / 2)
            theIncrement = 200
        }
        if (theMajors > 20) {
            theMajors = Int(theMajors / 3)
            theIncrement = 300
        }
        
        let numberOfFields = theMajors + 1
        let circleCenter = CGPoint(x: 109, y: 105)
        let circleRadius: CGFloat = 68
        let startAngle: CGFloat = 2.16 //2.094  Radians!
        let angleRange: CGFloat = 5.06

        let textPositions = calculateTextPositions(numberOfFields: numberOfFields, circleCenter: circleCenter, circleRadius: circleRadius, startAngle: startAngle, angleRange: angleRange)
        
        
        var theCount = 0
        for index in 0 ..< (theMajors + 1) {
            //let tLabel = UILabel(frame: CGRect(x: theX[index], y: theY[index], width: 40, height: 25))
            let tLabel = UILabel(frame: textPositions[index])
            tLabel.font = UIFont.systemFont(ofSize: 18)
            tLabel.textColor = UIColor.black
            tLabel.text = String(theCount)
            addSubview(tLabel)
            theCount += theIncrement
        }

        
        let lPSI = UILabel(frame: CGRect(x: 112, y: 80, width: 40, height: 25))
        lPSI.font = UIFont.systemFont(ofSize: 18)
        lPSI.textColor = UIColor.black
        lPSI.text = "psi"
        addSubview(lPSI)
        
    }
    
    func eraseAll() {
            layer.contents = nil
           for subview in subviews {
                subview.removeFromSuperview()
            }
        }
    
    
    func calculateTextPositions(numberOfFields: Int, circleCenter: CGPoint, circleRadius: CGFloat, startAngle: CGFloat, angleRange: CGFloat) -> [CGRect] {
        var textPositions: [CGRect] = []
        let angleIncrement = angleRange / CGFloat(numberOfFields - 1)
        
        for i in 0..<numberOfFields {
            let angle = startAngle + CGFloat(i) * angleIncrement
            let x = circleCenter.x + cos(angle) * circleRadius
            let y = circleCenter.y + sin(angle) * circleRadius
            let position = CGRect(x: x, y: y, width: 60, height: 25)
            textPositions.append(position)
        }
        
        return textPositions
    }
    
    
    func setNameLabel() {
        // setup the name of the Gauge
        nameLabel.text = gaugeName
        

    }
    
    func setUp() {
        print("setup")
        segmentColors = [theGreen, theGreen, theGreen, theGreen, theRed]
        
        needle.backgroundColor = needleColor
        needle.translatesAutoresizingMaskIntoConstraints = false

        // make the needle a third of our height
        needle.bounds = CGRect(x: 0, y: 0, width: needleWidth, height: bounds.height / 3)

        // align it so that it is positioned and rotated from the bottom center
        needle.layer.anchorPoint = CGPoint(x: 0.5, y: 1)

        // now center the needle over our center point
        needle.center = CGPoint(x: bounds.midX, y: bounds.midY)
        addSubview(needle)
        
        // this is the value label setup
        
        valueLabel.font = valueFont
        valueLabel.text = "0"
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(valueLabel)

        NSLayoutConstraint.activate([
            valueLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            valueLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -75)
        ])
        
        // set name label
        
        nameLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        nameLabel.text = gaugeName
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(nameLabel)

        NSLayoutConstraint.activate([
            nameLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            nameLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -28)
        ])
        
        drawSegmentValues()
        
        value = 220
        
        
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUp()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setUp()
    }
    
 
    
    
    
}


//============================================================================   Gauge View 3 ====================================================================================

class gaugeSubView3: UIView {
    
    var gaugeMax: Int = padConfig.PPSrange {
        didSet {
            print("Gauge Changed")
            setUp()
        }
    }
    var gaugeAlarm: Int = padConfig.PPSalarm
    var theMajors: Int = padConfig.PPSrange / 100
    var theIncrement: Int = 100
    
    var gaugeName: String = "" {
        didSet {
            
        }
    }
    
    let nameLabel = UILabel()
    var outerBezelColor = UIColor(red: 0, green: 0.5, blue: 1, alpha: 1)
    var outerBezelWidth: CGFloat = 10

    var innerBezelColor = UIColor.white
    var innerBezelWidth: CGFloat = 5

    var insideColor = UIColor.white
    
    var segmentWidth: CGFloat = 10
    var theGreen = UIColor(red: 27/255, green: 244/255, blue: 5/255, alpha: 1)
    var theRed = UIColor(red: 196/255, green: 0/255, blue: 12/255, alpha: 1)
    var theYellow = UIColor(red: 255/255, green: 253/255, blue: 0/255, alpha: 1)
    //var segmentColors = [UIColor(red: 0.7, green: 0, blue: 0, alpha: 1), UIColor(red: 0, green: 0.5, blue: 0, alpha: 1), UIColor(red: 0, green: 0.5, blue: 0, alpha: 1), UIColor(red: 0, green: 0.5, blue: 0, alpha: 1), UIColor(red: 0.7, green: 0, blue: 0, alpha: 1)]
    //var segmentColors = [UIColor(red: 0, green: 0.5, blue: 0, alpha: 1), UIColor(red: 0.7, green: 0, blue: 0, alpha: 1)]
    var segmentColors = [UIColor]()
    
    
    var totalAngle: CGFloat = 270
    var rotation: CGFloat = -135
    
    var majorTickColor = UIColor.black
    var majorTickWidth: CGFloat = 2
    var majorTickLength: CGFloat = 25

    var minorTickColor = UIColor.black.withAlphaComponent(0.5)
    var minorTickWidth: CGFloat = 1
    var minorTickLength: CGFloat = 20
    var minorTickCount = 3
    
    var outerCenterDiscColor = UIColor(white: 0.9, alpha: 1)
    var outerCenterDiscWidth: CGFloat = 35
    var innerCenterDiscColor1 = UIColor(red: 10/255, green: 96/255, blue: 255/255, alpha: 1)
    var innerCenterDiscColor2 = UIColor(red: 255, green: 0, blue: 0, alpha: 1)
    var innerCenterDiscColor = UIColor(red: 10/255, green: 96/255, blue: 255/255, alpha: 1)
    var innerCenterDiscWidth: CGFloat = 25
    
    var needleColor = UIColor(red: 10/255, green: 96/255, blue: 255/255, alpha: 1)
    var needleWidth: CGFloat = 4
    let needle = UIView()
    
    let needleDisc = UIView()
    
    let valueLabel = UILabel()
    var valueFont = UIFont.systemFont(ofSize: 35, weight: .bold)
    var valueColor = UIColor.black
    
    
    
    var value: Int = 0 {
        didSet {
            
            // update the value label to show the exact number
            if(value == 99999) {
                valueLabel.text = "ERR"
            } else {
                valueLabel.text = String(value)
            }

            // figure out where the needle is, between 0 and 1
            var tempValue = Int(Float(Float(value)/Float(gaugeMax)) * 100)
            if(tempValue > 100) {tempValue = 105}
            if(tempValue < 0) {tempValue = 0}
            let needlePosition = CGFloat(tempValue) / 100

            // create a lerp from the start angle (rotation) through to the end angle (rotation + totalAngle)
            let lerpFrom = rotation
            let lerpTo = rotation + totalAngle
            
            if(value > gaugeAlarm) {
                needle.backgroundColor = UIColor(red: 255, green: 0, blue: 0, alpha: 1)
                nameLabel.textColor = UIColor(red: 255, green: 0, blue: 0, alpha: 1)
                innerCenterDiscColor = innerCenterDiscColor2
                if(value == 99999) { value = 0}
                setNeedsDisplay()
            } else {
                needle.backgroundColor = needleColor
                nameLabel.textColor = .black
                innerCenterDiscColor = innerCenterDiscColor1
                setNeedsDisplay()
            }

            // lerp from the start to the end position, based on the needle's position
            let needleRotation = lerpFrom + (lerpTo - lerpFrom) * needlePosition
            needle.transform = CGAffineTransform(rotationAngle: deg2rad(needleRotation))
        }
    }
    
    override func draw(_ rect: CGRect) {
        
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        //drawBackground(in: rect, context: ctx)
        drawSegments(in: rect, context: ctx)
        drawTicks(in: rect, context: ctx)
        drawCenterDisc(in: rect, context: ctx)
        
    }
    
    
    
    func drawBackground(in rect: CGRect, context ctx: CGContext) {
        // draw the outer bezel as the largest circle
        outerBezelColor.set()
        ctx.fillEllipse(in: rect)

        // move in a little on each edge, then draw the inner bezel
        let innerBezelRect = rect.insetBy(dx: outerBezelWidth, dy: outerBezelWidth)
        innerBezelColor.set()
        ctx.fillEllipse(in: innerBezelRect)

        // finally, move in some more and draw the inside of our gauge
        let insideRect = innerBezelRect.insetBy(dx: innerBezelWidth, dy: innerBezelWidth)
        insideColor.set()
        ctx.fillEllipse(in: insideRect)
    }
    

    
    func deg2rad(_ number: CGFloat) -> CGFloat {
        return number * .pi / 180
    }
    
    func drawSegments(in rect: CGRect, context ctx: CGContext) {
        // 1: Save the current drawing configuration
        ctx.saveGState()

        // 2: Move to the center of our drawing rectangle and rotate so that we're pointing at the start of the first segment
        ctx.translateBy(x: rect.midX, y: rect.midY)
        ctx.rotate(by: deg2rad(rotation) - (.pi / 2))

        // 3: Set up the user's line width
        ctx.setLineWidth(segmentWidth)

        // 4: Calculate the size of each segment in the total gauge
        //let segmentAngle = deg2rad(totalAngle / CGFloat(segmentColors.count))
        let segmentAngle = deg2rad(totalAngle / 100.0)

        // 5: Calculate how wide the segment arcs should be
        let segmentRadius = (((rect.width - segmentWidth) / 2) - outerBezelWidth) - innerBezelWidth

        // 6: Draw each segment
        //for (index, segment) in segmentColors.enumerated() {
          for index in 1...100 {
            // figure out where the segment starts in our arc
            let start = CGFloat(index) * segmentAngle

            // activate its color
            //segment.set()
            if (index <= Int((Float(Float(configuration.minSafePressure) / Float(gaugeMax)) * Float(100)))) {
                ctx.setStrokeColor(theGreen.cgColor)
            }
            if (index > Int((Float(Float(configuration.minSafePressure) / Float(gaugeMax)) * Float(100))) && index <= Int((Float(Float(gaugeAlarm) / Float(gaugeMax)) * Float(100)))) {
                ctx.setStrokeColor(theYellow.cgColor)
            }
            if (index > Int((Float(Float(gaugeAlarm) / Float(gaugeMax)) * Float(100)))) {
                ctx.setStrokeColor(theRed.cgColor)
            }
            

            // add a path for the segment
            ctx.addArc(center: .zero, radius: segmentRadius, startAngle: start, endAngle: start + segmentAngle, clockwise: false)

            // and stroke it using the activated color
            ctx.drawPath(using: .stroke)
        }

        // 7: Reset the graphics state
        ctx.restoreGState()
    }
    
    func drawTicks(in rect: CGRect, context ctx: CGContext) {
        // save our clean graphics state
        ctx.saveGState()
        ctx.translateBy(x: rect.midX, y: rect.midY)
        ctx.rotate(by: deg2rad(rotation) - (.pi / 2))

        //let segmentAngle = deg2rad(totalAngle / CGFloat(segmentColors.count))
        let segmentAngle = deg2rad(totalAngle / CGFloat(theMajors))

        let segmentRadius = (((rect.width - segmentWidth) / 2) - outerBezelWidth) - innerBezelWidth

        // save the graphics state where we've moved to the center and rotated towards the start of the first segment
        ctx.saveGState()

        // draw major ticks
        ctx.setLineWidth(majorTickWidth)
        majorTickColor.set()
        
        let majorEnd = segmentRadius + (segmentWidth / 2)
        let majorStart = majorEnd - majorTickLength
        
        //for _ in 0 ... segmentColors.count {
        for _ in 0 ... theMajors {
            ctx.move(to: CGPoint(x: majorStart, y: 0))
            ctx.addLine(to: CGPoint(x: majorEnd, y: 0))
            ctx.drawPath(using: .stroke)
            ctx.rotate(by: segmentAngle)
        }
        


        // go back to the state we had before we drew the major ticks
        ctx.restoreGState()

        // save it again, because we're about to draw the minor ticks
        ctx.saveGState()

        // draw minor ticks
        ctx.setLineWidth(minorTickWidth)
        minorTickColor.set()

        let minorEnd = segmentRadius + (segmentWidth / 2)
        let minorStart = minorEnd - minorTickLength
        let minorTickSize = segmentAngle / CGFloat(minorTickCount + 1)
        
        //for _ in 0 ..< segmentColors.count {
        for _ in 0 ..< theMajors {
            ctx.rotate(by: minorTickSize)

            for _ in 0 ..< minorTickCount {
                ctx.move(to: CGPoint(x: minorStart, y: 0))
                ctx.addLine(to: CGPoint(x: minorEnd, y: 0))
                ctx.drawPath(using: .stroke)
                ctx.rotate(by: minorTickSize)
            }
        }
        
        
        // go back to the graphics state where we've moved to the center and rotated towards the start of the first segment
        ctx.restoreGState()

        // go back to the original graphics state
        ctx.restoreGState()
    }
    
    func drawCenterDisc(in rect: CGRect, context ctx: CGContext) {
        ctx.saveGState()
        ctx.translateBy(x: rect.midX, y: rect.midY)

        let outerCenterRect = CGRect(x: -outerCenterDiscWidth / 2, y: -outerCenterDiscWidth / 2, width: outerCenterDiscWidth, height: outerCenterDiscWidth)
        outerCenterDiscColor.set()
        ctx.fillEllipse(in: outerCenterRect)

        let innerCenterRect = CGRect(x: -innerCenterDiscWidth / 2, y: -innerCenterDiscWidth / 2, width: innerCenterDiscWidth, height: innerCenterDiscWidth)
        innerCenterDiscColor.set()
        ctx.fillEllipse(in: innerCenterRect)
        ctx.restoreGState()
    }
    
    
    func drawSegmentValues() {
        
        // Dynamically draw the value labels around the outside of the circle on the major ticks. Thank you cGPT :)
        
        print("Segments")
        var theX = [Int]()
        var theY = [Int]()
        theX.removeAll()
        theY.removeAll()
        theMajors = padConfig.PPSrange / 100
        if (theMajors <= 10) {
            theIncrement = 100
        }
        if (theMajors > 10 && theMajors <= 20) {
            theMajors = Int(theMajors / 2)
            theIncrement = 200
        }
        if (theMajors > 20) {
            theMajors = Int(theMajors / 3)
            theIncrement = 300
        }
        
        let numberOfFields = theMajors + 1
        let circleCenter = CGPoint(x: 109, y: 105)
        let circleRadius: CGFloat = 68
        let startAngle: CGFloat = 2.16 //2.094  Radians!
        let angleRange: CGFloat = 5.06

        let textPositions = calculateTextPositions(numberOfFields: numberOfFields, circleCenter: circleCenter, circleRadius: circleRadius, startAngle: startAngle, angleRange: angleRange)
        
        
        var theCount = 0
        for index in 0 ..< (theMajors + 1) {
            //let tLabel = UILabel(frame: CGRect(x: theX[index], y: theY[index], width: 40, height: 25))
            let tLabel = UILabel(frame: textPositions[index])
            tLabel.font = UIFont.systemFont(ofSize: 18)
            tLabel.textColor = UIColor.black
            tLabel.text = String(theCount)
            addSubview(tLabel)
            theCount += theIncrement
        }

        
        let lPSI = UILabel(frame: CGRect(x: 112, y: 80, width: 40, height: 25))
        lPSI.font = UIFont.systemFont(ofSize: 18)
        lPSI.textColor = UIColor.black
        lPSI.text = "psi"
        addSubview(lPSI)
        
    }
    
    func eraseAll() {
            layer.contents = nil
           for subview in subviews {
                subview.removeFromSuperview()
            }
        }
    
    
    func calculateTextPositions(numberOfFields: Int, circleCenter: CGPoint, circleRadius: CGFloat, startAngle: CGFloat, angleRange: CGFloat) -> [CGRect] {
        var textPositions: [CGRect] = []
        let angleIncrement = angleRange / CGFloat(numberOfFields - 1)
        
        for i in 0..<numberOfFields {
            let angle = startAngle + CGFloat(i) * angleIncrement
            let x = circleCenter.x + cos(angle) * circleRadius
            let y = circleCenter.y + sin(angle) * circleRadius
            let position = CGRect(x: x, y: y, width: 60, height: 25)
            textPositions.append(position)
        }
        
        return textPositions
    }
    
    
    func setNameLabel() {
        // setup the name of the Gauge
        nameLabel.text = gaugeName
        

    }
    
    func setUp() {
        print("setup")
        segmentColors = [theGreen, theGreen, theGreen, theGreen, theRed]
        
        needle.backgroundColor = needleColor
        needle.translatesAutoresizingMaskIntoConstraints = false

        // make the needle a third of our height
        needle.bounds = CGRect(x: 0, y: 0, width: needleWidth, height: bounds.height / 3)

        // align it so that it is positioned and rotated from the bottom center
        needle.layer.anchorPoint = CGPoint(x: 0.5, y: 1)

        // now center the needle over our center point
        needle.center = CGPoint(x: bounds.midX, y: bounds.midY)
        addSubview(needle)
        
        // this is the value label setup
        
        valueLabel.font = valueFont
        valueLabel.text = "0"
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(valueLabel)

        NSLayoutConstraint.activate([
            valueLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            valueLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -75)
        ])
        
        // set name label
        
        nameLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        nameLabel.text = gaugeName
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(nameLabel)

        NSLayoutConstraint.activate([
            nameLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            nameLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -28)
        ])
        
        drawSegmentValues()
        
        value = 220
        
        
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUp()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setUp()
    }
    
 
    
    
    
}

