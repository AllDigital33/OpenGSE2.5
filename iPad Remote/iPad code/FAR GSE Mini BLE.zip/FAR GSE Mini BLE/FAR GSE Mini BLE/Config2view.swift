//
//  ViewController.swift
//  FAR Biprop Remote
//
//  Created by Brinker, Mike on 5/27/23.
//

import Foundation
import AVFoundation
import UIKit

class Config2View: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var labelSafetyPad: UILabel!
    @IBOutlet weak var imageArmedIcon: UIImageView!
    @IBOutlet weak var labelOxSafety: UILabel!
    
    @IBOutlet weak var labelSafetyLox: UILabel!
    @IBOutlet weak var labelFuelSafety: UILabel!
    @IBOutlet weak var labelSafetyFuel: UILabel!
    
    @IBOutlet weak var labelSafetyHelium: UILabel!
    @IBOutlet weak var labelStatus: UILabel!
    
    @IBOutlet weak var switchMuteAlerts: UISwitch!
    @IBOutlet weak var switchMuteVoice: UISwitch!
    @IBOutlet weak var switchSend: UISwitch!
    
    @IBOutlet weak var switchOxEnable: UISwitch!
    @IBOutlet weak var inputOxName: UITextField!
    @IBOutlet weak var inputOxFill: UITextField!
    @IBOutlet weak var inputOxAlarm: UITextField!
    @IBOutlet weak var inputOxRange: UITextField!
    @IBOutlet weak var labelOxFillActual: UILabel!
    @IBOutlet weak var labelOxAlarmActual: UILabel!
    @IBOutlet weak var labelOxRangeActual: UILabel!
    @IBOutlet weak var switchFuelEnable: UISwitch!
    @IBOutlet weak var inputFuelName: UITextField!
    @IBOutlet weak var inputFuelFill: UITextField!
    @IBOutlet weak var inputFuelAlarm: UITextField!
    @IBOutlet weak var inputFuelRange: UITextField!
    @IBOutlet weak var labelFuelFillActual: UILabel!
    @IBOutlet weak var labelFuelAlarmActual: UILabel!
    @IBOutlet weak var labelFuelRangeActual: UILabel!
    @IBOutlet weak var switchRspareEnable: UISwitch!
    @IBOutlet weak var inputRspareName: UITextField!
    @IBOutlet weak var inputRspareAlarm: UITextField!
    @IBOutlet weak var inputRspareRange: UITextField!
    @IBOutlet weak var labelRspareAlarmActual: UILabel!
    @IBOutlet weak var labelRspareRangeActual: UILabel!
    @IBOutlet weak var switchPspareEnable: UISwitch!
    @IBOutlet weak var inputPspareName: UITextField!
    @IBOutlet weak var inputPspareAlarm: UITextField!
    @IBOutlet weak var inputPspareRange: UITextField!
    @IBOutlet weak var labelPspareAlarmActual: UILabel!
    @IBOutlet weak var labelPspareRangeActual: UILabel!
    @IBOutlet weak var selectorMain: UISegmentedControl!
    @IBOutlet weak var selectorhaz: UISegmentedControl!
    @IBOutlet weak var switchArmA: UISwitch!
    @IBOutlet weak var switchArmB: UISwitch!
    @IBOutlet weak var switchMainOnHold: UISwitch!
    @IBOutlet weak var switchMainOffHold: UISwitch!
    @IBOutlet weak var inputCPUtempAlarm: UITextField!
    @IBOutlet weak var labelCPUtempActual: UILabel!
    @IBOutlet weak var switchValve9: UISwitch!
    @IBOutlet weak var selectorPadRadio: UISegmentedControl!
    @IBOutlet weak var selectorRemoteRadio: UISegmentedControl!
    @IBOutlet weak var inputLineVent: UITextField!
    @IBOutlet weak var labelLineVentActual: UILabel!
    @IBOutlet weak var inputSendPressure: UITextField!
    @IBOutlet weak var labelSendPressureActual: UILabel!
    @IBOutlet weak var switchDefaultAll: UISwitch!
    @IBOutlet weak var switchSend2: UISwitch!
    @IBOutlet weak var imgHealthMbatt: UIImageView!
    @IBOutlet weak var imgHealthHbatt: UIImageView!
    @IBOutlet weak var imgHealthMCUtemp: UIImageView!
    @IBOutlet weak var imgHealthPT: UIImageView!
    @IBOutlet weak var imgHealthRadio: UIImageView!
    @IBOutlet weak var imgHealthFlashMem: UIImageView!
    @IBOutlet weak var imgHealthFlashFull: UIImageView!
    @IBOutlet weak var imgHealthADC: UIImageView!
    @IBOutlet weak var imgHealthMCU: UIImageView!
    @IBOutlet weak var imgHealthBLEbatt: UIImageView!
    @IBOutlet weak var lblMCUtemp: UILabel!
    @IBOutlet weak var labelRadioTimer: UILabel!
    @IBOutlet weak var buttonErrors: UIButton!
    @IBOutlet weak var imageNoSync: UIImageView!
    @IBOutlet weak var labelSafetyPRS: UILabel!
    @IBOutlet weak var labelSafetyPRSvalue: UILabel!
    @IBOutlet weak var labelPressureSafety: UILabel!
    @IBOutlet weak var switchRadio: UISwitch!
    @IBOutlet weak var switchDAQfiles: UISwitch!
    @IBOutlet weak var tableBluetooth: UITableView!
    @IBOutlet weak var labelBLEdevice: UILabel!
    @IBOutlet weak var buttonBLE: UIButton!
    @IBOutlet weak var labelBluetoothBatt: UILabel!
    @IBOutlet weak var labeliPadBatt: UILabel!
    @IBOutlet weak var imgHealthiPadBatt: UIImageView!
    @IBOutlet weak var imgHealthiPadRadio: UIImageView!
    @IBOutlet weak var inputValve9: UITextField!
    
    
    
    var player: AVAudioPlayer?
    var timerOne: Timer?
    var bluetoothList = [String]()
    var BLEtempCount = 0
    var BLEtimer: Date = Date()
    let cellReuseIdentifier = "cell"
    let cellSpacingHeight: CGFloat = 1

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        //let voices = AVSpeechSynthesisVoice.speechVoices()
        //for voice in voices {
        //    print(voice.language)
       // }
        
        labelStatus.text = ""
        inputValve9.isHidden = true
        
        timerOne = Timer.scheduledTimer(timeInterval: 0.25, target: self, selector: #selector(self.housekeepingTimer), userInfo: nil, repeats: true)
        refreshView()
        refreshData()
        updateConfig()
        bluetoothTableInit()
        //refreshInput()
        

        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        refreshView()
        refreshData()
        updateConfig()
        bluetoothList.removeAll()
        tableBluetooth.reloadData()
    }

    
    @objc func housekeepingTimer() {
        if(working.viewConfigRefreshData) {refreshData()}
        if(working.viewConfigRefreshScreen) {refreshView()}
        if(working.viewConfigRefreshConfig) {updateConfig()}
        if(working.viewHealthRefresh) {updateHealth()}
        
        // clear status
        if(working.statusTimeout < Date() && labelStatus.text != "") {
             labelStatus.text = ""
         }
         //update status
        if(working.statusTimeout > Date()) {
             labelStatus.text = working.status
         }
        
        
        radioLast() // update radio last counter
        
        localBatteries()
        
        if(errors.errorCount > 0) {
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
        
        //----- BLE -------------------------------------
        if(working.BLEsearch && BLEtimer > Date()) {
            if(working.BLEdevices.count > BLEtempCount) {
                BLEtempCount = working.BLEdevices.count
                bluetoothList.removeAll()
                bluetoothList = working.BLEdevices
                tableBluetooth.reloadData()
                print("Searching found one")
            }
        }
        if(working.BLEsearch && BLEtimer < Date()) {
            working.BLEsearch = false
            print("Searching done")
            buttonBLE.setTitle("Search Bluetooth", for: .normal)
        }
        
        

        
    }

    //===================================  REFRESH HERE ================================================
    
    func radioLast() {
        
        if(working.firstContact) {
            let theDiff: Int = getDateDiff(start: working.radioLastClock, end: Date())
            labelRadioTimer.text = String(theDiff)
        } else {
            labelRadioTimer.text = String("N/A")
        }
    }
    func getDateDiff(start: Date, end: Date) -> Int  {
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([Calendar.Component.second], from: start, to: end)
        let seconds = dateComponents.second
        return Int(seconds!)
    }
    
    
    func refreshView() {
        labelOxSafety.text = configuration.oxTankName
        labelFuelSafety.text = configuration.fuelTankName
        labelPressureSafety.text = configuration.pressureTankName
        labelSafetyPRS.text = configuration.rspareTankName
        working.viewConfigRefreshScreen = false
    }
    
    func refreshData() {
        // ---------------- Standard Header
        if(padStatus.padHot) {
            labelSafetyPad.text = "HOT"
            labelSafetyPad.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        } else {
            labelSafetyPad.text = "SAFE"
            labelSafetyPad.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.padArmed) {
            imageArmedIcon.image = UIImage(named: "armed")
        } else {
            imageArmedIcon.image = UIImage(named: "disarm2")
        }
        if(errors.errorCount > 0) {
            buttonErrors.setTitle(" ", for: .normal)
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
        if(padConfig.updated == 1) {
            imageNoSync.isHidden = true
        } else {
            imageNoSync.isHidden = false
        }
        // ---------------- end standard header

        updatePressure()
        
        lblMCUtemp.text = "MCU Temperature: " + String(padStatus.CPUtemp) + " F"
        
        working.viewConfigRefreshData = false
        
        if(working.radioTab) {
            switchRadio.isOn = true
        } else {
            switchRadio.isOn = false
        }
        if(working.filesTab) {
            switchDAQfiles.isOn = true
        } else {
            switchDAQfiles.isOn = false
        }
        labelBLEdevice.text = configuration.BLEdevice
        
        
    }
    
    
    func denySend() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "You must unlock the safety before sending the request", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    
    func denyMessage(theText: String) { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: theText, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }

    func updatePressure() {
        
        // =====================================   Standard header
        if(padConfig.POXenabled == 1){
            labelSafetyLox.isHidden = false
            labelOxSafety.isHidden = false
        } else {
            labelSafetyLox.isHidden = true
            labelOxSafety.isHidden = true
        }
        if(padStatus.pressureOne == 99999) {
            labelSafetyLox.text = String("ERR")
        } else {
            labelSafetyLox.text = String(padStatus.pressureOne)
        }
        if(padStatus.pressureOne > padConfig.POXalarm || padStatus.pressureOne == 99999) {
            labelSafetyLox.textColor = .red
        } else {
            labelSafetyLox.textColor = .black
        }
        //-----
        if(padConfig.PFLenabled == 1){
            labelSafetyFuel.isHidden = false
            labelFuelSafety.isHidden = false
        } else {
            labelSafetyFuel.isHidden = true
            labelFuelSafety.isHidden = true
        }
        if(padStatus.pressureTwo == 99999) {
            labelSafetyFuel.text = String("ERR")
        } else {
            labelSafetyFuel.text = String(padStatus.pressureTwo)
        }
        if(padStatus.pressureTwo > padConfig.PFLalarm || padStatus.pressureTwo == 99999) {
            labelSafetyFuel.textColor = .red
        } else {
            labelSafetyFuel.textColor = .black
        }
        //------
        if(padConfig.PPSenabled == 1){
            labelSafetyHelium.isHidden = false
            labelPressureSafety.isHidden = false
        } else {
            labelSafetyHelium.isHidden = true
            labelPressureSafety.isHidden = true
        }
        if(padStatus.pressureThree == 99999) {
            labelSafetyHelium.text = String("ERR")
        } else {
            labelSafetyHelium.text = String(padStatus.pressureThree)
        }
        if(padStatus.pressureThree > padConfig.PPSalarm || padStatus.pressureThree == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        if(padConfig.PRSenabled == 1){
            labelSafetyPRS.isHidden = false
            labelSafetyPRSvalue.isHidden = false
        } else {
            labelSafetyPRS.isHidden = true
            labelSafetyPRSvalue.isHidden = true
        }
        if(padStatus.pressureFour == 99999) {
            labelSafetyPRSvalue.text = String("ERR")
        } else {
            labelSafetyPRSvalue.text = String(padStatus.pressureFour)
        }
        if(padStatus.pressureFour > padConfig.PRSalarm || padStatus.pressureFour == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        
        //====== END HEADER
    }
    
    func upRM(newAdd: String) {
        working.radioMessage = working.radioMessage + newAdd + ","
    }

    func trimIt(testS: String) -> String {
        var tmp: String = testS
        tmp = tmp.trimmingCharacters(in: .whitespacesAndNewlines)
        return tmp
    }
    
    //========================================== Health check =========================
    func updateHealth() {
        
        if(errors.mainBatt == 0) {
            imgHealthMbatt.image = UIImage(named: "good")
        } else {
            if(errors.mainBatt == 1) {
                imgHealthMbatt.image = UIImage(named: "bad")
            } else {
                imgHealthMbatt.image = UIImage(named: "question")
            }
        }
        
        if(errors.hazBatt == 0) {
            imgHealthHbatt.image = UIImage(named: "good")
        } else {
            if(errors.hazBatt == 1) {
                imgHealthHbatt.image = UIImage(named: "bad")
            } else {
                imgHealthHbatt.image = UIImage(named: "question")
            }
        }
        if(errors.MCUtemp == 0) {
            imgHealthMCUtemp.image = UIImage(named: "good")
        } else {
            if(errors.MCUtemp == 1) {
                imgHealthMCUtemp.image = UIImage(named: "bad")
            } else {
                imgHealthMCUtemp.image = UIImage(named: "question")
            }
        }
        if(errors.PT == 0) {
            imgHealthPT.image = UIImage(named: "good")
        } else {
            if(errors.PT == 1) {
                imgHealthPT.image = UIImage(named: "bad")
            } else {
                imgHealthPT.image = UIImage(named: "question")
            }
        }
        if(errors.radio == 0) {
            imgHealthRadio.image = UIImage(named: "good")
        } else {
            if(errors.radio == 1) {
                imgHealthRadio.image = UIImage(named: "bad")
            } else {
                imgHealthRadio.image = UIImage(named: "question")
            }
        }
        if(errors.flashMem == 0) {
            imgHealthFlashMem.image = UIImage(named: "good")
        } else {
            if(errors.flashMem == 1) {
                imgHealthFlashMem.image = UIImage(named: "bad")
            } else {
                imgHealthFlashMem.image = UIImage(named: "question")
            }
        }
        if(errors.flashFull == 0) {
            imgHealthFlashFull.image = UIImage(named: "good")
        } else {
            if(errors.flashFull == 1) {
                imgHealthFlashFull.image = UIImage(named: "bad")
            } else {
                imgHealthFlashFull.image = UIImage(named: "question")
            }
        }
        if(errors.ADC == 0) {
            imgHealthADC.image = UIImage(named: "good")
        } else {
            if(errors.ADC == 1) {
                imgHealthADC.image = UIImage(named: "bad")
            } else {
                imgHealthADC.image = UIImage(named: "question")
            }
        }
        if(errors.MCUcrash == 0) {
            imgHealthMCU.image = UIImage(named: "good")
        } else {
            if(errors.ADC == 1) {
                imgHealthMCU.image = UIImage(named: "bad")
            } else {
                imgHealthMCU.image = UIImage(named: "question")
            }
        }
        if(errors.errorCount > 0) {
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
        working.viewHealthRefresh = false
    }
    
    func localBatteries() {
        // ---- Bluetooth Battery Error ---------------
        if(errors.BLEbatt == 0) {
            imgHealthBLEbatt.image = UIImage(named: "good")
            labelBluetoothBatt.text = "Bluetooth Battery = " + String(working.BLEbattery) + "%"
        } else {
            if(errors.BLEbatt == 1) {
                imgHealthBLEbatt.image = UIImage(named: "bad")
                labelBluetoothBatt.text = "Bluetooth Battery = " + String(working.BLEbattery) + "%"
            } else {
                imgHealthBLEbatt.image = UIImage(named: "question")
                labelBluetoothBatt.text = "Bluetooth Battery"
            }
        }
        // ---- iPad local Battery Error ---------------
        if(errors.iPadBatt == 0) {
            imgHealthiPadBatt.image = UIImage(named: "good")
            labeliPadBatt.text = "iPad Battery = " + String(working.iPadBatt) + "%"
        } else {
            if(errors.iPadBatt == 1) {
                imgHealthiPadBatt.image = UIImage(named: "bad")
                labeliPadBatt.text = "iPad Battery = " + String(working.iPadBatt) + "%"
            } else {
                imgHealthiPadBatt.image = UIImage(named: "question")
                labeliPadBatt.text = "iPad Battery"
            }
        }
        
        // ---- iPad 433Mhz Lora Radio Error ---------------
        if(errors.localRadio == 0) {
            imgHealthiPadRadio.image = UIImage(named: "good")
        } else {
            if(errors.localRadio == 1) {
                imgHealthiPadRadio.image = UIImage(named: "bad")
            } else {
                imgHealthiPadRadio.image = UIImage(named: "question")
            }
        }
        
        
        
    }
    
    func createRadioMessage() {
        
        // zzz call function to data check everything
        var thes: String = ""
        working.radioMessage = "#FCFG,"
        
        if(switchOxEnable.isOn) {upRM(newAdd: "1")} else {upRM(newAdd: "0")}
        thes = trimIt(testS: inputOxRange.text ?? "99"); upRM(newAdd: thes)
        thes = trimIt(testS: inputOxFill.text ?? "99"); upRM(newAdd: thes)
        thes = trimIt(testS: inputOxAlarm.text ?? "99"); upRM(newAdd: thes)
        if(switchFuelEnable.isOn) {upRM(newAdd: "1")} else {upRM(newAdd: "0")}
        thes = trimIt(testS: inputFuelRange.text ?? "99"); upRM(newAdd: thes)
        thes = trimIt(testS: inputFuelFill.text ?? "99"); upRM(newAdd: thes)
        thes = trimIt(testS: inputFuelAlarm.text ?? "99"); upRM(newAdd: thes)
        if(switchPspareEnable.isOn) {upRM(newAdd: "1")} else {upRM(newAdd: "0")}
        thes = trimIt(testS: inputPspareRange.text ?? "99"); upRM(newAdd: thes)
        thes = trimIt(testS: inputPspareAlarm.text ?? "99"); upRM(newAdd: thes)
        if(switchRspareEnable.isOn) {upRM(newAdd: "1")} else {upRM(newAdd: "0")}
        thes = trimIt(testS: inputRspareRange.text ?? "99"); upRM(newAdd: thes)
        thes = trimIt(testS: inputRspareAlarm.text ?? "99"); upRM(newAdd: thes)
        
        thes = trimIt(testS: inputSendPressure.text ?? "99"); upRM(newAdd: thes)
        thes = trimIt(testS: inputLineVent.text ?? "99"); upRM(newAdd: thes)
        if(selectorMain.selectedSegmentIndex == 0){upRM(newAdd: "12")} else {upRM(newAdd: "24")}
        if(selectorhaz.selectedSegmentIndex == 0){upRM(newAdd: "12")} else {upRM(newAdd: "24")}
        if(switchArmA.isOn) {upRM(newAdd: "1")} else {upRM(newAdd: "0")}
        if(switchArmB.isOn) {upRM(newAdd: "1")} else {upRM(newAdd: "0")}
        if(switchValve9.isOn) {upRM(newAdd: "1")} else {upRM(newAdd: "0")}
        if(switchMainOnHold.isOn) {upRM(newAdd: "1")} else {upRM(newAdd: "0")}
        if(switchMainOffHold.isOn) {upRM(newAdd: "1")} else {upRM(newAdd: "0")}
        if(selectorPadRadio.selectedSegmentIndex == 0){upRM(newAdd: "2")} else {upRM(newAdd: "1")}
        if(selectorRemoteRadio.selectedSegmentIndex == 0){upRM(newAdd: "2")} else {upRM(newAdd: "1")}
        thes = trimIt(testS: inputCPUtempAlarm.text ?? "99"); upRM(newAdd: thes)
        working.radioMessage = working.radioMessage + "!"

    }
    
    
    //**************************************  IB ACTIONS *******************************
    
    @IBAction func switchRadioAction(_ sender: Any) {  // show or hide the radio tab
        
        if(switchRadio.isOn == false) {
            var theIndex: Int = 0
            if let viewControllers = tabBarController?.viewControllers {
                for viewController in viewControllers {
                    let className = String(describing: Mirror(reflecting: viewController).subjectType)
                    if className.contains("Radio") {
                        print("Found a 'RadioViewController' instance.")
                        radioVC = tabBarController?.viewControllers?.remove(at: theIndex) as! RadioView
                        working.radioTab = false
                    }
                 theIndex += 1
                }
            }
        } else {
            print("showing the radio view")
            //tabBarController?.viewControllers?.insert(radioVC,at: 6)
            var theIndex: Int = 0
            var test: Bool = false
            if let viewControllers = tabBarController?.viewControllers {
                for viewController in viewControllers {
                    let className = String(describing: Mirror(reflecting: viewController).subjectType)
                    if className.contains("Radio") {
                        test = true
                    }
                 theIndex += 1
                }
            }
            if(!test) {
              tabBarController?.viewControllers?.insert(radioVC,at: theIndex)
                working.radioTab = true
            }
        }
    }
    
    @IBAction func switchDAQtabHide(_ sender: Any) {
      
        if(switchDAQfiles.isOn == false) {
            var theIndex: Int = 0
            if let viewControllers = tabBarController?.viewControllers {
                for viewController in viewControllers {
                    let className = String(describing: Mirror(reflecting: viewController).subjectType)
                    if className.contains("Files") {
                        print("Found a 'DAQViewController' instance.")
                        DAQfilesVC = tabBarController?.viewControllers?.remove(at: theIndex) as! FilesView
                        working.filesTab = false
                    }
                 theIndex += 1
                }
            }
        } else {
            print("showing the Files view")
            //tabBarController?.viewControllers?.insert(radioVC,at: 6)
            var theIndex: Int = 0
            var test: Bool = false
            if let viewControllers = tabBarController?.viewControllers {
                for viewController in viewControllers {
                    let className = String(describing: Mirror(reflecting: viewController).subjectType)
                    if className.contains("Files") {
                        test = true
                    }
                 theIndex += 1
                }
            }
            if(!test) {
              tabBarController?.viewControllers?.insert(DAQfilesVC,at: theIndex)
                working.filesTab = true
            }
        }

    }
    
    
    
    
    
    
    
    @IBAction func switchMuteAlertsChanged(_ sender: Any) {
        if(switchMuteAlerts.isOn) {
            configuration.mute = true
        } else {
            configuration.mute = false
        }
    }
    
    @IBAction func switchMuteVoiceChanged(_ sender: Any) {
        if(switchMuteVoice.isOn) {
            configuration.voice = true
        } else {
            configuration.voice = false
        }
        
    }
    
    @IBAction func buttonSaveSend1(_ sender: Any) {
        
        
        if(switchSend.isOn) {
            let checkit = validate()
            if(checkit) { // field validation
                createRadioMessage()
                working.radioSend = true

                working.viewStatusRefreshScreen = true
                working.viewStatusRefreshData = true
                
                working.status = "Sent Config Change Request..."
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
                saveLocalConfig()
                readLocalConfig()
            }
            switchSend.isOn = false
            switchSend2.isOn = false
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonSaveSend2(_ sender: Any) {
        if(switchSend2.isOn) {
            let checkit = validate()
            if(checkit) { // field validation
                createRadioMessage()
                working.radioSend = true

                working.viewStatusRefreshScreen = true
                working.viewStatusRefreshData = true
                
                working.status = "Sent Config Change Request..."
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
                saveLocalConfig()
                readLocalConfig()
            }
            switchSend.isOn = false
            switchSend2.isOn = false
            
        } else {
          denySend()
        }
        
    }
    
    @IBAction func buttonStatusAction(_ sender: Any) {
        
        working.radioMessage = "#S,033,!"
        working.radioSend = true
        working.status = "Sent Status Request..."
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
        
    }
    
    //============= BLUETOOTH SELECTION ======================================================
    
    @IBAction func buttonBluetooth(_ sender: Any) {
        
        if(!working.BLEsearch) {
            //--- BLE ---------
            if(working.BLEstatus && myPeripheal != nil) { //zzz
                manager?.cancelPeripheralConnection(myPeripheal!)
            }
            working.BLEstatus = false
            bluetoothList.removeAll()
            tableBluetooth.reloadData()
            configuration.BLEdevice = "null"
            working.BLEdevices.removeAll()
            labelBLEdevice.text = "none"
            buttonBLE.setTitle("Searching...", for: .normal)
            BLEtempCount = 0
            BLEtimer = Date().addingTimeInterval(15)
            manager?.scanForPeripherals(withServices: nil, options: nil)
            working.BLEsearch = true
            print("Pair Bluetooth Searching Button")
        }
    }
    
    func bluetoothTableInit() {
        bluetoothList.removeAll()
        tableBluetooth.layer.borderWidth = 2
        tableBluetooth.layer.borderColor = UIColor.black.cgColor
        // Register the table view cell class and its reuse id
        self.tableBluetooth.register(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)
        // This view controller itself will provide the delegate methods and row data for the table view.
        tableBluetooth.delegate = self
        tableBluetooth.dataSource = self
        print("Pair Bluetooth Init")
    
    }
    
    // create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell: UITableViewCell
        if tableView == tableBluetooth {
            cell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier, for: indexPath)
            cell.textLabel?.text = bluetoothList[indexPath.row]
        } else {
            cell = UITableViewCell()
        }

        return cell
    }
    
    // Set the spacing between sections
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return cellSpacingHeight
    }
    
    // method to run when table view cell is tapped
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if tableView == tableBluetooth {
            let selectedValue = bluetoothList[indexPath.row]
                // Perform action for the local table view
            print("Selected value in table: \(bluetoothList[indexPath.row])")
            configuration.BLEdevice = selectedValue
            labelBLEdevice.text = selectedValue
            manager?.scanForPeripherals(withServices: nil, options: nil)
            saveLocalConfig()
            
            }
    }
    
    // number of rows in table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tableBluetooth {
            return bluetoothList.count
           }
        return 0
    }
    

    

    
    
    
    
    //****************************  FIELD EDIT CHECKS *********************************
    
    func validate() -> Bool {
        // used before save to validate field contents
        
        var theF: Int = 0
        var theA: Int = 0
        var theR: Int = 0
        var thes: String = ""
        if(switchOxEnable.isOn) {
            thes = inputOxFill.text ?? "9999"
            theF = Int(thes.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 9999
            thes = inputOxAlarm.text ?? "9999"
            theA = Int(thes.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 9999
            thes = inputOxRange.text ?? "9999"
            theR = Int(thes.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 9999
            if(theF == 9999 || theA == 9999 || theR == 9999 || theF > theR || theF > theA || theA > theR) {
                denyMessage(theText: "Ox values range error")
                return false
            }
        }
        if(switchFuelEnable.isOn) {
            thes = inputFuelFill.text ?? "9999"
            theF = Int(thes.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 9999
            thes = inputFuelAlarm.text ?? "9999"
            theA = Int(thes.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 9999
            thes = inputFuelRange.text ?? "9999"
            theR = Int(thes.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 9999
            if(theF == 9999 || theA == 9999 || theR == 9999 || theF > theR || theF > theA || theA > theR) {
                denyMessage(theText: "Fuel values range error")
                return false
            }
        }
        if(switchRspareEnable.isOn) {
            thes = inputRspareAlarm.text ?? "9999"
            theA = Int(thes.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 9999
            thes = inputRspareRange.text ?? "9999"
            theR = Int(thes.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 9999
            if(theA == 9999 || theR == 9999 || theA > theR) {
                denyMessage(theText: "RSpare values range error")
                return false
            }
        }
        if(switchPspareEnable.isOn) {
            thes = inputPspareAlarm.text ?? "9999"
            theA = Int(thes.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 9999
            thes = inputPspareRange.text ?? "9999"
            theR = Int(thes.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 9999
            if(theA == 9999 || theR == 9999 || theA > theR) {
                denyMessage(theText: "PSpare values range error")
                return false
            }
        }
        thes = inputCPUtempAlarm.text ?? "9999"
        theA = Int(thes.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 9999
        if(theA > 250 || theA < 0) {
            denyMessage(theText: "CPU Alarm out of range")
            return false
        }
        thes = inputLineVent.text ?? "9999"
        theA = Int(thes.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 9999
        if(theA > 30000 || theA < 0) {
            denyMessage(theText: "Line Vent time out of range")
            return false
        }
        thes = inputSendPressure.text ?? "9999"
        theA = Int(thes.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 9999
        if(theA > 60000 || theA < 1000) {
            denyMessage(theText: "Send Pressure Interval out of range 1000-60000")
            return false
        }
        
        
        return true
    }

    func rCheck(testS: String) -> Bool {
        if(Int(testS) ?? 0 > 0 && Int(testS) ?? 100 < 6001) {
            return true
        } else {
            return false
        }
    }
                
    @IBAction func valve9Switch(_ sender: Any) {
        if(switchValve9.isOn) {
            inputValve9.isHidden = false
        } else {
            inputValve9.isHidden = true
        }
    }
    
                
    @IBAction func OxNameEditEnd(_ sender: Any) {
        var thes: String = ""
        thes = inputOxName.text ?? "Lox"
        thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
        if(thes.count > 0 && thes.count < 7) {
        } else {
            denyMessage(theText: "Ox name too long or short")
            inputOxName.text = configuration.oxTankName
        }
    }
    
    @IBAction func FuelNameEdit(_ sender: Any) {
        var thes: String = ""
        thes = inputFuelName.text ?? "Fuel"
        thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
        if(thes.count > 0 && thes.count < 7) {
        } else {
            denyMessage(theText: "Fuel name too long or short")
            inputFuelName.text = configuration.fuelTankName
        }
    }
    
    @IBAction func rspareNameEdit(_ sender: Any) {
        var thes: String = ""
        thes = inputRspareName.text ?? "Rspare"
        thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
        if(thes.count > 0 && thes.count < 7) {
        } else {
            denyMessage(theText: "Rocket Spare name too long or short")
            inputRspareName.text = configuration.rspareTankName
        }
    }
    
    @IBAction func valve9Edit(_ sender: Any) {
        var thes: String = ""
        thes = inputValve9.text ?? "Valve 9"
        thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
        if(thes.count > 0 && thes.count < 15) {
        } else {
            denyMessage(theText: "Valve name too long or short (1-14 char)")
            inputValve9.text = configuration.valve9Name
        }
    }
    
    
    
    
    @IBAction func pspareNameEdit(_ sender: Any) {
        var thes: String = ""
        thes = inputPspareName.text ?? "Pspare"
        thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
        if(thes.count > 0 && thes.count < 7) {
        } else {
            denyMessage(theText: "Pad Spare name too long or short")
            inputPspareName.text = configuration.pressureTankName
        }
    }
    
    @IBAction func CPUtempEdit(_ sender: Any) {
        var thes: String = ""
        thes = inputCPUtempAlarm.text ?? "170"
        thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
        if(Int(thes) ?? 0 > 0 && Int(thes) ?? 100 < 300) {
        } else {
            denyMessage(theText: "CPU Temperature Alarm out of range")
            inputCPUtempAlarm.text = String(padConfig.CPUtempAlarm)
        }
        
    }
    
    @IBAction func switchRspareChanged(_ sender: Any) {
        if(switchRspareEnable.isOn) {
            inputRspareName.isEnabled = true
            inputRspareAlarm.isEnabled = true
            inputRspareRange.isEnabled = true
        } else {
            inputRspareName.isEnabled = false
            inputRspareAlarm.isEnabled = false
            inputRspareRange.isEnabled = false
        }
    }
    
    @IBAction func switchPspareChanged(_ sender: Any) {
        if(switchPspareEnable.isOn) {
            inputPspareName.isEnabled = true
            inputPspareAlarm.isEnabled = true
            inputPspareRange.isEnabled = true
        } else {
            inputPspareName.isEnabled = false
            inputPspareAlarm.isEnabled = false
            inputPspareRange.isEnabled = false
        }
    }
    
    @IBAction func switchMuteAction(_ sender: Any) {
        if(switchMuteAlerts.isOn) {
            configuration.mute = true
        } else {
            configuration.mute = false
        }
    }
    
    @IBAction func switchVoiceAction(_ sender: Any) {
        if(switchMuteVoice.isOn) {
            configuration.voice = true
        } else {
            configuration.voice = false
        }
    }
    
    //============================================= DEFAULT =====================================
    
    @IBAction func buttonDefaultAction(_ sender: Any) {
        
        if(switchDefaultAll.isOn) {
            okCancelDefault()
            switchDefaultAll.isOn = false
        } else {
            denySend()
        }
    }
    
    func okCancelDefault() {
        
        let alertController = UIAlertController(title: "Confirm", message: "This will reset all settings to default, close all valves and stop current processes", preferredStyle: .alert)
        // Create the OK action
        let okAction = UIAlertAction(title: "OK", style: .default) { (_) in
            print("OK tapped")
            working.radioMessage = "#DEFAULT,33,!"
            working.radioSend = true
            working.status = "Sent Default All Request..."
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            
        }
        // Create the cancel action
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (_) in
            print("Cancel tapped")
            
        }
        // Add the actions to the alert controller
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)

        // Present the alert controller
        present(alertController, animated: true, completion: nil)
        
    }
    
    
    //============================================= ZERO  =====================================
    
    
    @IBAction func buttonZeroOx(_ sender: Any) {
        working.radioMessage = "#ZPOX,33,!"
        working.radioSend = true
        working.status = "Sent Zero Request..."
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
    }
    @IBAction func buttonZeroFuel(_ sender: Any) {
        working.radioMessage = "#ZPFL,33,!"
        working.radioSend = true
        working.status = "Sent Zero Request..."
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
    }
    @IBAction func buttonZeroRspare(_ sender: Any) {
        working.radioMessage = "#ZPRS,33,!"
        working.radioSend = true
        working.status = "Sent Zero Request..."
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
    }
    @IBAction func buttonZeroPSpare(_ sender: Any) {
        working.radioMessage = "#ZPPS,33,!"
        working.radioSend = true
        working.status = "Sent Zero Request..."
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
    }
    
    
 //============================================= update config =====================================
    
    func updateConfig() {
        
        if(padConfig.updated == 0) {
            imageNoSync.isHidden = false
        } else {
            imageNoSync.isHidden = true
        }
        
        if(padConfig.POXenabled == 1) {
            switchOxEnable.isOn = true
        } else {
            switchOxEnable.isOn = false
        }
        //----------------------
        labelOxFillActual.text = String(padConfig.POXfill)
        inputOxFill.text = String(padConfig.POXfill)
        //--------
        labelOxAlarmActual.text = String(padConfig.POXalarm)
        inputOxAlarm.text = String(padConfig.POXalarm)
        //--------
        labelOxRangeActual.text = String(padConfig.POXrange)
        inputOxRange.text = String(padConfig.POXrange)
        //----------------------
        if(padConfig.PFLenabled == 1) {
            switchFuelEnable.isOn = true
        } else {
            switchFuelEnable.isOn = false
        }
        //----------------------
        labelFuelFillActual.text = String(padConfig.PFLfill)
        inputFuelFill.text = String(padConfig.PFLfill)
        //--------
        labelFuelAlarmActual.text = String(padConfig.PFLalarm)
        inputFuelAlarm.text = String(padConfig.PFLalarm)
        //--------
        labelFuelRangeActual.text = String(padConfig.PFLrange)
        inputFuelRange.text = String(padConfig.PFLrange)
        //----------------------
        if(padConfig.PRSenabled == 1) {
            switchRspareEnable.isOn = true
            
        } else {
            switchRspareEnable.isOn = false
            
        }
        //----------------------
        labelRspareAlarmActual.text = String(padConfig.PRSalarm)
        inputRspareAlarm.text = String(padConfig.PRSalarm)
        //--------
        labelRspareRangeActual.text = String(padConfig.PRSrange)
        inputRspareRange.text = String(padConfig.PRSrange)
        //----------------------
        if(padConfig.PPSenabled == 1) {
            switchPspareEnable.isOn = true
        } else {
            switchPspareEnable.isOn = false
        }
        //----------------------
        labelPspareAlarmActual.text = String(padConfig.PPSalarm)
        inputPspareAlarm.text = String(padConfig.PPSalarm)
        //--------
        labelPspareRangeActual.text = String(padConfig.PRSrange)
        inputPspareRange.text = String(padConfig.PPSrange)
        //==========================
        if(padConfig.mainVoltage2412 == 12) {
            selectorMain.selectedSegmentIndex = 0
        } else {
            selectorMain.selectedSegmentIndex = 1
        }
        if(padConfig.hazVoltage2412 == 12) {
            selectorhaz.selectedSegmentIndex = 0
        } else {
            selectorhaz.selectedSegmentIndex = 1
        }
        //---------------------
        if(padConfig.recoveryArmA == 1) {
            switchArmA.isOn = true
        } else {
            switchArmA.isOn = false
        }
        if(padConfig.recoveryArmB == 1) {
            switchArmB.isOn = true
        } else {
            switchArmB.isOn = false
        }
        //-------------------
        if(padConfig.holdMainOn == 1) {
            switchMainOnHold.isOn = true
        } else {
            switchMainOnHold.isOn = false
        }
        if(padConfig.holdMainOff == 1) {
            switchMainOffHold.isOn = true
        } else {
            switchMainOffHold.isOn = false
        }
        //----------------------
        labelCPUtempActual.text = String(padConfig.CPUtempAlarm)
        inputCPUtempAlarm.text = String(padConfig.CPUtempAlarm)
        //--------
        if(padConfig.valve9 == 1) {
            switchValve9.isOn = true
            inputValve9.isHidden = false
            inputValve9.text = configuration.valve9Name
        } else {
            switchValve9.isOn = false
            inputValve9.isHidden = true
            inputValve9.text = configuration.valve9Name
        }
        //==========================
        if(padConfig.padRadioPower == 2) {
            selectorPadRadio.selectedSegmentIndex = 0
        } else {
            selectorPadRadio.selectedSegmentIndex = 1
        }
        if(padConfig.remoteRadioPower == 2) {
            selectorRemoteRadio.selectedSegmentIndex = 0
        } else {
            selectorRemoteRadio.selectedSegmentIndex = 1
        }
        //---------------------
        labelLineVentActual.text = String(padConfig.lineVentDelay)
        inputLineVent.text = String(padConfig.lineVentDelay)
        labelSendPressureActual.text = String(padConfig.pressureWaitTime)
        inputSendPressure.text = String(padConfig.pressureWaitTime)
        
        readLocalConfig()
        inputOxName.text = configuration.oxTankName
        inputFuelName.text = configuration.fuelTankName
        inputRspareName.text = configuration.rspareTankName
        inputPspareName.text = configuration.pressureTankName
        
        
        // zzz add DAQ to Config
        
        
        
        working.viewConfigRefreshConfig = false
    }
    
    //*********************************  Local Config File  **********************************



    func configFileURL(fileN: String) -> URL? {
        guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return nil }
        return documentsDirectory.appendingPathComponent(fileN)
        }

    func saveLocalConfig() {
          
        let filename: String = "config.txt"
        let configFile = configFileURL(fileN: filename)
        
        var saveLine: String = ""
        saveLine = (inputOxName.text ?? "X") + "," + (inputFuelName.text ?? "X") + ","
        saveLine = saveLine + (inputRspareName.text ?? "X") + "," + (inputPspareName.text ?? "X") + ","
        saveLine = saveLine + (configuration.BLEdevice) + "," + (inputValve9.text ?? "V9") + ",!"
        
        let data = (saveLine).data(using: String.Encoding.utf8)

        if FileManager.default.fileExists(atPath: configFile!.path) {
            if let fileHandle = try? FileHandle(forWritingTo: configFile!)          {
                fileHandle.write(data!)
                fileHandle.closeFile()
             }
            } else {
                try? data!.write(to: configFile!, options: .atomicWrite)
            }

    }
    

    
    
    
    
    
}



