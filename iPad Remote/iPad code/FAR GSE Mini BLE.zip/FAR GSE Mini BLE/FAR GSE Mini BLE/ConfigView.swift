//
//  ViewController.swift
//  FAR Biprop Remote
//
//  Created by Brinker, Mike on 3/22/21.
//

import Foundation
import AVFoundation
import UIKit

class ConfigView: UIViewController {

    @IBOutlet weak var switchDiagsTab: UISwitch!
    @IBOutlet weak var switchRadioTab: UISwitch!
    @IBOutlet weak var switchMuteAlerts: UISwitch!
    @IBOutlet weak var switchMuteVoice: UISwitch!
    @IBOutlet weak var labelSafetyPad: UILabel!
    @IBOutlet weak var labelSafetyLox: UILabel!
    @IBOutlet weak var labelSafetyFuel: UILabel!
    @IBOutlet weak var labelSafetyHelium: UILabel!
    @IBOutlet weak var labelOxSafety: UILabel!
    @IBOutlet weak var labelFuelSafety: UILabel!
    @IBOutlet weak var labelHeliumSafety: UILabel!
    @IBOutlet weak var labelStatus: UILabel!
    @IBOutlet weak var labelPressureSafety: UILabel!
    @IBOutlet weak var imageArmedIcon: UIImageView!
    @IBOutlet weak var labelLoxFillActual: UILabel!
    @IBOutlet weak var labelLoxAlarmActual: UILabel!
    @IBOutlet weak var labelFuelFillActual: UILabel!
    @IBOutlet weak var labelFuelAlarmActual: UILabel!
    @IBOutlet weak var switchSave: UISwitch!
    @IBOutlet weak var segmentSelector: UISegmentedControl!
    @IBOutlet weak var inputLoxFill: UITextField!
    @IBOutlet weak var inputLoxAlarm: UITextField!
    @IBOutlet weak var inputFuelFill: UITextField!
    @IBOutlet weak var inputFuelAlarm: UITextField!
    @IBOutlet weak var inputOxName: UITextField!
    @IBOutlet weak var inputFuelName: UITextField!
    @IBOutlet weak var switchName: UISwitch!
    
    
    var player: AVAudioPlayer?
    var timerOne: Timer?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        labelStatus.text = ""
        //housekeeping timer
        timerOne = Timer.scheduledTimer(timeInterval: 0.25, target: self, selector: #selector(self.housekeepingTimer), userInfo: nil, repeats: true)
        refreshView()
        refreshData()
        refreshInput()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        refreshInput()
        refreshView()
        refreshData()
    }
    
  
    @objc func housekeepingTimer() {
        if(working.viewConfigRefreshData) {refreshData()}
        if(working.viewConfigRefreshScreen) {refreshView()}
        
        // clear status
        if(working.statusTimeout < Date() && labelStatus.text != "") {
             labelStatus.text = ""
         }
         //update status
        if(working.statusTimeout > Date()) {
             labelStatus.text = working.status
         }
    }

    func refreshView() {
        labelOxSafety.text = configuration.oxTankName
        labelFuelSafety.text = configuration.fuelTankName
        labelHeliumSafety.text = configuration.pressureTankName
        working.viewConfigRefreshScreen = false
    }
    
    func refreshData() {
        if(padStatus.padHot) {
            labelSafetyPad.text = "HOT"
            labelSafetyPad.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        } else {
            labelSafetyPad.text = "SAFE"
            labelSafetyPad.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.padArmed) {
            imageArmedIcon.image = UIImage(named: "armed")
        } else {
            imageArmedIcon.image = UIImage(named: "disarm2")
        }
        updatePressure()
        updateConfig()
        working.viewConfigRefreshData = false
    }
    
    func updateConfig() {
        labelLoxFillActual.text = String(padStatus.oxFill)
        labelLoxAlarmActual.text = String(configuration.oxTankAlarm)
        labelFuelFillActual.text = String(padStatus.fuelFill)
        labelFuelAlarmActual.text = String(configuration.fuelTankAlarm)
    }
    
    func refreshInput() {
        inputLoxFill.text = String(padStatus.oxFill)
        inputLoxAlarm.text = String(configuration.oxTankAlarm)
        inputFuelFill.text = String(padStatus.fuelFill)
        inputFuelAlarm.text = String(configuration.fuelTankAlarm)
        inputOxName.text = configuration.oxTankName
        inputFuelName.text = configuration.fuelTankName
    }
    
    func updatePressure() {
        
        labelSafetyLox.text = String(padStatus.pressureOne)
        if(padStatus.pressureOne > configuration.oxTankAlarm) {
            labelSafetyLox.textColor = .red
        } else {
            labelSafetyLox.textColor = .black
        }
        labelSafetyFuel.text = String(padStatus.pressureTwo)
        if(padStatus.pressureTwo > configuration.fuelTankAlarm) {
            labelSafetyFuel.textColor = .red
        } else {
            labelSafetyFuel.textColor = .black
        }
        labelSafetyHelium.text = String(padStatus.pressureThree)
        if(padStatus.pressureThree > configuration.pressureTankAlarm) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
    }

    @IBAction func buttonSendSave(_ sender: Any) {
        var theErr: Bool = false
        if(switchSave.isOn) {
            var them: Int = 0
            var thes: String = ""
            var fuelF: String = "0"
            var loxF: String = "0"
            var fuelAlarm: Int = 0
            var loxAlarm: Int = 0
            //Lox Fill
            thes = inputLoxFill.text ?? "0"
            thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
            loxF = thes
            them = Int(thes) ?? 0
            if(them > 500 || them < 1) {
                theErr = true
                denyMessage(theText: "Lox fill out of range (1-500)")
            }
            //Fuel Fill
            thes = inputFuelFill.text ?? "0"
            thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
            them = Int(thes) ?? 0
            fuelF = thes
            if(them > 500 || them < 1) {
                theErr = true
                denyMessage(theText: "Fuel fill out of range (1-500)")
            }
            //Fuel Pressure Alarm
            thes = inputFuelAlarm.text ?? "0"
            thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
            them = Int(thes) ?? 0
            fuelAlarm = them
            if(them > 500 || them < 1) {
                theErr = true
                denyMessage(theText: "Fuel Alarm out of range (1-500)")
            }
            //Lox Pressure Alarm
            thes = inputLoxAlarm.text ?? "0"
            thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
            them = Int(thes) ?? 0
            loxAlarm = them
            if(them > 500 || them < 1) {
                theErr = true
                denyMessage(theText: "Fuel Alarm out of range (1-500)")
            }
            if(theErr == false) {
                working.radioMessage = "#SCFG," + loxF + "," + fuelF + ",!"  // SCFG,lox fill, fuel fill
                working.radioSend = true
                configuration.fuelTankAlarm = fuelAlarm
                configuration.oxTankAlarm = loxAlarm
                working.viewStatusRefreshScreen = true
                working.viewStatusRefreshData = true
                working.status = "Sent Config Change Request..."
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            }
            switchSave.isOn = false
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonChangeName(_ sender: Any) {
        var theRefresh: Bool = false
        if(switchName.isOn) {
            var thes: String = ""
            thes = inputOxName.text ?? "Lox"
            thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
            if(thes.count > 0 && thes.count < 7) {
                configuration.oxTankName = thes
                theRefresh = true
            } else {
                denyMessage(theText: "Ox name too long or short")
            }
            thes = inputFuelName.text ?? "Fuel"
            thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
            if(thes.count > 0 && thes.count < 9) {
                configuration.fuelTankName = thes
                theRefresh = true
            } else {
                denyMessage(theText: "Fuel name too long or short (1-8 char)")
            }
            if(theRefresh) {
                working.viewStatusRefreshScreen = true
                working.viewStatusRefreshData = true
                working.viewProcessRefreshScreen = true
                working.viewManualRefreshScreen = true
                working.viewRecoveryRefreshScreen = true
                working.viewLaunchRefreshScreen = true
                working.viewConfigRefreshScreen = true
                working.viewRadioRefreshScreen = true
                working.status = "Name changes confirmed"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            }
            
          switchName.isOn = false
        } else {
          denySend()
        }
        
    }
    
    
    
    
    @IBAction func selectorSwitch(_ sender: Any) {
        if(segmentSelector.selectedSegmentIndex != 1) {
            segmentSelector.selectedSegmentIndex = 1
        }
    }
    

    @IBAction func muteAlerts(_ sender: Any) {
        if(switchMuteAlerts.isOn) {
            configuration.mute = true
        } else {
            configuration.mute = false
        }
    }
    
    @IBAction func muteVoice(_ sender: Any) {
        if(switchMuteVoice.isOn) {
            configuration.voice = true
        } else {
            configuration.voice = false
        }
        
    }

    
    func denySend() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "You must unlock the safety before sending the request", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    
    func denyMessage(theText: String) { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: theText, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    
    @IBAction func changeRadioTab(_ sender: Any) {
        if(switchRadioTab.isOn) {
            
           // tabBarController?.viewControllers?.remove(at: index)
           // tabBarController?.tabBar.items[6].isHidden = false
            
            
        }
    }
    
}

