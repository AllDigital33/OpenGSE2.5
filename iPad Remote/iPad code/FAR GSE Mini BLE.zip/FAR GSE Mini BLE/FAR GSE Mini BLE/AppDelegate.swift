//
//  AppDelegate.swift
//  FAR Biprop Remote
//
//  Created by Brinker, Mike on 3/22/21.
//
//  TO DO LIST:
//     1) global variable structures  2) radio sentence structures  3) reset all  4) page/view timers and logic
//
//



/*
 
 Status data structure
 
 *      #S  Send full status
        #O# Open valve #
        #C# Close valve #
        #ARM1/0  Arm Haz and Ignitor
        #AH1/0 Arm Haz only / zzz
        #PC1 - close all valves
        #PF1 -
        #PF2 -
        #PO1 -
        #PO2 -
        #STOP Stop all process tasks
        #RON  Turn Recovery On
        #ROFF Turn Recovery Off
        #MON  Main Valves Open
        #MOFF Main Valves Closed
        #FIRE Ignitor Fire
        #ABORT  Abort
        #AC Abort Cancel
        #SETOX,#  Set Ox fill pressure
        #SETFU,#  Set Fuel fill pressure
        #SETPU,#  Set He fill pressure (unused now)

        * V1 = Fuel line vent
        * V2 = Fuel pnuematic disconnect valve
        * V3 = Ox line vent
        * V4 = Fuel pressurization valve (haz)
        * V5 = Ox pressurization valve (haz)
        * V6 = Ox pnuematic disconnect
        * V7 = Fuel rocket vent
        * V8 = Ox rocket vent
 

 
 */







import UIKit
import Foundation
import AVFoundation



@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        // Set font attributes for tab items
        let fontAttributes = [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 18)]
        // Apply the font attributes to the tab bar items
        UITabBarItem.appearance().setTitleTextAttributes(fontAttributes, for: .normal)
        // Optionally, apply the font attributes to the selected tab bar item
        UITabBarItem.appearance().setTitleTextAttributes(fontAttributes, for: .selected)
        
        
        
        
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }


}

struct configurationStruct {
    
    var oxTankName: String = "LOX"
    //var oxTankAlarm: Int = 415  //pressure in psi
    var fuelTankName: String = "Fuel"
    //var fuelTankAlarm: Int = 415 // pressure in psi
    var pressureTankName: String = "Helium"
    //var pressureTankAlarm: Int = 2500 // pressure in psi
    var rspareTankName: String = "Rspare"
    //var rspareTankAlarm: Int = 2500 // pressure in psi
    var valve9Name: String = "Valve 9"
    var minSafePressure: Int = 100 // green pressure
    var statusTimeout: Int = 20
    var mute: Bool = false
    var voice: Bool = false
    var BLEdevice: String = "null"
}

struct errorsStruct {
    
    var mainBatt: Int = 2
    var hazBatt: Int = 2
    var MCUtemp: Int = 2
    var PT: Int = 2
    var radio: Int = 2
    var flashMem: Int = 2
    var flashFull: Int = 2
    var ADC: Int = 2
    var MCUcrash: Int = 2
    var errorCount: Int = 0
    var BLEerror: Int = 2
    var BLEbatt: Int = 2
    var localRadio: Int = 2
    var iPadBatt: Int = 2
    
}

struct padConfigStruct {  // master configuration
    
    var POXenabled: Int = 1
    var POXrange: Int = 500
    var POXfill: Int = 100
    var POXalarm: Int = 425
    var PFLenabled: Int = 1
    var PFLrange: Int = 500
    var PFLfill: Int = 100
    var PFLalarm: Int = 425
    var PPSenabled: Int = 0
    var PPSrange: Int = 500
    var PPSalarm: Int = 425
    var PRSenabled: Int = 0
    var PRSrange: Int = 500
    var PRSalarm: Int = 425
    var lineVentDelay: Int = 5000
    var pressureWaitTime: Int = 2000
    var mainVoltage2412: Int = 24
    var hazVoltage2412: Int = 24
    var recoveryArmA: Int = 0
    var recoveryArmB: Int = 1
    var valve9: Int = 0
    var holdMainOn: Int = 1
    var holdMainOff: Int = 1
    var padRadioPower: Int = 1
    var remoteRadioPower: Int = 1
    var CPUtempAlarm: Int = 1
    var DAQauto: Int = 1
    var DAQtimeout: Int = 30000
    var updated: Int = 0
    
};


struct padStatusStruct {  // Main variables sent over radio to indicate pad status
    
    var tankConfig: Int = 2 // valid is 1,2,3
    var rocketConnected: Bool = false
    var padHot: Bool = false // pad safety plug in/out (haz 24v)
    var igniterArmed: Bool = false
    var valvesArmed: Bool = false
    var padArmed: Bool = false
    var igniterContinuity: Bool = false
    var mainVolts: Float = 0.0
    var hazVolts: Float = 0.0
    var pressureOne: Int = 0  // Ox Tank
    var pressureTwo: Int = 0  // Fuel Tank
    var pressureThree: Int = 0  // Pressure ground tank
    var pressureFour: Int = 0 // Pressure vehicle tank
    var tankTemperature: Int = 0 // Pressure tank temp
    var valveOne: Bool = false // closed = 0, open = 1
    var valveTwo: Bool = false
    var valveThree: Bool = false
    var valveFour: Bool = false
    var valveFive: Bool = false
    var valveSix: Bool = false
    var valveSeven: Bool = false
    var valveEight: Bool = false
    var valveNine: Bool = false
    var mainValvesOn: Bool = false
    var mainValvesOff: Bool = false
    var mainValvesState: Bool = false // 1 = open , 0 = closed
    var tankThreeActuatorOn: Bool = false
    var tankThreeActuatorOff: Bool = false
    var processC1: Int = 0  // can be 0- not run, 1 - complete, 2 - running, 3-stopped
    var processF1: Int = 0
    var processF2: Int = 0
    var processO1: Int = 0
    var processO2: Int = 0
    var processAbort: Int = 0
    var process7: Int = 0
    var process8: Int = 0
    var oxTankDisconnect: Bool = false
    var fuelTankDisconnect: Bool = false
    var pressureTankDisconnect: Bool = false
    var recoveryPower: Bool = false
    var altimeterAarmed: Bool = false
    var altimeterBarmed: Bool = false
    var CPUtemp: Int = 0
    var oxFill: Int = 400
    var fuelFill: Int = 400
    
}

struct workingStruct {
    var viewStatusRefreshData: Bool = false
    var viewStatusRefreshScreen: Bool = false
    var viewFilesRefreshData: Bool = false
    var viewFilesRefreshScreen: Bool = false
    var viewProcessRefreshData: Bool = false
    var viewProcessRefreshScreen: Bool = false
    var viewManualRefreshData: Bool = false
    var viewManualRefreshScreen: Bool = false
    var viewRecoveryRefreshData: Bool = false
    var viewRecoveryRefreshScreen: Bool = false
    var viewLaunchRefreshData: Bool = false
    var viewLaunchRefreshScreen: Bool = false
    var viewRadioRefreshData: Bool = false
    var viewRadioRefreshScreen: Bool = false
    var viewConfigRefreshData: Bool = false
    var viewConfigRefreshScreen: Bool = false
    var viewConfigRefreshConfig: Bool = false
    var viewHealthRefresh: Bool = false
    var oxAlarm: Int = 0  // 0 = off or reset, 1 = on, 2 = already activated
    var fuelAlarm: Int = 0  // 0 = off or reset, 1 = on, 2 = already activated
    var pressureAlarm: Int = 0  // 0 = off or reset, 1 = on, 2 = already activated
    
    var status: String = ""
    var statusTimeout: Date = Date()
    var configRetry: Date = Date()
    var lastStep: String = "Startup..."
    var radioConnected: Bool = false
    var RXarrowTimeout: Date = Date()
    var TXarrowTimeout: Date = Date()
    var radioSend: Bool = false
    var radioMessage: String = ""
    var lastRadio: Bool = false
    var lastRadioString: String = ""
    
    var radioRXarray = [String]()
    var radioLog: String = ""
    
    var countdownStart: Date = Date()
    var countdown: Bool = false
    var recoveryStartup: Date = Date()
    
    var firstContact: Bool = false
    var radioLastClock: Date = Date()
    
    var DAQrecording: Bool = false
    var DAQclock: Date = Date()
    
    var radioTab: Bool = true
    var filesTab: Bool = true
    var BLEstatus: Bool = false
    var BLEsearch: Bool = false
    var BLEdevices = [String]()
    var BLEbattery: Int = 0
    var BLEarm: Bool = false
    var iPadBatt: Int = 0
}

struct FTPStruct {
    var active: Bool = false
    var dir: Bool = false
    var fileName: String = " "
    var totalPackets: Int = 0
    var currentPacket: Int = 0
    var fileCount: Int = 0
    var lastRadio: Date = Date()
    var sendFlag: Bool = false
    var resend: Date = Date()
    var success: Bool = false
    var dirInit: Bool = false
    var fileList = [String]()
    var theIndex: Int = 999
    var refresh: Bool = false
}




var padStatus = padStatusStruct()
var configuration = configurationStruct()
var working = workingStruct()
var padConfig = padConfigStruct()
var errors = errorsStruct()
var FTPS = FTPStruct()
var timerFTP:  Timer?

var radioVC = RadioView() // used to show-hide radio tab
var DAQfilesVC = FilesView() // used to show-hide radio tab

let synthesizer = AVSpeechSynthesizer()



// ****************************************************  RADIO PROCESSING *****************************************

func processRadio(theData: String) -> Int {
    
    var malformed: Bool = false
    var BLEcommand: Bool = false
    
    //now check for length
    if(theData.count > 180 || theData.count < 5) {
        malformed = true
        working.radioRXarray.append("MALFORMED! (size - previous radio sentence)")
        return 0
    }
    if(malformed == false) {
        
        //now convert to array
        let tempArray = theData.components(separatedBy: ",")
        
        if(tempArray[0].prefix(2) == "#B") {
            BLEcommand = true
        } else {
            working.radioLastClock = Date()
        }
    
        if(!working.firstContact && !BLEcommand) {
            working.firstContact = true
            working.status = "Received first radio contact"
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
        }
        
        //now process message type (check length first)
        
        if(tempArray[0] == "#FS") { //recieved full status from pad
            if(tempArray.count == 47) {
            processStatus(theArr: tempArray)
            refreshAllData()
            return 1
            } else {
                malformed = true
                working.radioRXarray.append("MALFORMED! (wrong array size)")
                return 0
            }
        }
        
        if(tempArray[0] == "#PRS") { //recieved just pressure status from pad
            if(tempArray.count == 6) {
            processPressure(theArr: tempArray)
            refreshAll()
            return 2
        } else {
            malformed = true
            working.radioRXarray.append("MALFORMED! (wrong array size)")
            return 0
        }
        }
        
        if(tempArray[0] == "#CFG") { //recieved full configuration from pad
            if(tempArray.count == 28) {
            processConfig(theArr: tempArray)
            working.viewConfigRefreshConfig = true
            refreshAll()
            return 2
        } else {
            malformed = true
            working.radioRXarray.append("MALFORMED #CFG! (wrong array size Rx)")
            return 0
        }
        }
        
        if(tempArray[0] == "#HER") { //recieved just pressure status from pad
            if(tempArray.count == 12) {
            processHealth(theArr: tempArray)
            refreshAll()
                working.viewHealthRefresh = true
            return 2
        } else {
            malformed = true
            working.radioRXarray.append("MALFORMED! (wrong array size)")
            return 0
        }
        }
        
        if(tempArray[0] == "#M") { //got a message
            processMessage(theArr: tempArray)
            return 3
        }
        
        if(tempArray[0] == "#DON") { //got a message
            
            working.status = "DAQ is now recording"
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            if(!working.DAQrecording) {working.DAQclock = Date()}
            working.DAQrecording = true
            return 3
        }
        if(tempArray[0] == "#DOFF") { //got a message
            working.DAQrecording = false
            working.status = "DAQ stopped recording"
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            return 3
        }
        
        if(tempArray[0] == "#BM") { //got a message from BLE bridge
            processMessage(theArr: tempArray)
            print("got bluetooth message")
            return 3 // silent
        }
        if(tempArray[0] == "#BV") { //got battery voltage % from BLE bridge
            working.BLEbattery = Int(tempArray[1]) ?? 0
            if(working.BLEbattery > 0 && working.BLEbattery < 10) {
                errors.errorCount = 1
                errors.BLEbatt = 1
            } else {
                errors.BLEbatt = 0
            }
            return 9 //silent
        }
        if(tempArray[0] == "#BRE") { //got Local Radio Error from Bluetooth Bridge
            errors.localRadio = Int(tempArray[1]) ?? 0
            if(errors.localRadio == 1) {
                errors.errorCount = 1
            }
            print("set BRE")
            return 9 //silent
        }
        
    }
    return 99 //not malformed but nothing to do
}

// ****************************************************  FTP PROCESSING *****************************************

func processFTP(theData: String) -> Int {
    
    var malformed: Bool = false
    //now check for length
    if(theData.count > 150 || theData.count < 3) {
        malformed = true
        working.radioRXarray.append("MALFORMED! (size - previous radio sentence)")
        return 0
    }
    if(malformed == false) {
        FTPS.lastRadio = Date()
        working.radioLastClock = Date()
        //now convert to array
        let tempArray = theData.components(separatedBy: "~")  // FTP uses tilda as separator
        
        if(tempArray[0] == "$DIR") { //recieved Dir summary from MCU
          processFTPdirectory(theArr: tempArray)
            FTPS.success = false;
          return 5
        }
        if(tempArray[0] == "$START") { //recieved Dir summary from MCU
          processFile(theArr: tempArray)
            FTPS.success = false;
          return 5
        }
        if(tempArray[0] == "$FILE") { //recieved a chunk of file from MCU
          processFTPfile(theArr: tempArray)
          return 5
        }
        
    }
  return 99
}

func processFile(theArr: [String]) {
    
    let theGood: Int = Int(theArr[1]) ?? 0
    if(theGood != 1) {
        working.status = "Bad File Name on MCU - Aborting"
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
    } else {
        working.status = "Transferring File"
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
        
        let filename: String = FTPS.fileName
        let saveFile = saveFileURL(fileN: filename)
        if FileManager.default.fileExists(atPath: saveFile!.path) {
            // Delete file
            try? FileManager.default.removeItem(atPath: saveFile!.path)
        } else {
            print("File does not exist")
        }
        
        FTPS.totalPackets = Int(theArr[2]) ?? 0
        FTPS.currentPacket = 1
        FTPS.dir = false // only in file mode
        FTPS.active = true
        FTPS.sendFlag = true
        FTPS.resend = Date() + 3
        // also turns on a FTPtimer in SummaryView
    }
}


func processFTPdirectory(theArr: [String]) {
    
    if(Int(theArr[1]) == 0) {
        working.status = "MCU File List is Empty"
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
        working.viewFilesRefreshData = true
        FTPS.fileCount = 0
        FTPS.refresh = true
        return
    }
    
    working.status = "Refreshing MCU Files List"
    working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
    
    FTPS.fileName = "tempdir.tmp"
    let filename: String = FTPS.fileName
    let saveFile = saveFileURL(fileN: filename)
    if FileManager.default.fileExists(atPath: saveFile!.path) {
        // Delete file
        try? FileManager.default.removeItem(atPath: saveFile!.path)
    } else {
        print("File does not exist")
    }
    
    FTPS.totalPackets = Int(theArr[2]) ?? 0
    FTPS.fileCount = Int(theArr[1]) ?? 0
    FTPS.currentPacket = 1
    FTPS.dir = true // set to files refresh mode
    FTPS.active = true
    FTPS.sendFlag = true
    FTPS.resend = Date() + TimeInterval(3)
    // also turns on a FTPtimer in SummaryView

}

func sendTimer() { // sends and resends requests to MCU
    
        if(FTPS.sendFlag) {
            FTPS.sendFlag = false
            working.radioMessage = "$SEND," + FTPS.fileName + "," + String(FTPS.currentPacket) + ",!"
            working.radioSend = true
            FTPS.resend = Date() + TimeInterval(3)
        }
        if(Date() > FTPS.resend) {
            FTPS.sendFlag = true
            FTPS.resend = Date() + TimeInterval(3)
        }
}

func processFTPfile(theArr: [String]) {
    
    
    if(Int(theArr[1]) == FTPS.currentPacket) {  // yay got what we needed
        //------ Write the chunk to the local file
        let filename: String = FTPS.fileName
        let saveFile = saveFileURL(fileN: filename)
        let saveLine: String = theArr[2]
        let data = (saveLine).data(using: String.Encoding.utf8)
        if FileManager.default.fileExists(atPath: saveFile!.path) {
            if let fileHandle = try? FileHandle(forWritingTo: saveFile!)          {
                fileHandle.seekToEndOfFile()
                fileHandle.write(data!)
                fileHandle.closeFile()
            }
        } else {
            try? data!.write(to: saveFile!, options: .atomicWrite)
        }
        //----- increment and send -------------------
        if(Int(theArr[1]) == FTPS.totalPackets) {
            FTPS.active = false
            FTPS.dir = false
            working.radioMessage = "$DONE,33,!"
            FTPS.success = true;
            working.radioSend = true
            working.status = "FTP Process Complete"
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            return
        } else {
            FTPS.currentPacket = FTPS.currentPacket + 1
            FTPS.sendFlag = true
        }
    }
}



func saveFileURL(fileN: String) -> URL? {
    guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return nil }
    return documentsDirectory.appendingPathComponent(fileN)
    }


// ****************************************************       *****************************************

func refreshAll() {
    working.viewStatusRefreshScreen = true
    working.viewProcessRefreshScreen = true
    working.viewManualRefreshScreen = true
    working.viewFilesRefreshScreen = true
    working.viewRecoveryRefreshScreen = true
    working.viewLaunchRefreshScreen = true
    working.viewRadioRefreshScreen = true
    working.viewConfigRefreshScreen = true
    
    working.viewProcessRefreshData = true
    working.viewStatusRefreshData = true
    working.viewManualRefreshData = true
    working.viewRecoveryRefreshData = true
    working.viewLaunchRefreshData = true
    working.viewConfigRefreshData = true
    working.viewRadioRefreshData = true
    working.viewFilesRefreshData = true
}

func refreshAllData() {
    
    working.viewStatusRefreshScreen = true
    
    working.viewProcessRefreshData = true
    working.viewStatusRefreshData = true
    working.viewManualRefreshData = true
    working.viewRecoveryRefreshData = true
    working.viewLaunchRefreshData = true
    working.viewConfigRefreshData = true
    working.viewRadioRefreshData = true
    working.viewFilesRefreshData = true
    
}



func processStatus(theArr: [String]) {
    
    padStatus.tankConfig = Int(theArr[1]) ?? 0
    if(intToBool(theVal: theArr[2]) == true && padStatus.rocketConnected == false) { speakNow(theMessage: "Rocket umbilical is now connected") }
    if(intToBool(theVal: theArr[2]) == false && padStatus.rocketConnected == true) { speakNow(theMessage: "Rocket umbilical disconnected") }
    padStatus.rocketConnected = intToBool(theVal: theArr[2])
    if(intToBool(theVal: theArr[3]) == true && padStatus.padHot == false) { speakNow(theMessage: "Warning, Pad Controller is now hot") }
    if(intToBool(theVal: theArr[3]) == false && padStatus.padHot == true) { speakNow(theMessage: "Pad Controller is now safe") }
    padStatus.padHot = intToBool(theVal: theArr[3])
    padStatus.igniterArmed = intToBool(theVal: theArr[6])  // no longer using igniter armed, so switched to pad armed
    padStatus.valvesArmed = intToBool(theVal: theArr[5])
    if(intToBool(theVal: theArr[6]) == true && padStatus.padArmed == false) { speakNow(theMessage: "Pad Controller Armed") }
    if(intToBool(theVal: theArr[6]) == false && padStatus.padArmed == true) { speakNow(theMessage: "Pad Controller Disarmed") }
    padStatus.padArmed = intToBool(theVal: theArr[6])
    padStatus.igniterContinuity = intToBool(theVal: theArr[7])
    padStatus.mainVolts = Float(theArr[8])!
    padStatus.hazVolts = Float(theArr[9])!
    if(padStatus.hazVolts < 2.0) {padStatus.hazVolts = 0.0 }
    padStatus.pressureOne = Int(theArr[11]) ?? 0 // Ox Tank
    padStatus.pressureTwo = Int(theArr[12]) ?? 0 // Fuel Tank
    padStatus.pressureThree = Int(theArr[10]) ?? 0  // Pressure ground tank
    padStatus.pressureFour = Int(theArr[13]) ?? 0 // Pressure vehicle tank
    padStatus.tankTemperature = Int(theArr[14]) ?? 0 // Pressure tank temp
    padStatus.valveOne = intToBool(theVal: theArr[15])
    padStatus.valveTwo = intToBool(theVal: theArr[16])
    padStatus.valveThree = intToBool(theVal: theArr[17])
    padStatus.valveFour = intToBool(theVal: theArr[18])
    padStatus.valveFive = intToBool(theVal: theArr[19])
    padStatus.valveSix = intToBool(theVal: theArr[20])
    padStatus.valveSeven = intToBool(theVal: theArr[21])
    padStatus.valveEight = intToBool(theVal: theArr[22])
    padStatus.valveNine = intToBool(theVal: theArr[23])
    padStatus.mainValvesOn = intToBool(theVal: theArr[24])
    padStatus.mainValvesOff = intToBool(theVal: theArr[25])
    padStatus.mainValvesState = intToBool(theVal: theArr[26])
    padStatus.tankThreeActuatorOn = intToBool(theVal: theArr[27])
    padStatus.tankThreeActuatorOff = intToBool(theVal: theArr[28])
    padStatus.processC1 = Int(theArr[29]) ?? 0  // can be 0- not run, 1 - complete, 2 - running, 3-stopped
    padStatus.processF1 = Int(theArr[30]) ?? 0
    padStatus.processF2 = Int(theArr[31]) ?? 0
    padStatus.processO1 = Int(theArr[32]) ?? 0
    padStatus.processO2 = Int(theArr[33]) ?? 0
    padStatus.processAbort = Int(theArr[34]) ?? 0
    padStatus.process7 = Int(theArr[35]) ?? 0
    padStatus.process8 = Int(theArr[36]) ?? 0
    padStatus.oxTankDisconnect = intToBool(theVal: theArr[37])
    padStatus.fuelTankDisconnect = intToBool(theVal: theArr[38])
    padStatus.pressureTankDisconnect = intToBool(theVal: theArr[39])
    if(padStatus.recoveryPower == false && intToBool(theVal: theArr[40]) == true) {
        working.recoveryStartup = (Date() + TimeInterval(210)) //3:30 minute warmup on recovery
    }
    padStatus.recoveryPower = intToBool(theVal: theArr[40])
    if(intToBool(theVal: theArr[40]) == true) { // power is on
        let altA: Bool = intToBool(theVal: theArr[41])
        let altB: Bool = intToBool(theVal: theArr[42])
        if(padConfig.recoveryArmA == 1 && padConfig.recoveryArmB == 1) { // requires both
            if(altA && altB && (padStatus.altimeterAarmed == false || padStatus.altimeterBarmed == false)) { speakNow(theMessage: "Recovery Altimeters Armed") }
        }
        if(padConfig.recoveryArmA == 1 && padConfig.recoveryArmB == 0) { // requires A
            if(altA && padStatus.altimeterAarmed == false) { speakNow(theMessage: "Recovery Altimeter Armed") }
        }
        if(padConfig.recoveryArmA == 0 && padConfig.recoveryArmB == 1) { // requires A
            if(altB && padStatus.altimeterBarmed == false) { speakNow(theMessage: "Recovery Altimeter Armed") }
        }
    }
    
    padStatus.altimeterAarmed = intToBool(theVal: theArr[41])
    padStatus.altimeterBarmed = intToBool(theVal: theArr[42])
    padStatus.CPUtemp = Int(theArr[43]) ?? 0
    padStatus.oxFill = Int(theArr[44]) ?? 0
    padStatus.fuelFill = Int(theArr[45]) ?? 0
    
    
}

func processConfig(theArr: [String]) {
    
    padConfig.POXenabled = Int(theArr[1]) ?? 0
    padConfig.POXrange = Int(theArr[2]) ?? 0
    padConfig.POXfill = Int(theArr[3]) ?? 0
    padStatus.oxFill = padConfig.POXfill
    padConfig.POXalarm = Int(theArr[4]) ?? 0
    padConfig.PFLenabled = Int(theArr[5]) ?? 0
    padConfig.PFLrange = Int(theArr[6]) ?? 0
    padConfig.PFLfill = Int(theArr[7]) ?? 0
    padStatus.fuelFill = padConfig.PFLfill
    padConfig.PFLalarm = Int(theArr[8]) ?? 0
    padConfig.PPSenabled = Int(theArr[9]) ?? 0
    padConfig.PPSrange = Int(theArr[10]) ?? 0
    padConfig.PPSalarm = Int(theArr[11]) ?? 0
    padConfig.PRSenabled = Int(theArr[12]) ?? 0
    padConfig.PRSrange = Int(theArr[13]) ?? 0
    padConfig.PRSalarm = Int(theArr[14]) ?? 0
    padConfig.pressureWaitTime = Int(theArr[15]) ?? 0
    padConfig.lineVentDelay = Int(theArr[16]) ?? 0
    padConfig.mainVoltage2412 = Int(theArr[17]) ?? 0
    padConfig.hazVoltage2412 = Int(theArr[18]) ?? 0
    padConfig.recoveryArmA = Int(theArr[19]) ?? 0
    padConfig.recoveryArmB = Int(theArr[20]) ?? 0
    padConfig.valve9 = Int(theArr[21]) ?? 0
    padConfig.holdMainOn = Int(theArr[22]) ?? 0
    padConfig.holdMainOff = Int(theArr[23]) ?? 0
    padConfig.padRadioPower = Int(theArr[24]) ?? 0
    padConfig.remoteRadioPower = Int(theArr[25]) ?? 0
    padConfig.CPUtempAlarm = Int(theArr[26]) ?? 0
    padConfig.updated = 1
    
    readLocalConfig()
    
    working.status = "Received full configuration"
    working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))

}

func processHealth(theArr: [String]) {
 
    errors.errorCount = Int(theArr[1]) ?? 0
    errors.mainBatt = Int(theArr[2]) ?? 0
    errors.hazBatt = Int(theArr[3]) ?? 0
    errors.MCUtemp = Int(theArr[4]) ?? 0
    errors.PT = Int(theArr[5]) ?? 0
    errors.radio = Int(theArr[6]) ?? 0
    errors.flashMem = Int(theArr[7]) ?? 0
    errors.flashFull = Int(theArr[8]) ?? 0
    errors.ADC = Int(theArr[9]) ?? 0
    errors.MCUcrash = Int(theArr[10]) ?? 0
    
}


func processPressure(theArr: [String]) {
    
    padStatus.pressureOne = Int(theArr[2]) ?? 0 // Ox Tank
    padStatus.pressureTwo = Int(theArr[3]) ?? 0 // Fuel Tank
    padStatus.pressureThree = Int(theArr[1]) ?? 0  // Pressure ground tank
    padStatus.pressureFour = Int(theArr[4]) ?? 0 // Pressure vehicle tank
}

func intToBool(theVal: String) -> Bool {
    if(theVal == "1") {
        return true
    } else {
        return false
    }
    
}

func processMessage(theArr: [String]) {
    working.status = theArr[1]
    working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
}





//*********************************




func speakNow(theMessage: String) {
    if(!configuration.voice) {
        //let synthesizer = AVSpeechSynthesizer() -- this had to move up in iOS16
        let utterance = AVSpeechUtterance(string: theMessage)
        
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        synthesizer.speak(utterance)
        
    }
}

//==========================================

func configFileURL(fileN: String) -> URL? {
    guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return nil }
    return documentsDirectory.appendingPathComponent(fileN)
    }

func readLocalConfig() {
    
    let filename: String = "config.txt"
    let configFile = configFileURL(fileN: filename)
    var theLine: String = ""
    if FileManager.default.fileExists(atPath: configFile!.path) {
        do {
         // Get the saved data
            let savedData = try Data(contentsOf: configFile!)
         // Convert the data back into a string
         if let savedString = String(data: savedData, encoding: .utf8) {
             theLine = savedString
         }
        } catch {
         // Catch any errors
         print("Unable to read the file")
        }
        print("Read Local Config")
        print(theLine)
        // now process the line
        let tempArray = theLine.components(separatedBy: ",")
        if(tempArray.count > 0) {configuration.oxTankName = tempArray[0]}
        if(tempArray.count > 1) {configuration.fuelTankName = tempArray[1]}
        if(tempArray.count > 2) {configuration.rspareTankName = tempArray[2]}
        if(tempArray.count > 3) {configuration.pressureTankName = tempArray[3]}
        if(tempArray.count > 4) {configuration.BLEdevice = tempArray[4]}
        if(tempArray.count > 5) {configuration.valve9Name = tempArray[5]}
        refreshAll()
    }

}
