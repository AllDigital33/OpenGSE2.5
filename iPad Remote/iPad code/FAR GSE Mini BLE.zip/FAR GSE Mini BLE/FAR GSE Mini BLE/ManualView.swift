//
//  ManualView.swift
//  FAR Biprop Remote
//
//  Created by Brinker, Mike on 3/23/21.
//
/*
* V1 = Fuel line vent
* V2 = Fuel pnuematic disconnect valve
* V3 = Ox line vent
* V4 = Fuel pressurization valve (haz)
* V5 = Ox pressurization valve (haz)
* V6 = Ox pnuematic disconnect
* V7 = Fuel rocket vent
* V8 = Ox rocket vent
*/

import Foundation
import AVFoundation
import UIKit

class ManualView: UIViewController {

    @IBOutlet weak var labelStatus: UILabel!
    @IBOutlet weak var labelOneStatus: UILabel!
    @IBOutlet weak var labelTwoStatus: UILabel!
    @IBOutlet weak var labelThreeStatus: UILabel!
    @IBOutlet weak var labelFourStatus: UILabel!
    @IBOutlet weak var labelFiveStatus: UILabel!
    @IBOutlet weak var labelSixStatus: UILabel!
    @IBOutlet weak var labelSevenStatus: UILabel!
    @IBOutlet weak var labelEightStatus: UILabel!
    @IBOutlet weak var imageStatusOne: UIImageView!
    @IBOutlet weak var imageStatusTwo: UIImageView!
    @IBOutlet weak var imageStatusThree: UIImageView!
    @IBOutlet weak var imageStatusFour: UIImageView!
    @IBOutlet weak var imageStatusFive: UIImageView!
    @IBOutlet weak var imageStatusSix: UIImageView!
    @IBOutlet weak var imageStatusSeven: UIImageView!
    @IBOutlet weak var imageStatusEight: UIImageView!
    @IBOutlet weak var buttonOne: UIButton!
    @IBOutlet weak var buttonTwo: UIButton!
    @IBOutlet weak var buttonThree: UIButton!
    @IBOutlet weak var buttonFour: UIButton!
    @IBOutlet weak var buttonFive: UIButton!
    @IBOutlet weak var buttonSix: UIButton!
    @IBOutlet weak var buttonSeven: UIButton!
    @IBOutlet weak var buttonEight: UIButton!
    @IBOutlet weak var switchOne: UISwitch!
    @IBOutlet weak var switchTwo: UISwitch!
    @IBOutlet weak var switchThree: UISwitch!
    @IBOutlet weak var switchFour: UISwitch!
    @IBOutlet weak var switchFive: UISwitch!
    @IBOutlet weak var switchSix: UISwitch!
    @IBOutlet weak var switchSeven: UISwitch!
    @IBOutlet weak var switchEight: UISwitch!

    @IBOutlet weak var labelSafetyPad: UILabel!
    @IBOutlet weak var labelSafetyLox: UILabel!
    @IBOutlet weak var labelSafetyFuel: UILabel!
    @IBOutlet weak var labelSafetyHelium: UILabel!
    @IBOutlet weak var labelOxSafety: UILabel!
    @IBOutlet weak var labelFuelSafety: UILabel!
    
    @IBOutlet weak var labelPressureSafety: UILabel!
    @IBOutlet weak var imageArmedIcon: UIImageView!
    @IBOutlet weak var labelArmedStatus: UILabel!
    @IBOutlet weak var buttonArm: UIButton!
    @IBOutlet weak var switchArm: UISwitch!
    @IBOutlet weak var labelSwitchNine: UISwitch!
    @IBOutlet weak var buttonNine: UIButton!
    @IBOutlet weak var imageStatusNine: UIImageView!
    @IBOutlet weak var labelNineStatus: UILabel!
    
    @IBOutlet weak var switchSpareNine: UISwitch!
    @IBOutlet weak var buttonSpareNine: UIButton!
    @IBOutlet weak var imageSpareNine: UIImageView!
    @IBOutlet weak var labelSpareNine: UILabel!
    @IBOutlet weak var labelHeaderSpareNine: UILabel!
    
    
    @IBOutlet weak var labelFuelLine: UILabel!
    @IBOutlet weak var labelFuelPressurization: UILabel!
    @IBOutlet weak var labelFuelPneumatic: UILabel!
    @IBOutlet weak var labelFuelRocket: UILabel!
    @IBOutlet weak var labelLoxLine: UILabel!
    @IBOutlet weak var labelLoxPressurization: UILabel!
    @IBOutlet weak var labelLoxPnuematic: UILabel!
    @IBOutlet weak var labelLoxRocket: UILabel!
    @IBOutlet weak var button9: UIButton!
    @IBOutlet weak var button10: UIButton!
    @IBOutlet weak var labelRadioTimer: UILabel!
    @IBOutlet weak var labelSafetyPRS: UILabel!
    @IBOutlet weak var labelSafetyPRSvalue: UILabel!
    @IBOutlet weak var imageNoSync: UIImageView!
    @IBOutlet weak var buttonErrors: UIButton!
    
    var player: AVAudioPlayer?
    var timerOne: Timer?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        buttonOne.layer.cornerRadius = 6
        buttonTwo.layer.cornerRadius = 6
        buttonThree.layer.cornerRadius = 6
        buttonFour.layer.cornerRadius = 6
        buttonFive.layer.cornerRadius = 6
        buttonSix.layer.cornerRadius = 6
        buttonSeven.layer.cornerRadius = 6
        buttonEight.layer.cornerRadius = 6
        buttonNine.layer.cornerRadius = 6
        button10.layer.cornerRadius = 6
        buttonSpareNine.layer.cornerRadius = 6
        buttonArm.layer.cornerRadius = 6
        labelStatus.text = ""
        //housekeeping timer
        timerOne = Timer.scheduledTimer(timeInterval: 0.25, target: self, selector: #selector(self.housekeepingTimer), userInfo: nil, repeats: true)
        refreshView()
        refreshData()
        
        
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(false)
        refreshView()
        refreshData()

        
    }
    
    @objc func housekeepingTimer() {
        if(working.viewManualRefreshData) {refreshData()}
        if(working.viewManualRefreshScreen) {refreshView()}
        
        // clear status
        if(working.statusTimeout < Date() && labelStatus.text != "") {
             labelStatus.text = ""
         }
         //update status
        if(working.statusTimeout > Date()) {
             labelStatus.text = working.status
         }
        radioLast() // update radio last counter
        
        if(errors.errorCount > 0) {
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
    }

    //===================================  REFRESH HERE ================================================
    
    func radioLast() {
        
        if(working.firstContact) {
            let theDiff: Int = getDateDiff(start: working.radioLastClock, end: Date())
            labelRadioTimer.text = String(theDiff)
        } else {
            labelRadioTimer.text = String("N/A")
        }
    }
    func getDateDiff(start: Date, end: Date) -> Int  {
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([Calendar.Component.second], from: start, to: end)
        let seconds = dateComponents.second
        return Int(seconds!)
    }
    
    func refreshView() {
        labelOxSafety.text = configuration.oxTankName
        labelFuelSafety.text = configuration.fuelTankName
        labelPressureSafety.text = configuration.pressureTankName
        labelSafetyPRS.text = configuration.rspareTankName
        working.viewManualRefreshScreen = false
        
        labelFuelLine.text = configuration.fuelTankName + " line vent valve"
        labelFuelPressurization.text = configuration.fuelTankName + " pressurization valve"
        labelFuelPneumatic.text = configuration.fuelTankName + " pneumatic disconnect valve"
        labelFuelRocket.text = configuration.fuelTankName + " rocket vent valve"
        labelLoxLine.text = configuration.oxTankName + " line vent valve"
        labelLoxPressurization.text = configuration.oxTankName + " pressurization valve"
        labelLoxPnuematic.text = configuration.oxTankName + " pneumatic disconnect valve"
        labelLoxRocket.text = configuration.oxTankName + " rocket vent valve"
        if(padConfig.valve9 == 1) {
            switchSpareNine.isHidden = false
            buttonSpareNine.isHidden = false
            imageSpareNine.isHidden = false
            labelHeaderSpareNine.text = configuration.valve9Name + " valve"
            labelSpareNine.isHidden = false
            labelHeaderSpareNine.isHidden = false
        } else {
            switchSpareNine.isHidden = true
            buttonSpareNine.isHidden = true
            imageSpareNine.isHidden = true
            labelSpareNine.isHidden = true
            labelHeaderSpareNine.isHidden = true
        }
    }
    
    func refreshData() {
        
        // ---------------- Standard Header
        if(padStatus.padHot) {
            labelSafetyPad.text = "HOT"
            labelSafetyPad.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        } else {
            labelSafetyPad.text = "SAFE"
            labelSafetyPad.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.padArmed) {
            imageArmedIcon.image = UIImage(named: "armed")
        } else {
            imageArmedIcon.image = UIImage(named: "disarm2")
        }
        if(errors.errorCount > 0) {
            buttonErrors.setTitle(" ", for: .normal)
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
        if(padConfig.updated == 1) {
            imageNoSync.isHidden = true
        } else {
            imageNoSync.isHidden = false
        }
        // ---------------- end standard header
        
        if(padStatus.padArmed) {
            labelArmedStatus.text = "ARMED"
            labelArmedStatus.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
            buttonArm.setTitle("DISARM", for: .normal)
        } else {
            labelArmedStatus.text = "DISARMED"
            labelArmedStatus.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
            buttonArm.setTitle("ARM", for: .normal)
        }
        updatePressure()
        // ------------------------ Valves --------------------------
        //    * V1 = Fuel line vent
        //    * V2 = Fuel pnuematic disconnect valve
        //    * V3 = Ox line vent
        //    * V4 = Fuel pressurization valve (haz)
        //    * V5 = Ox pressurization valve (haz)
        //    * V6 = Ox pnuematic disconnect
        //    * V7 = Fuel rocket vent
        //    * V8 = Ox rocket vent
     
        //------------ Fuel Line Vent --------------------------
        if(padStatus.valveOne) {
            buttonOne.setTitle("Close", for: .normal)
            imageStatusOne.image = UIImage(named: "open2")
            labelOneStatus.text = "Open"
        } else {
            buttonOne.setTitle("Open", for: .normal)
            imageStatusOne.image = UIImage(named: "closed")
            labelOneStatus.text = "Closed"
        }
        //------------ Fuel  Pressurization --------------------------
        if(padStatus.valveFour) {
            buttonTwo.setTitle("Close", for: .normal)
            imageStatusTwo.image = UIImage(named: "open2")
            labelTwoStatus.text = "Open"
        } else {
            buttonTwo.setTitle("Open", for: .normal)
            imageStatusTwo.image = UIImage(named: "closed")
            labelTwoStatus.text = "Closed"
        }
        //------------ Fuel Pneumatic Disconnect --------------------------
        if(padStatus.valveTwo) {
            buttonThree.setTitle("Close", for: .normal)
            imageStatusThree.image = UIImage(named: "open2")
            labelThreeStatus.text = "Open"
        } else {
            buttonThree.setTitle("Open", for: .normal)
            imageStatusThree.image = UIImage(named: "closed")
            labelThreeStatus.text = "Closed"
        }
        //------------ Fuel Rocket Vent Valve --------------------------
        if(padStatus.valveSeven) {
            buttonEight.setTitle("Close", for: .normal)
            imageStatusEight.image = UIImage(named: "open2")
            labelEightStatus.text = "Open"
        } else {
            buttonEight.setTitle("Open", for: .normal)
            imageStatusEight.image = UIImage(named: "closed")
            labelEightStatus.text = "Closed"
        }
        //------------ OX line vent valve --------------------------
        if(padStatus.valveThree) {
            buttonFour.setTitle("Close", for: .normal)
            imageStatusFour.image = UIImage(named: "open2")
            labelFourStatus.text = "Open"
        } else {
            buttonFour.setTitle("Open", for: .normal)
            imageStatusFour.image = UIImage(named: "closed")
            labelFourStatus.text = "Closed"
        }
        //------------ OX pressurization --------------------------
        if(padStatus.valveFive) {
            buttonFive.setTitle("Close", for: .normal)
            imageStatusFive.image = UIImage(named: "open2")
            labelFiveStatus.text = "Open"
        } else {
            buttonFive.setTitle("Open", for: .normal)
            imageStatusFive.image = UIImage(named: "closed")
            labelFiveStatus.text = "Closed"
        }
        //------------ OX pneumatic --------------------------
        if(padStatus.valveSix) {
            buttonSix.setTitle("Close", for: .normal)
            imageStatusSix.image = UIImage(named: "open2")
            labelSixStatus.text = "Open"
        } else {
            buttonSix.setTitle("Open", for: .normal)
            imageStatusSix.image = UIImage(named: "closed")
            labelSixStatus.text = "Closed"
        }
        //------------ OX rocket vent valve --------------------------
        if(padStatus.valveEight) {
            buttonSeven.setTitle("Close", for: .normal)
            imageStatusSeven.image = UIImage(named: "open2")
            labelSevenStatus.text = "Open"
        } else {
            buttonSeven.setTitle("Open", for: .normal)
            imageStatusSeven.image = UIImage(named: "closed")
            labelSevenStatus.text = "Closed"
        }
        //------------ Main Valves --------------------------
        if(padStatus.mainValvesState) {
            //buttonNine.setTitle("Close", for: .normal)
            imageStatusNine.image = UIImage(named: "open2")
            labelNineStatus.text = "Open"
        } else {
            //buttonNine.setTitle("Open", for: .normal)
            imageStatusNine.image = UIImage(named: "closed")
            labelNineStatus.text = "Closed"
        }
        //------------ Spare #9 valve --------------------------
        if(padStatus.valveNine) {
            buttonSpareNine.setTitle("Close", for: .normal)
            imageSpareNine.image = UIImage(named: "open2")
            labelSpareNine.text = "Open"
        } else {
            buttonSpareNine.setTitle("Open", for: .normal)
            imageSpareNine.image = UIImage(named: "closed")
            labelSpareNine.text = "Closed"
        }
    
        working.viewManualRefreshData = false
    }
    
    func updatePressure() {
        
        // =====================================   Standard header
        if(padConfig.POXenabled == 1){
            labelSafetyLox.isHidden = false
            labelOxSafety.isHidden = false
        } else {
            labelSafetyLox.isHidden = true
            labelOxSafety.isHidden = true
        }
        if(padStatus.pressureOne == 99999) {
            labelSafetyLox.text = String("ERR")
        } else {
            labelSafetyLox.text = String(padStatus.pressureOne)
        }
        if(padStatus.pressureOne > padConfig.POXalarm || padStatus.pressureOne == 99999) {
            labelSafetyLox.textColor = .red
        } else {
            labelSafetyLox.textColor = .black
        }
        //-----
        if(padConfig.PFLenabled == 1){
            labelSafetyFuel.isHidden = false
            labelFuelSafety.isHidden = false
        } else {
            labelSafetyFuel.isHidden = true
            labelFuelSafety.isHidden = true
        }
        if(padStatus.pressureTwo == 99999) {
            labelSafetyFuel.text = String("ERR")
        } else {
            labelSafetyFuel.text = String(padStatus.pressureTwo)
        }
        if(padStatus.pressureTwo > padConfig.PFLalarm || padStatus.pressureTwo == 99999) {
            labelSafetyFuel.textColor = .red
        } else {
            labelSafetyFuel.textColor = .black
        }
        //------
        if(padConfig.PPSenabled == 1){
            labelSafetyHelium.isHidden = false
            labelPressureSafety.isHidden = false
        } else {
            labelSafetyHelium.isHidden = true
            labelPressureSafety.isHidden = true
        }
        if(padStatus.pressureThree == 99999) {
            labelSafetyHelium.text = String("ERR")
        } else {
            labelSafetyHelium.text = String(padStatus.pressureThree)
        }
        if(padStatus.pressureThree > padConfig.PPSalarm || padStatus.pressureThree == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        if(padConfig.PRSenabled == 1){
            labelSafetyPRS.isHidden = false
            labelSafetyPRSvalue.isHidden = false
        } else {
            labelSafetyPRS.isHidden = true
            labelSafetyPRSvalue.isHidden = true
        }
        if(padStatus.pressureFour == 99999) {
            labelSafetyPRSvalue.text = String("ERR")
        } else {
            labelSafetyPRSvalue.text = String(padStatus.pressureFour)
        }
        if(padStatus.pressureFour > padConfig.PRSalarm || padStatus.pressureFour == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        
        //====== END HEADER
    }

    

    
    @IBAction func buttonOneAction(_ sender: Any) {
        if(switchOne.isOn) {
            if(padStatus.valveOne) {
                working.radioMessage = "#C1,33,!"
                working.radioSend = true
                working.status = "Sent Close Request..."
                labelOneStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            } else {
                working.radioMessage = "#O1,33,!"
                working.radioSend = true
                working.status = "Sent Open Request..."
                labelOneStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            }
            switchOne.isOn = false
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonTwoAction(_ sender: Any) {
        if(switchTwo.isOn) {
            if(padStatus.valveFour) {
                working.radioMessage = "#C4,33,!"
                working.radioSend = true
                working.status = "Sent Close Request..."
                labelTwoStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            } else {
                if(padStatus.padArmed) { //must be armed to open, but not to close
                    if(padStatus.padHot){
                        working.radioMessage = "#O4,33,!"
                        working.radioSend = true
                        working.status = "Sent Open Request..."
                        labelTwoStatus.text = "Pending"
                        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
                    } else {
                        notHot()
                    }
                } else {
                    denyArmed()
                }
            }
            switchTwo.isOn = false
        } else {
          denySend()
        }
    }

    @IBAction func buttonErrorsAction(_ sender: Any) {
        tabBarController?.selectedIndex = 5
    }
    
    @IBAction func buttonThreeAction(_ sender: Any) {
        if(switchThree.isOn) {
            if(padStatus.valveTwo) {
                working.radioMessage = "#C2,33,!"
                working.radioSend = true
                working.status = "Sent Close Request..."
                labelThreeStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            } else {
                working.radioMessage = "#O2,33,!"
                working.radioSend = true
                working.status = "Sent Open Request..."
                labelThreeStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            }
            switchThree.isOn = false
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonEightAction(_ sender: Any) {
        if(switchEight.isOn) {
            if(padStatus.valveSeven) {
                working.radioMessage = "#C7,33,!"
                working.radioSend = true
                working.status = "Sent Close Request..."
                labelEightStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            } else {
                working.radioMessage = "#O7,33,!"
                working.radioSend = true
                working.status = "Sent Open Request..."
                labelEightStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            }
            switchEight.isOn = false
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonFourAction(_ sender: Any) {
        if(switchFour.isOn) {
            if(padStatus.valveThree) {
                working.radioMessage = "#C3,33,!"
                working.radioSend = true
                working.status = "Sent Close Request..."
                labelFourStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            } else {
                working.radioMessage = "#O3,33,!"
                working.radioSend = true
                working.status = "Sent Open Request..."
                labelFourStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            }
            switchFour.isOn = false
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonFiveAction(_ sender: Any) {
        if(switchFive.isOn) {
            if(padStatus.valveFive) {
                working.radioMessage = "#C5,33,!"
                working.radioSend = true
                working.status = "Sent Close Request..."
                labelFiveStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            } else {
                if(padStatus.padArmed) { //must be armed to open, but not to close
                    if(padStatus.padHot){
                        working.radioMessage = "#O5,33,!"
                        working.radioSend = true
                        working.status = "Sent Open Request..."
                        labelFiveStatus.text = "Pending"
                        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
                    } else {
                        notHot()
                    }
                } else {
                    denyArmed()
                }
            }
            switchFive.isOn = false
        } else {
          denySend()
        }
    }
    @IBAction func buttonSixAction(_ sender: Any) {
        if(switchSix.isOn) {
            if(padStatus.valveSix) {
                working.radioMessage = "#C6,33,!"
                working.radioSend = true
                working.status = "Sent Close Request..."
                labelSixStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            } else {
                working.radioMessage = "#O6,33,!"
                working.radioSend = true
                working.status = "Sent Open Request..."
                labelSixStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            }
            switchSix.isOn = false
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonSevenAction(_ sender: Any) {
        if(switchSeven.isOn) {
            if(padStatus.valveEight) {
                working.radioMessage = "#C8,33,!"
                working.radioSend = true
                working.status = "Sent Close Request..."
                labelSevenStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            } else {
                working.radioMessage = "#O8,33,!"
                working.radioSend = true
                working.status = "Sent Open Request..."
                labelSevenStatus.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            }
            switchSeven.isOn = false
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonSpareAction(_ sender: Any) {
        if(switchSpareNine.isOn) {
            if(padStatus.valveNine) {
                working.radioMessage = "#C9,33,!"
                working.radioSend = true
                working.status = "Sent Close Request..."
                labelSpareNine.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            } else {
                working.radioMessage = "#O9,33,!"
                working.radioSend = true
                working.status = "Sent Open Request..."
                labelSpareNine.text = "Pending"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            }
            switchSpareNine.isOn = false
        } else {
          denySend()
        }
        
        
    }
    
    
    
    
    @IBAction func buttonStatus(_ sender: Any) {
        working.radioMessage = "#S,033,!"
        working.radioSend = true
        working.status = "Sent Status Request..."
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
    }
    
    @IBAction func buttonArmAction(_ sender: Any) {
        if(switchArm.isOn) {
            if(padStatus.padHot){
              if(padStatus.padArmed) {
                working.radioMessage = "#ARM0,033,!"
                working.radioSend = true
                working.status = "Sent Disarm Request..."
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
              } else {
                working.radioMessage = "#ARM1,033,!"
                working.radioSend = true
                working.status = "Sent Arm Request..."
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
              }
            } else {
                notHot()
            }
            switchArm.isOn = false
        } else {
            denySend()
        }
        
    }
    
    @IBAction func buttonNineAction(_ sender: Any) { // zzz left off here do main vales
    
        if(labelSwitchNine.isOn) {
                if(padStatus.padArmed) {
                    if(padStatus.padHot){
                        working.radioMessage = "#MON,33,!"
                        working.radioSend = true
                        working.status = "Sent Open Request..."
                        labelNineStatus.text = "Pending"
                        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
                    } else {
                        notHot()
                    }
                } else {
                    denyArmed()
                }
        } else {
            denySend()
        }
        labelSwitchNine.isOn = false
    }
    
    @IBAction func buttonTen(_ sender: Any) {
        if(labelSwitchNine.isOn) {
            working.radioMessage = "#MOFF,33,!"
            working.radioSend = true
            working.status = "Sent Close Request..."
            labelNineStatus.text = "Pending"
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            
        } else {
            denySend()
        }
        
        labelSwitchNine.isOn = false
    }
    
    
    
    
    
    
    
    func denyArmed() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "The pad must be ARMED before sending the request", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    
    
    

    func denySend() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "You must unlock the safety before sending the request", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    
    
    func notHot() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "The pad controller is not hot. Insert Safety Plug.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    
    

}



