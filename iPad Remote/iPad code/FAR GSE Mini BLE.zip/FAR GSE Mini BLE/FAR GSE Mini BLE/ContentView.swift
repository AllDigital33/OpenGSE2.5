//
//  ContentView.swift
//  FAR Biprop Remote
//
//  Created by Preston Brinker on 3/27/21.
//
import UIKit
import SwiftUI

struct ContentView: View {
    //@State public var value: Double
        var body: some View {
            VStack {
                //GaugeView(coveredRadius: 250, maxValue: 500, steperSplit: 50, value: $value)
                GaugeView(coveredRadius: 250, maxValue: 500, steperSplit: 50)
                /*Slider(value: $value, in: 0...500, step: 1)
                    .padding(.horizontal, 20)
                HStack {
                    Spacer()
                    Button(action: {
                        self.value = 0
                    }) {
                        Text("Zero")
                    }.foregroundColor(.blue)
                    Spacer()
                    Button(action: {
                        self.value = 500
                    }) {
                        Text("Max")
                    }.foregroundColor(.blue)
                    Spacer()
                }*/
            }
        }
}

struct Needle: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: 0, y: rect.height/2))
        path.addLine(to: CGPoint(x: rect.width, y: 0))
        path.addLine(to: CGPoint(x: rect.width, y: rect.height))
        return path
    }
}

public func beep(){
    //g1Value += 1
}

struct GaugeView: View {
    func colorRanges(percent: Int) -> Color {
        let targetPressure: Int = 400;
        if(percent*5 > targetPressure+50){
            return Color.init(red: 1, green: 0, blue: 0)
        } else if(percent*5 >= targetPressure-50){
            return Color.init(red: 0, green: 1, blue: 0)
        } else {
            return Color.init(red: 0, green: 0, blue: 0)
        }
    }
    
    
    func tick(at tick: Int, totalTicks: Int) -> some View {
        let percent = (tick * 100) / totalTicks
        let startAngle = coveredRadius/2 * -1
        let stepper = coveredRadius/Double(totalTicks)
        let rotation = Angle.degrees(startAngle + stepper * Double(tick))
        return VStack {
                   Rectangle()
                    .fill(colorRanges(percent: percent))
                       .frame(width: tick % 2 == 0 ? 5 : 3,
                              height: tick % 2 == 0 ? 20 : 10) //alternet small big dash
                   Spacer()
           }.rotationEffect(rotation)
    }
    
    func tickText(at tick: Int, text: String) -> some View {
        let percent = (tick * 100) / tickCount
        let startAngle = coveredRadius/2 * -1 + 90
        let stepper = coveredRadius/Double(tickCount)
        let rotation = startAngle + stepper * Double(tick)
        return Text(text).foregroundColor(colorRanges(percent: percent)).rotationEffect(.init(degrees: -1 * rotation), anchor: .center).offset(x: -115, y: 0).rotationEffect(Angle.degrees(rotation))
    }
    
    let coveredRadius: Double // 0 - 360°
    let maxValue: Int
    let steperSplit: Int
    
    private var tickCount: Int {
        return maxValue/steperSplit
    }
    
    //@Binding var value: Double
    var body: some View {
        ZStack {
            //Text("\(value, specifier: "%0.0f")")
 //           Text("\(g1Value, specifier: "%0.0f")")
 //               .font(.system(size: 40, weight: Font.Weight.bold))
  //              .foregroundColor(Color.orange)
 //               .offset(x: 0, y: 40)
            ForEach(0..<tickCount*2 + 1) { tick in
                self.tick(at: tick,
                          totalTicks: self.tickCount*2)
            }
            ForEach(0..<tickCount+1) { tick in
                self.tickText(at: tick, text: "\(self.steperSplit*tick)")
            }
            Needle()
                .fill(Color.red)
                .frame(width: 100, height: 6)
                .offset(x: -50, y: 0)
                //.rotationEffect(.init(degrees: getAngle(value: value)), anchor: .center)
       //         .rotationEffect(.init(degrees: getAngle(value2: g1Value)), anchor: .center)
                .animation(.linear)
            Circle()
                .frame(width: 20, height: 20)
                .foregroundColor(.red)
            //frame sets size of gauge
        }.frame(width: 266, height: 188, alignment: .center)
    }
    func getAngle(value2: Double) -> Double {
        return (value2/Double(maxValue))*coveredRadius - coveredRadius/2 + 90
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
