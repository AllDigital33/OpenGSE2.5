//
//  RadioView.swift
//  FAR Biprop Remote
//
//  Created by Brinker, Mike on 3/23/21.
//


import Foundation
import AVFoundation
import UIKit


class RadioView: UIViewController {

    @IBOutlet weak var labelStatus: UILabel!
    @IBOutlet weak var labelSafetyPad: UILabel!
    @IBOutlet weak var labelSafetyLox: UILabel!
    @IBOutlet weak var labelSafetyFuel: UILabel!
    @IBOutlet weak var labelSafetyHelium: UILabel!
    @IBOutlet weak var labelOxSafety: UILabel!
    @IBOutlet weak var labelFuelSafety: UILabel!
    @IBOutlet weak var labelPressureSafety: UILabel!
    @IBOutlet weak var textBox: UITextView!
    @IBOutlet weak var switchRefreshLive: UISwitch!
    @IBOutlet weak var imageArmedIcon: UIImageView!
    @IBOutlet weak var labelSafetyPRS: UILabel!
    @IBOutlet weak var labelSafetyPRSvalue: UILabel!
    @IBOutlet weak var buttonErrors: UIButton!
    @IBOutlet weak var imageNoSync: UIImageView!
    
    
    var timerOne: Timer?
    var currentCount: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
        
        labelStatus.text = ""
        for item in working.radioRXarray {
            textBox.text += item
            textBox.text += "\n"
        }
        currentCount = working.radioRXarray.count

        timerOne = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(self.housekeepingTimer), userInfo: nil, repeats: true)
        refreshView()
        refreshData()
    }
    
  
    @objc func housekeepingTimer() {
        
        if(working.viewRadioRefreshData) {refreshData()}
        if(working.viewRadioRefreshScreen) {refreshView()}
        
        if(switchRefreshLive.isOn) {
            if(working.radioRXarray.count > currentCount) {
                let theStart: Int = currentCount
                let theEnd: Int = working.radioRXarray.count - 1
                for n in theStart...theEnd {
                    textBox.text += working.radioRXarray[n]
                    textBox.text += "\n"
                }
                currentCount = working.radioRXarray.count
            }
        }
        
        
        if(working.viewRadioRefreshData) {refreshData()}
        if(working.viewRadioRefreshScreen) {refreshView()}
        
        // clear status
        if(working.statusTimeout < Date() && labelStatus.text != "") {
             labelStatus.text = ""
         }
         //update status
        if(working.statusTimeout > Date()) {
             labelStatus.text = working.status
         }
        
        if(errors.errorCount > 0) {
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
    }

    func refreshView() {
        labelOxSafety.text = configuration.oxTankName
        labelFuelSafety.text = configuration.fuelTankName
        labelPressureSafety.text = configuration.pressureTankName
        labelSafetyPRS.text = configuration.rspareTankName
        working.viewRadioRefreshScreen = false
    }
    
    func refreshData() {
        
        // ---------------- Standard Header
        if(padStatus.padHot) {
            labelSafetyPad.text = "HOT"
            labelSafetyPad.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        } else {
            labelSafetyPad.text = "SAFE"
            labelSafetyPad.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.padArmed) {
            imageArmedIcon.image = UIImage(named: "armed")
        } else {
            imageArmedIcon.image = UIImage(named: "disarm2")
        }
        if(errors.errorCount > 0) {
            buttonErrors.setTitle(" ", for: .normal)
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
        if(padConfig.updated == 1) {
            imageNoSync.isHidden = true
        } else {
            imageNoSync.isHidden = false
        }
        // ---------------- end standard header


        updatePressure()
        working.viewRadioRefreshData = false
    }
    
    func updatePressure() {
        
        // =====================================   Standard header
        if(padConfig.POXenabled == 1){
            labelSafetyLox.isHidden = false
            labelOxSafety.isHidden = false
        } else {
            labelSafetyLox.isHidden = true
            labelOxSafety.isHidden = true
        }
        if(padStatus.pressureOne == 99999) {
            labelSafetyLox.text = String("ERR")
        } else {
            labelSafetyLox.text = String(padStatus.pressureOne)
        }
        if(padStatus.pressureOne > padConfig.POXalarm || padStatus.pressureOne == 99999) {
            labelSafetyLox.textColor = .red
        } else {
            labelSafetyLox.textColor = .black
        }
        //-----
        if(padConfig.PFLenabled == 1){
            labelSafetyFuel.isHidden = false
            labelFuelSafety.isHidden = false
        } else {
            labelSafetyFuel.isHidden = true
            labelFuelSafety.isHidden = true
        }
        if(padStatus.pressureTwo == 99999) {
            labelSafetyFuel.text = String("ERR")
        } else {
            labelSafetyFuel.text = String(padStatus.pressureTwo)
        }
        if(padStatus.pressureTwo > padConfig.PFLalarm || padStatus.pressureTwo == 99999) {
            labelSafetyFuel.textColor = .red
        } else {
            labelSafetyFuel.textColor = .black
        }
        //------
        if(padConfig.PPSenabled == 1){
            labelSafetyHelium.isHidden = false
            labelPressureSafety.isHidden = false
        } else {
            labelSafetyHelium.isHidden = true
            labelPressureSafety.isHidden = true
        }
        if(padStatus.pressureThree == 99999) {
            labelSafetyHelium.text = String("ERR")
        } else {
            labelSafetyHelium.text = String(padStatus.pressureThree)
        }
        if(padStatus.pressureThree > padConfig.PPSalarm || padStatus.pressureThree == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        if(padConfig.PRSenabled == 1){
            labelSafetyPRS.isHidden = false
            labelSafetyPRSvalue.isHidden = false
        } else {
            labelSafetyPRS.isHidden = true
            labelSafetyPRSvalue.isHidden = true
        }
        if(padStatus.pressureFour == 99999) {
            labelSafetyPRSvalue.text = String("ERR")
        } else {
            labelSafetyPRSvalue.text = String(padStatus.pressureFour)
        }
        if(padStatus.pressureFour > padConfig.PRSalarm || padStatus.pressureFour == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        
        //====== END HEADER
    }

    
    @IBAction func buttonErrorsAction(_ sender: Any) {
        tabBarController?.selectedIndex = 5
    }
    
    
    
    
    
    
}


