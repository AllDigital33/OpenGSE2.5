//
//  ConfigUIView.swift
//  FAR Biprop Remote
//
//  Created by Brinker, Mike on 3/22/21.
//

import SwiftUI

struct ConfigUIView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ConfigUIView_Previews: PreviewProvider {
    static var previews: some View {
        ConfigUIView()
    }
}
