//
//  FilesView.swift
//  FAR Biprop Remote
//
//  Created by Mike Brinker on 6/3/23.
//

import UIKit
import Foundation
import AVFoundation
import MessageUI

import DGCharts
import SwiftUI





class FilesView: UIViewController, UITableViewDelegate, UITableViewDataSource {


    @IBOutlet weak var labelStatus: UILabel!
    @IBOutlet weak var labelSafetyPad: UILabel!
    @IBOutlet weak var labelSafetyLox: UILabel!
    @IBOutlet weak var labelSafetyFuel: UILabel!
    @IBOutlet weak var labelSafetyHelium: UILabel!
    @IBOutlet weak var labelOxSafety: UILabel!
    @IBOutlet weak var labelFuelSafety: UILabel!
    @IBOutlet weak var labelPressureSafety: UILabel!
    @IBOutlet weak var imageArmedIcon: UIImageView!
    @IBOutlet weak var labelSafetyPRS: UILabel!
    @IBOutlet weak var labelSafetyPRSvalue: UILabel!
    @IBOutlet weak var buttonErrors: UIButton!
    @IBOutlet weak var imageNoSync: UIImageView!
    
    @IBOutlet weak var labelMCUcount: UILabel!
    @IBOutlet weak var labelLocalCount: UILabel!
    @IBOutlet weak var textFileContents: UITextView!
    @IBOutlet weak var localFilesView: UITableView!
    @IBOutlet weak var MCUfilesView: UITableView!
    
    @IBOutlet weak var switchRefresh: UISwitch!
    @IBOutlet weak var switchDeleteAll: UISwitch!
    @IBOutlet weak var buttonMCUdeleteAll: UIButton!
    
    @IBOutlet weak var FTPview: UIView!
    @IBOutlet weak var FTPtext: UILabel!
    @IBOutlet weak var labelSelectLocal: UILabel!
    @IBOutlet weak var labelRefreshing: UILabel!
    @IBOutlet weak var buttonCancel: UIButton!
    @IBOutlet weak var switchDeleteLocal: UISwitch!
    @IBOutlet weak var buttonGraph: UIButton!

    @IBOutlet weak var lineChartView: LineChartView!
    
    

    
    
    
    var timerOne: Timer?
    var currentCount: Int = 0
    let cellReuseIdentifier = "cell"
    let cellReuseIdentifier2 = "cell2"
    let cellSpacingHeight: CGFloat = 1
    var localFileList = [String]()
    var MCUfileList = [String]()
    var theSelected: String? = ""
    var theFileList = [String]()
    var chartViewHostingController: UIHostingController<AnyView>?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        UIApplication.shared.isIdleTimerDisabled = true
       
        // to close the chart/graph view
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(chartTapped(_:)))
            lineChartView.addGestureRecognizer(tapGesture)
        
        
        // Do any additional setup after loading the view.
        
        labelStatus.text = ""
        FTPview.isHidden = true
        FTPtext.isHidden = true
        labelRefreshing.isHidden = true
        buttonCancel.isHidden = true
        textFileContents.isHidden = true
        buttonGraph.isHidden = true
        FTPS.theIndex = 999 //not selected
        
        localFilesInit()
        MCUfilesInit()
        lineChartView.isHidden = true

        timerOne = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(self.housekeepingTimer), userInfo: nil, repeats: true)
        refreshView()
        refreshData()
    }
    
    override func viewDidAppear(_ animated: Bool) { //refresh everything
    
          lineChartView.isHidden = true
          refreshLocalFiles()
    
    }
    
    
    
    
    
  
    @objc func housekeepingTimer() {
        
        if(working.viewFilesRefreshData) {refreshData()}
        if(working.viewFilesRefreshScreen) {refreshView()}
        
        // clear status
        if(working.statusTimeout < Date() && labelStatus.text != "") {
             labelStatus.text = ""
         }
         //update status
        if(working.statusTimeout > Date()) {
             labelStatus.text = working.status
         }
        
        //=========  FTP Activities =====================
        if(FTPS.active && FTPview.isHidden) {
            FTPview.isHidden = false
            FTPtext.isHidden = false
            labelRefreshing.isHidden = false
            buttonCancel.isHidden = false
        }
        if(!FTPS.active && !FTPview.isHidden) { // all done
            if(FTPS.success) {
                FTPS.success = false
                if(!FTPS.dirInit) {FTPS.dirInit = true}
            }
            FTPview.isHidden = true
            FTPtext.isHidden = true
            labelRefreshing.isHidden = true
            buttonCancel.isHidden = true
            refreshMCUFiles()
            refreshLocalFiles()
        }
        if(FTPS.active) {
            if(FTPS.dir) {
                FTPtext.text = "Refreshing " + String(FTPS.fileCount)+" files." + "\r\n" + String(FTPS.currentPacket) + " of " + String(FTPS.totalPackets) + " packets"
            } else {
                FTPtext.text = "Transfering " + FTPS.fileName + "\r\n"  + String(FTPS.currentPacket) + " of "  + String(FTPS.totalPackets) + " packets"
            }
        }
        if((FTPS.lastRadio + 30) < Date() && FTPS.active) {
            FTPS.active = false
            FTPS.dir = false
            working.status = "File transfer timeout - Aborting"
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            refreshMCUFiles()
            refreshLocalFiles()
         }
        if(FTPS.refresh) {
            refreshMCUFiles()
        }
        
        if(errors.errorCount > 0) {
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
        
    }

    func refreshView() {
        labelOxSafety.text = configuration.oxTankName
        labelFuelSafety.text = configuration.fuelTankName
        labelPressureSafety.text = configuration.pressureTankName
        labelSafetyPRS.text = configuration.rspareTankName
        working.viewFilesRefreshScreen = false
    }
    
    func refreshData() {
        
        // ---------------- Standard Header
        if(padStatus.padHot) {
            labelSafetyPad.text = "HOT"
            labelSafetyPad.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        } else {
            labelSafetyPad.text = "SAFE"
            labelSafetyPad.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.padArmed) {
            imageArmedIcon.image = UIImage(named: "armed")
        } else {
            imageArmedIcon.image = UIImage(named: "disarm2")
        }
        if(errors.errorCount > 0) {
            buttonErrors.setTitle(" ", for: .normal)
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
        if(padConfig.updated == 1) {
            imageNoSync.isHidden = true
        } else {
            imageNoSync.isHidden = false
        }
        // ---------------- end standard header


        updatePressure()
        working.viewFilesRefreshData = false
    }
    
    
    func updatePressure() {
        
        // =====================================   Standard header
        if(padConfig.POXenabled == 1){
            labelSafetyLox.isHidden = false
            labelOxSafety.isHidden = false
        } else {
            labelSafetyLox.isHidden = true
            labelOxSafety.isHidden = true
        }
        if(padStatus.pressureOne == 99999) {
            labelSafetyLox.text = String("ERR")
        } else {
            labelSafetyLox.text = String(padStatus.pressureOne)
        }
        if(padStatus.pressureOne > padConfig.POXalarm || padStatus.pressureOne == 99999) {
            labelSafetyLox.textColor = .red
        } else {
            labelSafetyLox.textColor = .black
        }
        //-----
        if(padConfig.PFLenabled == 1){
            labelSafetyFuel.isHidden = false
            labelFuelSafety.isHidden = false
        } else {
            labelSafetyFuel.isHidden = true
            labelFuelSafety.isHidden = true
        }
        if(padStatus.pressureTwo == 99999) {
            labelSafetyFuel.text = String("ERR")
        } else {
            labelSafetyFuel.text = String(padStatus.pressureTwo)
        }
        if(padStatus.pressureTwo > padConfig.PFLalarm || padStatus.pressureTwo == 99999) {
            labelSafetyFuel.textColor = .red
        } else {
            labelSafetyFuel.textColor = .black
        }
        //------
        if(padConfig.PPSenabled == 1){
            labelSafetyHelium.isHidden = false
            labelPressureSafety.isHidden = false
        } else {
            labelSafetyHelium.isHidden = true
            labelPressureSafety.isHidden = true
        }
        if(padStatus.pressureThree == 99999) {
            labelSafetyHelium.text = String("ERR")
        } else {
            labelSafetyHelium.text = String(padStatus.pressureThree)
        }
        if(padStatus.pressureThree > padConfig.PPSalarm || padStatus.pressureThree == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        if(padConfig.PRSenabled == 1){
            labelSafetyPRS.isHidden = false
            labelSafetyPRSvalue.isHidden = false
        } else {
            labelSafetyPRS.isHidden = true
            labelSafetyPRSvalue.isHidden = true
        }
        if(padStatus.pressureFour == 99999) {
            labelSafetyPRSvalue.text = String("ERR")
        } else {
            labelSafetyPRSvalue.text = String(padStatus.pressureFour)
        }
        if(padStatus.pressureFour > padConfig.PRSalarm || padStatus.pressureFour == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        
        //====== END HEADER
    }
    
    
    // number of rows in table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return self.animals.count
        //return self.theFileList.count
        
        if tableView == localFilesView {
            return localFileList.count
           } else if tableView == MCUfilesView {
               return MCUfileList.count
           }
        return 0
    }
    
    // create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        /*
        // create a new cell if needed or reuse an old one
        let cell:UITableViewCell = (tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier))!
        // set the text from the data model
        //cell.textLabel?.text = self.animals[indexPath.row]
        cell.textLabel?.text = self.theFileList[indexPath.row]
        return cell
        */
        let cell: UITableViewCell
        
        if tableView == localFilesView {
            cell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier, for: indexPath)
            cell.textLabel?.text = localFileList[indexPath.row]
        } else if tableView == MCUfilesView {
            cell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier2, for: indexPath)
            cell.textLabel?.text = MCUfileList[indexPath.row]
        } else {
            cell = UITableViewCell()
        }

        return cell
    }
    
    // Set the spacing between sections
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return cellSpacingHeight
    }
    
    // method to run when table view cell is tapped
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //print("You tapped cell number \(indexPath.row).")
        //theSelected = theFileList[indexPath.row]
        //readSelectedFile()
        
        if tableView == localFilesView {
                let selectedValue = localFileList[indexPath.row]
                // Perform action for the local table view
                theSelected = localFileList[indexPath.row]
                readSelectedFile()
                print("Selected value in localFileView: \(selectedValue)")
            } else if tableView == MCUfilesView {
                let selectedValue = MCUfileList[indexPath.row]
                FTPS.theIndex = indexPath.row
                // Perform action for the second table view
                print("Selected value in MCUfileView: \(selectedValue)")
            }
        
    }
    
    
    
    
    func localFilesInit() {
        
        textFileContents.layer.borderWidth = 2
        textFileContents.layer.borderColor = UIColor.black.cgColor
        localFilesView.layer.borderWidth = 2
        localFilesView.layer.borderColor = UIColor.black.cgColor
        
        let filemgr = FileManager.default
        let dirPaths = filemgr.urls(for: .documentDirectory, in: .userDomainMask)
        let docsDir = dirPaths[0].path

        do {
            //let filelist = try filemgr.contentsOfDirectory(atPath: "/")
            let filelistR = try filemgr.contentsOfDirectory(atPath: docsDir)
            let filelist = filelistR.sorted()
            for filename in filelist {
                print(filename)
                localFileList.append("\(filename)")
            }
        } catch let error {
            print("Error: \(error.localizedDescription)")
        }
 
        // Register the table view cell class and its reuse id
        self.localFilesView.register(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)

        // This view controller itself will provide the delegate methods and row data for the table view.
        localFilesView.delegate = self
        localFilesView.dataSource = self
        
        labelLocalCount.text = String(localFileList.count) + " Total Files"
        
    }
    
    func MCUfilesInit() {
    
        textFileContents.layer.borderWidth = 2
        textFileContents.layer.borderColor = UIColor.black.cgColor
        MCUfilesView.layer.borderWidth = 2
        MCUfilesView.layer.borderColor = UIColor.black.cgColor
   
        MCUfileList.append("Refresh to see list")
        FTPS.theIndex = 999 //not selected
        
        
        
        // Register the table view cell class and its reuse id
        self.MCUfilesView.register(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)

        // This view controller itself will provide the delegate methods and row data for the table view.
        MCUfilesView.delegate = self
        MCUfilesView.dataSource = self
        labelMCUcount.text = String(MCUfileList.count) + " Total Files"
        
    }
    
    
    func parseFirstLineOfFile() -> [String] {
        guard let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("tempdir.tmp") else {
            print("File not found.")
            return []
        }

        do {
            let fileContents = try String(contentsOf: fileURL)
            let firstLine = fileContents.components(separatedBy: .newlines).first ?? ""
            let array = firstLine.components(separatedBy: ",")
            return array
        } catch {
            print("Error reading file: \(error)")
            return []
        }
    }
    
    
    func refreshMCUFiles() {
             
        FTPS.refresh = false
        MCUfileList.removeAll()
        MCUfilesView.reloadData()
        FTPS.theIndex = 999 //not selected
        FTPS.fileList.removeAll()
        if(FTPS.fileCount == 0) {
            MCUfilesInit()
            return
        }
        
        let filesArray = parseFirstLineOfFile()
        
        if(filesArray.count > 2) {
            var buf: Int = 0
            while((buf+1) < filesArray.count) {
                let theS: Int = Int(filesArray[buf + 1]) ?? 0
                var sizeString: String = ""
                if(theS < 1000) {
                    sizeString = String(theS) + "b"
                }
                if(theS >= 1000 && theS < 1000000) {
                    sizeString = String(Int(theS/1000)) + "Kb"
                }
                if(theS >= 1000000) {
                    sizeString = String(Int(theS/1000000)) + "Mb"
                }
                let fString = filesArray[buf] + "           " + sizeString
                FTPS.fileList.append(filesArray[buf])
                
                print (fString)
                buf = buf + 2
                MCUfileList.append(fString)
            }
            MCUfilesView.reloadData()
            labelMCUcount.text = String(MCUfileList.count) + " Total Files"
        }
    }
    
    
    
    func refreshLocalFiles() {
        
        // now clear the table
        textFileContents.text = ""
        
        localFileList.removeAll()
        localFilesView.reloadData()
        
        
        let filemgr = FileManager.default
        let dirPaths = filemgr.urls(for: .documentDirectory, in: .userDomainMask)
        let docsDir = dirPaths[0].path

        do {
            //let filelist = try filemgr.contentsOfDirectory(atPath: "/")
            let filelistR = try filemgr.contentsOfDirectory(atPath: docsDir)
            let filelist = filelistR.sorted()
            for filename in filelist {
                print(filename)
                localFileList.append("\(filename)")
            }
        } catch let error {
            print("Error: \(error.localizedDescription)")
        }
        localFilesView.reloadData()
        labelLocalCount.text = String(localFileList.count) + " Total Files"
    }
    
    func readSelectedFile() {
        
        labelSelectLocal.isHidden = true
        textFileContents.isHidden = false
        buttonGraph.isHidden = false
        
        textFileContents.text = ""
        let directoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
       // let fileURL = URL(fileURLWithPath: "myFile", relativeTo: directoryURL)
        
        
       // let fileURL = URL(fileURLWithPath: theSelected!, relativeTo: directoryURL).appendingPathExtension("txt")
        let fileURL = URL(fileURLWithPath: theSelected!, relativeTo: directoryURL)
        
        do {
         // Get the saved data
         let savedData = try Data(contentsOf: fileURL)
         // Convert the data back into a string
         if let savedString = String(data: savedData, encoding: .utf8) {
            //print(savedString)
            textFileContents.text += savedString
         }
        } catch {
         // Catch any errors
            textFileContents.text = "Error reading the file"
         print("Unable to read the file")
        }
        
        
    }
    
    
    
    

    
    @IBAction func buttonErrorsAction(_ sender: Any) {
        tabBarController?.selectedIndex = 5
    }
    
    
    //===========================================================  RADIO PROCESSING
    
    
    
    func calculateNMEAChecksum(sentence: String) -> UInt8 {
        // Exclude the initial '$' character from the checksum calculation
        let sentenceWithoutPrefix = sentence.dropFirst()

        // Initialize the XOR checksum
        var checksum: UInt8 = 0

        // Calculate the XOR checksum for each character in the sentence
        for character in sentenceWithoutPrefix {
            guard character != "*" else {
                break
            }
            checksum ^= character.asciiValue ?? 0
        }

        return checksum
    }
    
    
    func exampleNMEA() {
        
        // Example NMEA sentence
        let sentence = "$GPRMC,123519,A,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W*6A"

        // Calculate the checksum
        let checksum = calculateNMEAChecksum(sentence: sentence)

        // Print the checksum in hexadecimal format
        let checksumHex = String(format: "%02X", checksum)
        print("Checksum: 0x\(checksumHex)")
    }
    
    func denySend() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "You must unlock the safety before sending the request", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    func denyRefresh() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "You must first refresh the list", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    func denySelect() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "You must first select a file", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    func denyFile() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "Not a valid file to graph", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    
    //=======================================  IAB  =================================================
    
    
    @IBAction func buttonMCUdeleteAction(_ sender: Any) {
        
        if(switchDeleteAll.isOn) {
            working.radioMessage = "#FF,33,!"
            working.radioSend = true
            working.status = "Sent Delete All Request"
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            switchDeleteAll.isOn = false
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonRefreshAction(_ sender: Any) {
        
        if(switchRefresh.isOn) {
            working.radioMessage = "#DIR,33,!"
            working.radioSend = true
            working.status = "Sent Files Refresh Request"
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            switchRefresh.isOn = false
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonTransfer(_ sender: Any) {
        
        if(!FTPS.dirInit){
            switchRefresh.isOn = false
            denyRefresh()
            return
        }
        if(FTPS.theIndex == 999){
            switchRefresh.isOn = false
            denySelect()
            return
        }
        if(switchRefresh.isOn) {
            // transfer file logic here
            FTPS.fileName = FTPS.fileList[FTPS.theIndex]
            working.radioMessage = "#GET," + FTPS.fileName + ",!"
            working.radioSend = true
            working.status = "Requesting File: " + FTPS.fileName
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            switchRefresh.isOn = false
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonCancelAction(_ sender: Any) {
        
        FTPS.active = false
        working.radioMessage = "$DONE,33,!"  //cancel FTP
        working.radioSend = true
        working.status = "Canceling Request" + FTPS.fileName
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
    }
    
    @IBAction func buttonDeleteLocal(_ sender: Any) {
        if(switchDeleteLocal.isOn) {
            
            if(theSelected == nil) {
                denySelect()
                switchDeleteLocal.isOn = false
                return
            }
            
            let directoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let fileURL = URL(fileURLWithPath: theSelected!, relativeTo: directoryURL)
            do {
                try FileManager.default.removeItem(at: fileURL)
            }  catch  { print(error) }
            refreshLocalFiles()
            
            switchDeleteLocal.isOn = false
        } else {
            denySend()
        }
    }
    
    @IBAction func buttonDeleteAllLocal(_ sender: Any) {
        if(switchDeleteLocal.isOn) {
            
            let documentsUrl =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!

            do {
                let fileURLs = try FileManager.default.contentsOfDirectory(at: documentsUrl,
                                                                           includingPropertiesForKeys: nil,
                                                                           options: .skipsHiddenFiles)
                for fileURL in fileURLs {
                        try FileManager.default.removeItem(at: fileURL)
                }
            } catch  { print(error) }
            refreshLocalFiles()
            
            
            switchDeleteLocal.isOn = false
            
        } else {
            denySend()
        }
        
        
    }
    
    @IBAction func buttonSend(_ sender: Any) {
        
        
        if(labelSelectLocal.isHidden == true) {
            let directoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            //let fileURL = URL(fileURLWithPath: "config.txt", relativeTo: directoryURL)
            
            let fileURL = URL(fileURLWithPath: theSelected!, relativeTo: directoryURL)
            print(String(theSelected!))
            
            do {
                let fileData = try Data(contentsOf: fileURL)
                //let activityViewController = UIActivityViewController(activityItems: [fileData], applicationActivities: nil)

                let activityViewController = UIActivityViewController(activityItems: [CustomActivityItem(data: fileData, filename: String(theSelected!))], applicationActivities: nil)
                           
                
            //let activityViewController = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
            
            
                // Present the activity view controller
                if let popoverController = activityViewController.popoverPresentationController {
                    popoverController.sourceView = (sender as! UIView)
                    popoverController.sourceRect = (sender as AnyObject).bounds
                }
                present(activityViewController, animated: true, completion: nil)
            } catch {
                print("Error opening file")
            }

        } else {
            denySelect()
        }
    }
    
    //====================================================== GRAPH CHART ==========================================
    
    
    @IBAction func buttonGraphAction(_ sender: Any) {
     
        var numFields: Int = 0
        var fieldList = [String]()
        var dataEntry1: [ChartDataEntry] = []
        var dataEntry2: [ChartDataEntry] = []
        var dataEntry3: [ChartDataEntry] = []
        var dataEntry4: [ChartDataEntry] = []
        
     // -----------  Check for a valid file  -----------------------------------------------
        
        if(theSelected == nil) {
            denySelect()
            return
        }
        
        let directoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let fileURL = URL(fileURLWithPath: theSelected!, relativeTo: directoryURL)
        
        do {
            let fileContents = try String(contentsOf: fileURL)
            let firstLine = fileContents.components(separatedBy: .newlines).first ?? ""
            let array = firstLine.components(separatedBy: ",")
            if(array[0] == "Milliseconds"){
                // we have a good file
                numFields = array.count
                for i in 1...numFields {
                    fieldList.append(array[i-1])
                }
                //=====================  READ VALUES FROM FILE ===============================
                let lines = fileContents.components(separatedBy: .newlines)
                var inx: Int = 0
                //---- One ---
                for line in lines {
                    inx += 1
                    if(inx > 1) { // one is the field descriptions
                        if(line.isEmpty == false) {
                                let values = line.components(separatedBy: ",")
                                if(values.count == numFields) {
                                   var xValue = Double(values[0])
                                   let trims = values[1].trimmingCharacters(in: .whitespacesAndNewlines)
                                   var yValue = Double(trims)
                                    if(yValue == 99999) {yValue = 0}
                                   var dataEntry = ChartDataEntry(x: xValue ?? 0.0, y: yValue ?? 0.0)
                                   dataEntry1.append(dataEntry)
                                   //----------------------------
                                    if(numFields >= 3) { // has a second field
                                        let trims = values[2].trimmingCharacters(in: .whitespacesAndNewlines)
                                        var yValue = Double(trims)
                                        if(yValue == 99999) {yValue = 0}
                                        var dataEntry = ChartDataEntry(x: xValue ?? 0.0, y: yValue ?? 0.0)
                                        dataEntry2.append(dataEntry)
                                    }
                                    //----------------------------
                                     if(numFields >= 4) { // has a third field
                                         let trims = values[3].trimmingCharacters(in: .whitespacesAndNewlines)
                                         var yValue = Double(trims)
                                         if(yValue == 99999) {yValue = 0}
                                         var dataEntry = ChartDataEntry(x: xValue ?? 0.0, y: yValue ?? 0.0)
                                         dataEntry3.append(dataEntry)
                                     }
                                    //----------------------------
                                     if(numFields == 5) { // has a fourth field
                                         let trims = values[4].trimmingCharacters(in: .whitespacesAndNewlines)
                                         var yValue = Double(trims)
                                         if(yValue == 99999) {yValue = 0}
                                         var dataEntry = ChartDataEntry(x: xValue ?? 0.0, y: yValue ?? 0.0)
                                         dataEntry4.append(dataEntry)
                                     }
                                    
                                }
                        }
                    }
                    inx += 1
                }
            } else { // not "milliseconds" a bad file
                print(array[0])
                denyFile()
                return
            }
        } catch {
            print("Error reading file: \(error)")
            return
        }
       
        
        
     // -----------  Set up the view -----------------------------------------------
        lineChartView.xAxis.labelPosition = .bottom
        lineChartView.xAxis.labelTextColor = .black
        lineChartView.xAxis.labelFont = UIFont.systemFont(ofSize: 12.0)
        lineChartView.leftAxis.labelFont = UIFont.systemFont(ofSize: 16.0)
        lineChartView.rightAxis.labelFont = UIFont.systemFont(ofSize: 16.0)
        //lineChartView.chartDescription.text = "Chart Title"
        //lineChartView.chartDescription.font = UIFont.systemFont(ofSize: 16.0)
        //lineChartView.chartDescription.textAlign = .center
        
        
        // Create the lines in the chart
        //-------- ONE ---------------------------------------------------------------
        let dataSet = LineChartDataSet(entries: dataEntry1, label: fieldList[1])
        dataSet.colors = [.blue]
        dataSet.lineWidth = 2.0
        dataSet.drawCirclesEnabled = false
        let data = LineChartData(dataSet: dataSet)
        //-------- TWO ---------------------------------------------------------------
        if(numFields >= 3) { // has a second field
            let dataSet2 = LineChartDataSet(entries: dataEntry2, label: fieldList[2])
            dataSet2.colors = [.red]
            dataSet2.lineWidth = 2.0
            dataSet2.drawCirclesEnabled = false
            data.dataSets.append(dataSet2)
        }
        //-------- THREE ---------------------------------------------------------------
        if(numFields >= 4) { // has a second field
            let dataSet3 = LineChartDataSet(entries: dataEntry3, label: fieldList[3])
            dataSet3.colors = [.green]
            dataSet3.lineWidth = 2.0
            dataSet3.drawCirclesEnabled = false
            data.dataSets.append(dataSet3)
        }
        //-------- FOUR ---------------------------------------------------------------
        if(numFields == 5) { // has a second field
            let dataSet4 = LineChartDataSet(entries: dataEntry4, label: fieldList[4])
            dataSet4.colors = [.black]
            dataSet4.lineWidth = 2.0
            dataSet4.drawCirclesEnabled = false
            data.dataSets.append(dataSet4)
        }
        // Set the LineChartData to the lineChartView
        lineChartView.data = data
    
        // Refresh the chart to update the display
        lineChartView.notifyDataSetChanged()
        lineChartView.backgroundColor = UIColor.white
        lineChartView.isOpaque = true
        lineChartView.translatesAutoresizingMaskIntoConstraints = false
        lineChartView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        lineChartView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        lineChartView.topAnchor.constraint(equalTo: view.topAnchor, constant: view.bounds.height * 0.155).isActive = true
        lineChartView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -view.bounds.height * 0.065).isActive = true
        
        lineChartView.isHidden = false
        
    }
    
    
    
    @objc func chartTapped(_ sender: UITapGestureRecognizer) {
        if sender.state == .ended {
            // Handle the chart tap action here
            // You can perform any desired actions or trigger the IBAction method
            lineChartView.isHidden = true
        }
    }
    
    func parseFirst(thefile: String) -> [String] {
        guard let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent(thefile) else {
            print("File not found.")
            return []
        }
        do {
            let fileContents = try String(contentsOf: fileURL)
            let firstLine = fileContents.components(separatedBy: .newlines).first ?? ""
            let array = firstLine.components(separatedBy: ",")
            return array
        } catch {
            print("Error reading file: \(error)")
            return []
        }
    }
    
    //====================================================== END GRAPH CHART STUFF ==========================================
    
    
    
    
    
    
    //==================  USED for Airdrop and Mail UI  ========================
    
    // Custom UIActivityItemSource class
    class CustomActivityItem: NSObject, UIActivityItemSource {
        let data: Data
        let filename: String
        
        init(data: Data, filename: String) {
            self.data = data
            self.filename = filename
        }
        
        func activityViewControllerPlaceholderItem(_ activityViewController: UIActivityViewController) -> Any {
            return data
        }
        
        func activityViewController(_ activityViewController: UIActivityViewController, itemForActivityType activityType: UIActivity.ActivityType?) -> Any? {
            if activityType == .airDrop {
                return data
            }
            return nil
        }
        
        func activityViewController(_ activityViewController: UIActivityViewController, dataTypeIdentifierForActivityType activityType: UIActivity.ActivityType?) -> String {
            if activityType == .airDrop {
                return "public.data"
            }
            return ""
        }
        
        func activityViewController(_ activityViewController: UIActivityViewController, subjectForActivityType activityType: UIActivity.ActivityType?) -> String {
            if activityType == .mail {
                return filename
            }
            return ""
        }
    }
    
    
    
    
}


