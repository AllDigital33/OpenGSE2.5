//
//  LaunchView.swift
//  FAR Biprop Remote
//
//  Created by Brinker, Mike on 3/23/21.
//

import Foundation
import AVFoundation
import UIKit

class LaunchView: UIViewController {

    @IBOutlet weak var labelStatus: UILabel!
    @IBOutlet weak var labelSafetyPad: UILabel!
    @IBOutlet weak var labelSafetyLox: UILabel!
    @IBOutlet weak var labelSafetyFuel: UILabel!
    @IBOutlet weak var labelSafetyHelium: UILabel!
    @IBOutlet weak var labelOxSafety: UILabel!
    @IBOutlet weak var labelFuelSafety: UILabel!
    @IBOutlet weak var labelPressureSafety: UILabel!
    
    @IBOutlet weak var buttonIgniterArm: UIButton!
    @IBOutlet weak var buttonIgniterFire: UIButton!
    @IBOutlet weak var buttonMainValvesOpen: UIButton!
    @IBOutlet weak var buttonAbort: UIButton!
    @IBOutlet weak var switchIgniterArm: UISwitch!
    @IBOutlet weak var switchIgniterFire2: UISwitch!
    @IBOutlet weak var switchMainValvesOpen2: UISwitch!
    @IBOutlet weak var switchAbort2: UISwitch!
    @IBOutlet weak var imageArmedIcon: UIImageView!
    @IBOutlet weak var labelClock: UILabel!
    
    @IBOutlet weak var imagePadHot: UIImageView!
    @IBOutlet weak var imageRecoveryPower: UIImageView!
    @IBOutlet weak var imageRecoveryContinuity: UIImageView!
    @IBOutlet weak var imageIgniterContinuity: UIImageView!
    @IBOutlet weak var imagePneumatics: UIImageView!
    @IBOutlet weak var labelOx2: UILabel!
    @IBOutlet weak var labelFuel2: UILabel!
    @IBOutlet weak var imagePadArmed: UIImageView!
    @IBOutlet weak var labelLaunch: UILabel!
    @IBOutlet weak var labelOxName: UILabel!
    @IBOutlet weak var labelFuelName: UILabel!
    @IBOutlet weak var labelRadioTimer: UILabel!
    @IBOutlet weak var labelSafetyPRS: UILabel!
    @IBOutlet weak var labelSafetyPRSvalue: UILabel!
    @IBOutlet weak var buttonErrors: UIButton!
    @IBOutlet weak var imageNoSync: UIImageView!
    @IBOutlet weak var labelDAQ: UILabel!
    @IBOutlet weak var buttonDAQ: UIButton!
    @IBOutlet weak var labelDAQtimer: UILabel!
    
    
    
    var player: AVAudioPlayer?
    var timerOne: Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        buttonIgniterArm.layer.cornerRadius = 6
        buttonIgniterArm.layer.borderWidth = 2.0
        buttonIgniterArm.layer.borderColor = UIColor.black.cgColor
        buttonIgniterFire.layer.cornerRadius = 6
        buttonIgniterFire.layer.borderWidth = 2.0
        buttonIgniterFire.layer.borderColor = UIColor.black.cgColor
        buttonMainValvesOpen.layer.cornerRadius = 6
        buttonMainValvesOpen.layer.borderWidth = 2.0
        buttonMainValvesOpen.layer.borderColor = UIColor.black.cgColor
        buttonAbort.layer.cornerRadius = 6
        buttonAbort.layer.borderWidth = 2.0
        buttonAbort.layer.borderColor = UIColor.black.cgColor
        labelClock.layer.borderWidth = 2.0
        labelClock.layer.borderColor = UIColor.black.cgColor
        labelDAQtimer.isHidden = true
        

        //housekeeping timer
        timerOne = Timer.scheduledTimer(timeInterval: 0.25, target: self, selector: #selector(self.housekeepingTimer), userInfo: nil, repeats: true)
        refreshView()
        refreshData()
        buttonDAQ.setTitle(" ", for: .normal)
    }

    
    
    @objc func housekeepingTimer() {
        if(working.viewLaunchRefreshData) {refreshData()}
        if(working.viewLaunchRefreshScreen) {refreshView()}
        
        // clear status
        if(working.statusTimeout < Date() && labelStatus.text != "") {
             labelStatus.text = ""
         }
         //update status
        if(working.statusTimeout > Date()) {
             labelStatus.text = working.status
         }
        //update countdown clock
        if(working.countdown) {
            updateClock()
        }
        radioLast() // update radio last counter
        
        // DAQ stuff here ------------

        if(!working.DAQrecording) {
            buttonDAQ.setBackgroundImage(UIImage(named: "DAQnorec"), for: UIControl.State.normal)
            labelDAQ.text = "start"
            labelDAQtimer.isHidden = true
        } else {
            buttonDAQ.setBackgroundImage(UIImage(named: "DAQrec"), for: UIControl.State.normal)
            labelDAQ.text = "stop"
            let theDiff: Int = getDateDiff(start: working.DAQclock, end: Date())
            labelDAQtimer.isHidden = false
            labelDAQtimer.text = String(theDiff)
        }
        
        if(errors.errorCount > 0) {
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
            
    }

    
    //===================================  REFRESH HERE ================================================
    
    func radioLast() {
        
        if(working.firstContact) {
            let theDiff: Int = getDateDiff(start: working.radioLastClock, end: Date())
            labelRadioTimer.text = String(theDiff)
        } else {
            labelRadioTimer.text = String("N/A")
        }
    }
    func getDateDiff(start: Date, end: Date) -> Int  {
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([Calendar.Component.second], from: start, to: end)
        let seconds = dateComponents.second
        return Int(seconds!)
    }
    
    func refreshView() {
        labelOxSafety.text = configuration.oxTankName
        labelFuelSafety.text = configuration.fuelTankName
        labelPressureSafety.text = configuration.pressureTankName
        labelSafetyPRS.text = configuration.rspareTankName
        working.viewLaunchRefreshScreen = false
        labelOxName.text = configuration.oxTankName
        labelFuelName.text = configuration.fuelTankName
    }
    
    func refreshData() {
        // ---------------- Standard Header
        if(padStatus.padHot) {
            labelSafetyPad.text = "HOT"
            labelSafetyPad.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        } else {
            labelSafetyPad.text = "SAFE"
            labelSafetyPad.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.padArmed) {
            imageArmedIcon.image = UIImage(named: "armed")
        } else {
            imageArmedIcon.image = UIImage(named: "disarm2")
        }
        if(errors.errorCount > 0) {
            buttonErrors.setTitle(" ", for: .normal)
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
        if(padConfig.updated == 1) {
            imageNoSync.isHidden = true
        } else {
            imageNoSync.isHidden = false
        }
        // ---------------- end standard header

        updatePressure()
        
        // GO NO GO POLL
        
        if(padStatus.padHot) {
            imagePadHot.image = UIImage(named: "good")
        } else {
            imagePadHot.image = UIImage(named: "bad")
        }
        
        if(padStatus.recoveryPower) {
            imageRecoveryPower.image = UIImage(named: "good")
        } else {
            imageRecoveryPower.image = UIImage(named: "bad")
        }
        imageRecoveryContinuity.image = UIImage(named: "good")
        if(!padStatus.altimeterBarmed && padConfig.recoveryArmB == 1) {
            imageRecoveryContinuity.image = UIImage(named: "bad")
        }
        if(!padStatus.altimeterAarmed && padConfig.recoveryArmA == 1) {
            imageRecoveryContinuity.image = UIImage(named: "bad")
        }
        if(padStatus.igniterContinuity) {
            imageIgniterContinuity.image = UIImage(named: "good")
        } else {
            imageIgniterContinuity.image = UIImage(named: "bad")
        }
        if(padStatus.processF2 == 1 && padStatus.processO2 == 1) {
        //if(padStatus.oxTankDisconnect && padStatus.fuelTankDisconnect) {
            imagePneumatics.image = UIImage(named: "good")
        } else {
            imagePneumatics.image = UIImage(named: "bad")
        }
        if(padStatus.padArmed) {
            imagePadArmed.image = UIImage(named: "good")
        } else {
            imagePadArmed.image = UIImage(named: "bad")
        }
        
        // ARMED SECTION
        if(padStatus.padArmed) {
            labelLaunch.text = "LAUNCH - ARMED"
            labelLaunch.backgroundColor = .red
            buttonIgniterArm.setTitle("DISARM", for: .normal)
            buttonIgniterFire.backgroundColor = .red
            buttonMainValvesOpen.backgroundColor = .red
        } else {
            labelLaunch.text = "LAUNCH - DISARMED"
            labelLaunch.backgroundColor = .black
            buttonIgniterArm.setTitle("ARM", for: .normal)
            buttonIgniterFire.backgroundColor = .gray
            buttonMainValvesOpen.backgroundColor = .gray
        }
        
        if(padStatus.mainValvesState) {
            buttonMainValvesOpen.setTitle("CLOSE", for: .normal)
        } else {
            buttonMainValvesOpen.setTitle("OPEN VALVES", for: .normal)
        }
        
        
        working.viewLaunchRefreshData = false
    }
    
    func updatePressure() {
        
        // =====================================   Standard header
        if(padConfig.POXenabled == 1){
            labelSafetyLox.isHidden = false
            labelOxSafety.isHidden = false
        } else {
            labelSafetyLox.isHidden = true
            labelOxSafety.isHidden = true
        }
        if(padStatus.pressureOne == 99999) {
            labelSafetyLox.text = String("ERR")
        } else {
            labelSafetyLox.text = String(padStatus.pressureOne)
        }
        if(padStatus.pressureOne > padConfig.POXalarm || padStatus.pressureOne == 99999) {
            labelSafetyLox.textColor = .red
        } else {
            labelSafetyLox.textColor = .black
        }
        //-----
        if(padConfig.PFLenabled == 1){
            labelSafetyFuel.isHidden = false
            labelFuelSafety.isHidden = false
        } else {
            labelSafetyFuel.isHidden = true
            labelFuelSafety.isHidden = true
        }
        if(padStatus.pressureTwo == 99999) {
            labelSafetyFuel.text = String("ERR")
        } else {
            labelSafetyFuel.text = String(padStatus.pressureTwo)
        }
        if(padStatus.pressureTwo > padConfig.PFLalarm || padStatus.pressureTwo == 99999) {
            labelSafetyFuel.textColor = .red
        } else {
            labelSafetyFuel.textColor = .black
        }
        //------
        if(padConfig.PPSenabled == 1){
            labelSafetyHelium.isHidden = false
            labelPressureSafety.isHidden = false
        } else {
            labelSafetyHelium.isHidden = true
            labelPressureSafety.isHidden = true
        }
        if(padStatus.pressureThree == 99999) {
            labelSafetyHelium.text = String("ERR")
        } else {
            labelSafetyHelium.text = String(padStatus.pressureThree)
        }
        if(padStatus.pressureThree > padConfig.PPSalarm || padStatus.pressureThree == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        if(padConfig.PRSenabled == 1){
            labelSafetyPRS.isHidden = false
            labelSafetyPRSvalue.isHidden = false
        } else {
            labelSafetyPRS.isHidden = true
            labelSafetyPRSvalue.isHidden = true
        }
        if(padStatus.pressureFour == 99999) {
            labelSafetyPRSvalue.text = String("ERR")
        } else {
            labelSafetyPRSvalue.text = String(padStatus.pressureFour)
        }
        if(padStatus.pressureFour > padConfig.PRSalarm || padStatus.pressureFour == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        
        //====== END HEADER
        
        // POGO Pressure
        if(padConfig.POXenabled == 1){
            labelOx2.isHidden = false
        } else {
            labelOx2.isHidden = true
        }
        if(padStatus.pressureOne == 99999) {
            labelOx2.text = String("ERR")
        } else {
            labelOx2.text = String(padStatus.pressureOne)
        }
        if(padStatus.pressureOne > padConfig.POXalarm || padStatus.pressureOne == 99999 || padStatus.pressureOne < Int(Double(padConfig.POXfill) * 0.8)) {
            labelOx2.textColor = .red
        } else {
            labelOx2.textColor = .green
        }
        //-----
        if(padConfig.PFLenabled == 1){
            labelFuel2.isHidden = false
        } else {
            labelFuel2.isHidden = true
        }
        if(padStatus.pressureTwo == 99999) {
            labelFuel2.text = String("ERR")
        } else {
            labelFuel2.text = String(padStatus.pressureTwo)
        }
        if(padStatus.pressureTwo > padConfig.PFLalarm || padStatus.pressureTwo == 99999 || padStatus.pressureTwo < Int(Double(padConfig.PFLfill) * 0.8)) {
            labelFuel2.textColor = .red
        } else {
            labelFuel2.textColor = .green
        }
    }

   
    
    @IBAction func buttonErrorsAction(_ sender: Any) {
        tabBarController?.selectedIndex = 5
    }
    

    @IBAction func buttonIgniterArmAction(_ sender: Any) {
        if(switchIgniterArm.isOn) {
          if(padStatus.padArmed) {
            working.radioMessage = "#ARM0,033,!"
            working.radioSend = true
            working.status = "Sent Disarm Request..."
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
          } else {
            if(padStatus.padHot){
                working.radioMessage = "#ARM1,033,!"
                working.radioSend = true
                working.status = "Sent Arm Request..."
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            } else {
                notHot()
            }
          }
            switchIgniterArm.isOn = false
        } else {
            denySend()
        }
    }

    @IBAction func buttonIgniterFireAction(_ sender: Any) {
        if(switchIgniterFire2.isOn) {
                if(padStatus.padArmed) { //must be armed to open, but not to close
                    if(padStatus.padHot){
                        working.radioMessage = "#FIRE,33,!"
                        working.radioSend = true
                        working.status = "Sent FIRE Request..."
                        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
                        //Send command twice just in case
                        let delay = DispatchTime.now() + 1.5
                        DispatchQueue.main.asyncAfter(deadline: delay) {
                            self.backupIgniterFire()
                        }
                    } else {
                        notHot()
                    }
                } else {
                    denyArmed()
                }
            switchIgniterFire2.isOn = false
        } else {
          denySend()
        }
    }
    func backupIgniterFire() {
        //back-up igniter 1.5 seconds later
        working.radioMessage = "#FIRE,33,!"
        working.radioSend = true
    }
    
    @IBAction func switchIgniter(_ sender: Any) {
        if(switchIgniterFire2.isOn) {
            if(padStatus.processF2 != 1 || padStatus.processO2 != 1) {
                igWarning();
            }
        }
    }
    
    func igWarning() { // popup alert
        
        let alert = UIAlertController(title: "WARNING!", message: "The QD Pneumatic Disconnects are not green", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    
    @IBAction func buttonMainValvesOpenAction(_ sender: Any) {
        if(switchMainValvesOpen2.isOn) {
            if(padStatus.mainValvesState) {
                working.radioMessage = "#MOFF,33,!"
                working.radioSend = true
                working.status = "Sent Main Valves Close Request..."
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
                let delay = DispatchTime.now() + 1.5
                DispatchQueue.main.asyncAfter(deadline: delay) {
                self.backupMainClose()
                }
                switchMainValvesOpen2.isOn = false
            } else {
                if(padStatus.padArmed) {
                    if(padStatus.padHot){
                        working.radioMessage = "#MON,33,!"
                        working.radioSend = true
                        working.status = "Sent Main Valves Open Request..."
                        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
                        let delay = DispatchTime.now() + 1.5
                        DispatchQueue.main.asyncAfter(deadline: delay) {
                            self.backupMainOpen()
                        }
                    } else {
                        notHot()
                    }
                } else {
                    denyArmed()
                }
                switchMainValvesOpen2.isOn = false
            }
        } else {
            denySend()
        }
    }
    func backupMainOpen() {
        //back-up main open 1.5 seconds later
        working.radioMessage = "#MON,33,!"
        working.radioSend = true
    }
    func backupMainClose() {
        //back-up main close 1.5 seconds later
        working.radioMessage = "#MOFF,33,!"
        working.radioSend = true
    }
    
    @IBAction func buttonAbortAction(_ sender: Any) {
        if(switchAbort2.isOn) {
            working.radioMessage = "#ABORT,33,!"
            working.radioSend = true
            working.status = "Sent ABORT Request..."
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            switchAbort2.isOn = false
            let delay = DispatchTime.now() + 1.5
            DispatchQueue.main.asyncAfter(deadline: delay) {
                self.backupAbort()
            }
        } else {
          denySend()
        }
    }
    func backupAbort() {
        //back-up Abort 1.5 seconds later
        working.radioMessage = "#ABORT,33,!"
        working.radioSend = true
    }
    
    
    @IBAction func buttonDAQaction(_ sender: Any) {
        
        if(working.DAQrecording) {
            working.radioMessage = "#DAQOFF,33,!"
            working.radioSend = true
            working.status = "Sent DAQ STOP Request..."
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
        } else {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyMMdd_HHmmss"
            let timestamp = formatter.string(from: Date())
            let fileSend = "\(timestamp)" + ".txt"
            working.radioMessage = "#DAQON,"+fileSend+",!" // send filename to use with current date-time (MCU has no time)
            working.radioSend = true
            working.status = "Sent DAQ START Request..."
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
        }
        
    }
    
    func denySend() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "You must unlock the safety before sending the request", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    
    @IBAction func buttonStatus(_ sender: Any) {
        working.radioMessage = "#S,033,!"
        working.radioSend = true
        working.status = "Sent Status Request..."
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
    }
    
    @IBAction func buttonCountdown(_ sender: Any) {
        if(working.countdown) {
            working.countdown = false
            
        } else {
            working.countdown = true
            working.countdownStart = Date()
        }
    }
    @IBAction func buttonCountdownReset(_ sender: Any) {
        labelClock.text = ":15"
        working.countdown = false
        
    }
    
    func denyArmed() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "The pad must be ARMED before sending the request", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    

    func updateClock() {
        let theDiff: Int = getDateDiff(start: working.countdownStart, end: Date())
        let (h,m,s) = secondsToHoursMinutesSeconds(seconds: theDiff)
        var cSec: Int = 0
        var displayClock: String = ""
        if (s < 16) {
            cSec = 15 - s;
            displayClock = ":" + "\(String(format: "%02d", cSec))"
        } else {
            displayClock = ":00"
            working.countdown = false
        }
        labelClock.text = displayClock
        /*
        if(m==0) {
            displayClock = ":" + "\(String(format: "%02d", s))"
        } else {
            displayClock = "\(String(format: "%02d", m))" + ":" + "\(String(format: "%02d", s))"
        }
        */
        
    }

    func secondsToHoursMinutesSeconds (seconds : Int) -> (Int, Int, Int) {
      return (seconds / 3600, (seconds % 3600) / 60, (seconds % 3600) % 60)
    }
    
    func notHot() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "The pad controller is not hot. Insert Safety Plug.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    
}

