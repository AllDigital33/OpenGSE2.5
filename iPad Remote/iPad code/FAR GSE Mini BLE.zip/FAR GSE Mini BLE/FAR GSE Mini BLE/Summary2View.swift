//
//  ViewController.swift
//  FAR Biprop Remote
//
//  Created by Brinker, Mike on 3/22/21.
//

import Foundation
import AVFoundation
import UIKit

// -------------  Bluetooth  ---------------------------------------
import CoreBluetooth
var myPeripheal:CBPeripheral?
var myCharacteristic:CBCharacteristic?
var myCharacteristicRX:CBCharacteristic?
var manager:CBCentralManager?
let serviceUUID = CBUUID(string: "3f0cf7c9-ee33-4449-88b8-4e05fdf2c163")
let BLE_Characteristic_uuid_Tx = "2347c909-41b0-466e-b984-267cfca13359"  //(Property = Write without response)
let BLE_Characteristic_uuid_Rx = "b339bc4e-a4cd-41aa-a286-7e05f0d1465f"   // (Property = Read/Notify)



class Summary2View: UIViewController, CBCentralManagerDelegate {

    @IBOutlet weak var labelStatus: UILabel!
    @IBOutlet weak var labelLOXPressurization: UILabel!
    @IBOutlet weak var labelLOXlineVent: UILabel!
    @IBOutlet weak var labelLOXpneumatic: UILabel!
    @IBOutlet weak var labelLOXrocketVent: UILabel!
    @IBOutlet weak var labelFuelPressurization: UILabel!
    @IBOutlet weak var labelFuelLineVent: UILabel!
    @IBOutlet weak var labelFuelPneumatic: UILabel!
    @IBOutlet weak var labelRocketVent: UILabel!
    @IBOutlet weak var labelLOXexternalTank: UILabel!
    @IBOutlet weak var labelFuelExternalTank: UILabel!
    @IBOutlet weak var labelMainValves: UILabel!
    @IBOutlet weak var labelIgniterContinuity: UILabel!
    @IBOutlet weak var labelIgniterArmed: UILabel!
    @IBOutlet weak var labelAltimeterPower: UILabel!
    @IBOutlet weak var labelAltAarmed: UILabel!
    @IBOutlet weak var labelAltBarmed: UILabel!
    @IBOutlet weak var imageRadioStatus: UIImageView!
    @IBOutlet weak var imageRadioTX: UIImageView!
    @IBOutlet weak var imageRadioRX: UIImageView!
    @IBOutlet weak var labelRocketConnected: UILabel!
    @IBOutlet weak var labelVoltage: UILabel!
    @IBOutlet weak var labelHazVoltage: UILabel!
    @IBOutlet weak var labelPadController: UILabel!
    @IBOutlet weak var gaugeViewOne: UIView!
    @IBOutlet weak var gaugeViewTwo: UIView!
    @IBOutlet weak var gaugeViewThree: UIView!
    @IBOutlet weak var labelSafetyPad: UILabel!
    @IBOutlet weak var labelSafetyLox: UILabel!
    @IBOutlet weak var labelSafetyFuel: UILabel!
    @IBOutlet weak var labelSafetyHelium: UILabel!
    @IBOutlet weak var labelOxValves: UILabel!
    @IBOutlet weak var labelFuelValves: UILabel!
    @IBOutlet weak var labelOxSafety: UILabel!
    @IBOutlet weak var labelFuelSafety: UILabel!
    @IBOutlet weak var labelPressureSafety: UILabel!
    @IBOutlet weak var imageArmedIcon: UIImageView!
    @IBOutlet weak var labelRadioTimer: UILabel!
    @IBOutlet weak var imageNoSync: UIImageView!
    @IBOutlet weak var labelSafetyPRS: UILabel!
    @IBOutlet weak var labelSafetyPRSvalue: UILabel!
    @IBOutlet weak var labelMCUtemp: UILabel!
    @IBOutlet weak var buttonErrors: UIButton!
    @IBOutlet weak var labelNoBLE: UILabel!
    
    // ------ BLE ---------------------------------
    private var txCharacteristic: CBCharacteristic!
    private var rxCharacteristic: CBCharacteristic!
    
    
    let gauge1 = gaugeSubView1(frame: CGRect(x: 0, y: 0, width: 250, height: 250))
    let gauge2 = gaugeSubView2(frame: CGRect(x: 0, y: 0, width: 250, height: 250))
    let gauge3 = gaugeSubView3(frame: CGRect(x: 0, y: 0, width: 250, height: 250))
    
    var player: AVAudioPlayer?
    var timerOne: Timer?
    var BLEbattRetry: Date = Date()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        UIApplication.shared.isIdleTimerDisabled = true
        UIDevice.current.isBatteryMonitoringEnabled = true
        
        readLocalConfig()
        
        //------- BLE  ----------------
        manager = CBCentralManager(delegate: self, queue: nil)
        if(!working.BLEstatus) {
            labelNoBLE.isHidden = false
            imageRadioStatus.image = UIImage(named: "bad")!
            working.radioConnected = false
        } else {
            labelNoBLE.isHidden = true
            imageRadioStatus.image = UIImage(named: "good")!
            working.radioConnected = true
        }
        
        
        imageRadioStatus.image = UIImage(named: "bad")!
        working.radioConnected = false
        
        refreshGauges()
        
        imageRadioTX.isHidden = true
        imageRadioRX.isHidden = true
        refreshData()
        refreshView()
        
        working.statusTimeout = Date()
        working.RXarrowTimeout = Date()
        working.TXarrowTimeout = Date()
        
        //Hide Radio Tab
        var theIndex: Int = 0
        if let viewControllers = tabBarController?.viewControllers {
            for viewController in viewControllers {
                let className = String(describing: Mirror(reflecting: viewController).subjectType)
                if className.contains("Radio") {
                    working.radioTab = false
                    radioVC = tabBarController?.viewControllers?.remove(at: theIndex) as! RadioView
                }
             theIndex += 1
            }
        }
        //Hide Files Tab
        var theIndex2: Int = 0
        if let viewControllers = tabBarController?.viewControllers {
            for viewController in viewControllers {
                let className = String(describing: Mirror(reflecting: viewController).subjectType)
                if className.contains("Files") {
                    working.filesTab = false
                    DAQfilesVC = tabBarController?.viewControllers?.remove(at: theIndex2) as! FilesView
                }
             theIndex2 += 1
            }
        }
        
        //housekeeping timer
        timerOne = Timer.scheduledTimer(timeInterval: 0.25, target: self, selector: #selector(self.housekeepingTimer), userInfo: nil, repeats: true)
        //FTP Send timer
        timerOne = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.FTPtimer), userInfo: nil, repeats: true)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(false)
        refreshView()
        refreshData()
    }
    
    @objc func FTPtimer() {
        if(FTPS.active) {sendTimer()}
    }
    
    @objc func housekeepingTimer() {
        if(working.viewStatusRefreshData) {refreshData()}
        if(working.viewStatusRefreshScreen) {refreshView()}
        
        // process anything on the send queue
        if(working.radioSend) {
            radioSend(theM: working.radioMessage)
            working.radioSend = false
        }
        
        // clear status
        if(working.statusTimeout < Date() && labelStatus.text != "") {
             labelStatus.text = ""
         }
         //update status
        if(working.statusTimeout > Date()) {
             labelStatus.text = working.status
         }
         // radio light
        if(working.RXarrowTimeout < Date() && imageRadioRX.isHidden == false) {
             imageRadioRX.isHidden = true
         }
        if(working.TXarrowTimeout < Date() && imageRadioTX.isHidden == false) {
             imageRadioTX.isHidden = true
         }
        if(!working.firstContact && working.BLEstatus) {
            working.status = "Waiting for first radio contact"
            working.statusTimeout = Date().addingTimeInterval(1000)
        }
        if(!working.BLEstatus) {
            
            if(configuration.BLEdevice == "null" || configuration.BLEdevice == "") {
                working.status = "No Bluetooth Device Configured - Go to Pairing in Config"
            } else {
                working.status = "Scanning for Bluetooth Connection"
            }
            working.statusTimeout = Date().addingTimeInterval(1000)
        }
        if(padConfig.updated == 0 && working.firstContact && working.configRetry < Date()) {
            
            working.radioMessage = "#S,033,!" //general request to send all
            working.radioSend = true
            working.status = "Requested Configuration..."
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            working.configRetry = Date().addingTimeInterval(30)  // try every 30 seconds
            
        }
        radioLast() // update radio last counter
        
        if(errors.errorCount > 0) {
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
        //---- check iPad battery for error state -----------
        let level = UIDevice.current.batteryLevel // 0-1 value
        working.iPadBatt = Int(Float(level * 100.0))
        if(working.iPadBatt > 0 && working.iPadBatt < 10) {
            errors.iPadBatt = 1
            errors.errorCount = 1
        } else {
            errors.iPadBatt = 0
        }
        
        //------ Get BLE Battery and Radio Status --------------
        if(working.BLEstatus == true && errors.BLEbatt == 2 && BLEbattRetry < Date()) {
            working.radioMessage = "#BLEBATT,033,!" //get BLE battery info
            working.radioSend = true
            BLEbattRetry = Date().addingTimeInterval(5)
        }
    }

    
    
    //===========================================================  GUAGES  =================================================
    
    func refreshGauges() {
        gauge1.eraseAll()
        gauge1.backgroundColor = .clear
        gaugeViewOne.addSubview(gauge1)
        gaugeViewOne.backgroundColor = .clear
        gauge1.gaugeName = configuration.oxTankName
        gauge1.gaugeMax = padConfig.POXrange
        gauge1.value = 0
        gauge1.gaugeAlarm = padConfig.POXalarm
        gauge1.draw(CGRect(x: 0, y: 0, width: 250, height: 250))
 
        gauge2.eraseAll()
        gauge2.backgroundColor = .clear
        gaugeViewTwo.addSubview(gauge2)
        gaugeViewTwo.backgroundColor = .clear
        gauge2.gaugeName = configuration.fuelTankName
        gauge2.value = 0
        gauge2.gaugeMax = padConfig.PFLrange
        gauge2.gaugeAlarm = padConfig.PFLalarm
        
        gauge3.eraseAll()
        gauge3.backgroundColor = .clear
        gaugeViewThree.addSubview(gauge3)
        gaugeViewThree.backgroundColor = .clear
        gauge3.gaugeName = configuration.pressureTankName
        gauge3.value = 0
        gauge3.gaugeAlarm = padConfig.PPSalarm
        gauge3.gaugeMax = padConfig.PPSrange
        
        
        gauge1.value = padStatus.pressureOne
        gauge2.value = padStatus.pressureTwo
        gauge3.value = padStatus.pressureThree
        
        if(padConfig.PPSenabled == 0){
            gaugeViewThree.isHidden = true
            gaugeViewTwo.center = CGPointMake(684, 220);
            gaugeViewOne.center = CGPointMake(342, 220);
        } else {
            gaugeViewThree.isHidden = false
            gaugeViewTwo.center = CGPointMake(512, 220);
            gaugeViewOne.center = CGPointMake(212, 220);
            gaugeViewThree.center = CGPointMake(812, 220);
            
        }
        
        
    }
    
    
    //************************************************  RADIO HANDLER HERE ************************************************
    
    func radioReceive(BLEstring: String)  {   // Radio Handler
    
            var dataString: String = BLEstring
            var goodSentence: Bool = false
            var FTPpacket: Bool = false
            var malformed: Bool = false
            imageRadioRX.isHidden = false
            working.RXarrowTimeout = Date() + 2
            
            //New logic to verify integrity and concatenate multiple sentences
            //first check for @ and ! characters
            let tempLeft: String = String(dataString.prefix(1))
            let tempRight: String = String(dataString.suffix(1))

            if (tempLeft == "$" && tempRight=="!") {
               // got a good FTP Packet
                let radioProcess: Int = processFTP(theData: dataString)
                //self.labelStatus.text = "Radio Process = " + "\(String(radioProcess))"
                if (radioProcess != 99) { //valid data
                    self.playSound(theFile: "ticks")
                }
                FTPpacket = true
               
            }
            if(!FTPpacket) {
                if (tempLeft == "#" && tempRight=="!") {
                    //Got a good sentence
                    if(working.lastRadio) { //clear previous partial sentence
                        malformed = true
                        working.lastRadio = false
                    }
                    goodSentence = true
                } else { // Process not regular sentence
                    if (!(tempLeft == "#" || tempRight=="!")) { //garbage clear previous
                        working.lastRadio = false
                        malformed = true
                    }
                    if (tempLeft == "#") {  //Potentially Valid first half
                        if(working.lastRadio == true) { //clear previous malformed first half
                            malformed = true
                            working.lastRadio = false
                        } //valid first half
                        working.lastRadio = true
                        working.lastRadioString = dataString
                        dataString = dataString + " (PARTIAL)"
                    }
                    if (tempRight == "!") {  //Potentially Valid second half
                        if(working.lastRadio == true) { //got a match!
                            dataString = working.lastRadioString + dataString
                            goodSentence = true
                            working.lastRadio = false
                            working.radioRXarray.append(String("(concatenated)"))
                            //zzz logging(message: String("(concatenated)"), filename: workingData.radioLog!)
                        } else {
                            malformed = true
                        }
                    } //end valid second half
                    if (malformed == true) {
                        dataString = dataString + " (MALFORMED!)"
                    }
                } //end integrity check
            } // end not FTP packet
            //Now Log the radio line
            let now = Date()
            let formatter = DateFormatter()
            formatter.dateStyle = .short
            formatter.timeStyle = .medium
            let datetime = formatter.string(from: now)
            //log it to memory and disk
            working.radioRXarray.append(String(datetime + "  " + dataString))
            //zzz logging(message: dataString, filename: workingData.radioLog!)
    
            // ***************************  PROCESS GOOD RADIO SENTANCES HERE **********************************

           if(goodSentence == true) {
            let radioProcess: Int = processRadio(theData: dataString)
            //self.labelStatus.text = "Radio Process = " + "\(String(radioProcess))"
            if (radioProcess != 99 && radioProcess != 9) { //received flight data (99 = bad, 9 = silent)
                //self.flightDataRefresh()
               // if(configData.alertRadioRX) {self.playSound(theFile: "radioRX")}
                self.playSound(theFile: "radioRX")
            }
            
          } // end good sentence
            
            
        
        
    }
    
    func radioSend(theM: String)
    {
        if(working.BLEstatus) {
            let textToSend: String! = theM
            
            imageRadioTX.isHidden = false
            working.TXarrowTimeout = Date() + 2
            if(textToSend.count > 126) {
                working.status = "SEND ERROR STRING TOO LONG"
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            }
            if(textToSend.count > 63) {
                let sub1 = textToSend.prefix(63)
                let sub2 = textToSend.suffix(textToSend.count - 63)
                sendBLE(text: String(sub1))
                let secondsToDelay = 1.0
                DispatchQueue.main.asyncAfter(deadline: .now() + secondsToDelay) {
                    self.sendBLE(text: String(sub2))
                }
            } else {
                sendBLE(text: textToSend) // normal send
            }
            
            if(!FTPS.active)  {
               self.playSound(theFile: "event")
            } else {
                self.playSound(theFile: "ticks")
            }
            let now = Date()
            let formatter = DateFormatter()
            formatter.dateStyle = .short
            formatter.timeStyle = .medium
            let datetime = formatter.string(from: now)
            working.radioRXarray.append(String(datetime + "  SENT: " + textToSend!))
        } else {
            working.status = "Error - No bluetooth radio connection"
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
        }
    }
    
    func sendBLE(text: String) {  //sneds data to the BLE bridge
        if (myPeripheal != nil && myCharacteristic != nil) {
            print("BLE sent")
            let data = text.data(using: .utf8)
            myPeripheal!.writeValue(data!,  for: myCharacteristic!, type: CBCharacteristicWriteType.withResponse)
        } else {
            working.status = "Error - No bluetooth radio connection"
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
        }
    }
    
    
    //===================================  REFRESH HERE ================================================
    
    func radioLast() {
        
        if(working.firstContact) {
            let theDiff: Int = getDateDiff(start: working.radioLastClock, end: Date())
            labelRadioTimer.text = String(theDiff)
        } else {
            labelRadioTimer.text = String("N/A")
        }
    }
    func getDateDiff(start: Date, end: Date) -> Int  {
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([Calendar.Component.second], from: start, to: end)
        let seconds = dateComponents.second
        return Int(seconds!)
    }

    func refreshView() {
        refreshGauges()
        labelOxValves.text = configuration.oxTankName + " Valves"
        labelFuelValves.text = configuration.fuelTankName + " Valves"
        labelOxSafety.text = configuration.oxTankName
        labelFuelSafety.text = configuration.fuelTankName
        labelPressureSafety.text = configuration.pressureTankName
        labelSafetyPRS.text = configuration.rspareTankName
        working.viewStatusRefreshScreen = false
    }
    
    func refreshData() {
 
        
        // ------------------------ Valves --------------------------
        //    * V1 = Fuel line vent
        //    * V2 = Fuel pnuematic disconnect valve
        //    * V3 = Ox line vent
        //    * V4 = Fuel pressurization valve (haz)
        //    * V5 = Ox pressurization valve (haz)
        //    * V6 = Ox pnuematic disconnect
        //    * V7 = Fuel rocket vent
        //    * V8 = Ox rocket vent
        labelLOXPressurization.text = openClosed(theState: padStatus.valveFive)
        labelLOXPressurization.textColor = blackGreen(theState: padStatus.valveFive)
        labelLOXlineVent.text = openClosed(theState: padStatus.valveThree)
        labelLOXlineVent.textColor = blackGreen(theState: padStatus.valveThree)
        labelLOXpneumatic.text = openClosed(theState: padStatus.valveSix)
        labelLOXpneumatic.textColor = blackGreen(theState: padStatus.valveSix)
        labelLOXrocketVent.text = openClosed(theState: padStatus.valveEight)
        labelLOXrocketVent.textColor = blackGreen(theState: padStatus.valveEight)
        labelFuelPressurization.text = openClosed(theState: padStatus.valveFour)
        labelFuelPressurization.textColor = blackGreen(theState: padStatus.valveFour)
        labelFuelLineVent.text = openClosed(theState: padStatus.valveOne)
        labelFuelLineVent.textColor = blackGreen(theState: padStatus.valveOne)
        labelFuelPneumatic.text = openClosed(theState: padStatus.valveTwo)
        labelFuelPneumatic.textColor = blackGreen(theState: padStatus.valveTwo)
        labelRocketVent.text = openClosed(theState: padStatus.valveEight)
        labelRocketVent.textColor = blackGreen(theState: padStatus.valveEight)
        
        labelLOXexternalTank.text = connectDisconnect(theState: padStatus.oxTankDisconnect)
        labelLOXexternalTank.textColor = blackRed(theState: padStatus.oxTankDisconnect)
        labelFuelExternalTank.text = connectDisconnect(theState: padStatus.fuelTankDisconnect)
        labelFuelExternalTank.textColor = blackRed(theState: padStatus.fuelTankDisconnect)
            
        labelMainValves.text = openClosed(theState: padStatus.mainValvesState)
        labelMainValves.textColor = blackGreen(theState: padStatus.mainValvesState)
            
        labelIgniterContinuity.text = noYes(theState: padStatus.igniterContinuity)
        labelIgniterContinuity.textColor = redGreen(theState: padStatus.igniterContinuity)
        
        labelIgniterArmed.text = noYes(theState: padStatus.igniterArmed)
        labelIgniterArmed.textColor = greenRed(theState: padStatus.igniterArmed)
        
        if(padStatus.recoveryPower) {
            labelAltimeterPower.text = "ON"
            if(padConfig.recoveryArmA == 1) {
                labelAltAarmed.text = noYes(theState: padStatus.altimeterAarmed)
                labelAltAarmed.textColor = redGreen(theState: padStatus.altimeterAarmed)
            } else {
                labelAltAarmed.text = "n/a"
                labelAltAarmed.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
            }
            if(padConfig.recoveryArmB == 1) {
                labelAltBarmed.text = noYes(theState: padStatus.altimeterBarmed)
                labelAltBarmed.textColor = redGreen(theState: padStatus.altimeterBarmed)
            } else {
                labelAltBarmed.text = "n/a"
                labelAltBarmed.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
            }
        } else {
            labelAltimeterPower.text = "OFF"
            labelAltAarmed.text = "n/a"
            labelAltBarmed.text = "n/a"
            labelAltAarmed.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
            labelAltBarmed.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
        }
        labelAltimeterPower.textColor = redGreen(theState: padStatus.recoveryPower)
        // zzz add radio status logic ?
        labelRocketConnected.text = connectDisconnect2(theState: padStatus.rocketConnected)
        labelRocketConnected.textColor = redGreen(theState: padStatus.rocketConnected)
        
        labelVoltage.text = String(format: "%.1f", padStatus.mainVolts) + "v"
        labelHazVoltage.text = String(format: "%.1f", padStatus.hazVolts) + "v"
        labelMCUtemp.text = String(padStatus.CPUtemp) + "° F"
        if(padStatus.CPUtemp >= padConfig.CPUtempAlarm) {
            labelMCUtemp.textColor = UIColor(red: 255, green: 0, blue: 0, alpha: 1)
        } else {
            labelMCUtemp.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
        }
        if(working.radioConnected) {
            imageRadioStatus.image = UIImage(named: "good")!
        } else {
            imageRadioStatus.image = UIImage(named: "bad")!
        }
        
        
        
        // ---------------- Standard Header
        if(padStatus.padHot) {
            labelSafetyPad.text = "HOT"
            labelSafetyPad.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        } else {
            labelSafetyPad.text = "SAFE"
            labelSafetyPad.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.padArmed) {
            imageArmedIcon.image = UIImage(named: "armed")
        } else {
            imageArmedIcon.image = UIImage(named: "disarm2")
        }
        if(errors.errorCount > 0) {
            buttonErrors.setTitle(" ", for: .normal)
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
        if(padConfig.updated == 1) {
            imageNoSync.isHidden = true
        } else {
            imageNoSync.isHidden = false
        }
        // ---------------- end standard header
        
        updatePressure()
        working.viewStatusRefreshData = false
    }
    
    func openClosed(theState: Bool) -> String {
        if(theState) {
           return "open"
        } else {
            return "closed"
        }
    }
    func blackGreen(theState: Bool) -> UIColor {  // 0 blaock, 1 green
        if(theState) {
           return UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        } else {
            return UIColor(red: 0, green: 0, blue: 0, alpha: 1)
        }
    }
    func connectDisconnect(theState: Bool) -> String {
        if(theState) {
           return "disconnected"
        } else {
            return "connected"
        }
    }
    func connectDisconnect2(theState: Bool) -> String {
        if(theState) {
           return "connected"
        } else {
            return "disconnected"
        }
    }
    func greenRed(theState: Bool) -> UIColor {  // 1 red, 0 green
        if(theState) {
           return UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        } else {
            return UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
    }
    func redGreen(theState: Bool) -> UIColor {  // 0 red, 1 green
        if(theState) {
            return UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        } else {
            return UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        }
    }
    func blackRed(theState: Bool) -> UIColor {  // 0 red, 1 green
        if(theState) {
            return UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        } else {
            return UIColor(red: 0, green: 0, blue: 0, alpha: 1)
        }
    }
    func noYes(theState: Bool) -> String {
        if(theState) {
           return "yes"
        } else {
            return "no"
        }
    }
    

    func updatePressure() {
        
        
        
        // =====================================   Standard header
        if(padConfig.POXenabled == 1){
            labelSafetyLox.isHidden = false
            labelOxSafety.isHidden = false
        } else {
            labelSafetyLox.isHidden = true
            labelOxSafety.isHidden = true
        }
        if(padStatus.pressureOne == 99999) {
            labelSafetyLox.text = String("ERR")
        } else {
            labelSafetyLox.text = String(padStatus.pressureOne)
        }
        if(padStatus.pressureOne > padConfig.POXalarm || padStatus.pressureOne == 99999) {
            labelSafetyLox.textColor = .red
        } else {
            labelSafetyLox.textColor = .black
        }
        //-----
        if(padConfig.PFLenabled == 1){
            labelSafetyFuel.isHidden = false
            labelFuelSafety.isHidden = false
        } else {
            labelSafetyFuel.isHidden = true
            labelFuelSafety.isHidden = true
        }
        if(padStatus.pressureTwo == 99999) {
            labelSafetyFuel.text = String("ERR")
        } else {
            labelSafetyFuel.text = String(padStatus.pressureTwo)
        }
        if(padStatus.pressureTwo > padConfig.PFLalarm || padStatus.pressureTwo == 99999) {
            labelSafetyFuel.textColor = .red
        } else {
            labelSafetyFuel.textColor = .black
        }
        //------
        if(padConfig.PPSenabled == 1){
            labelSafetyHelium.isHidden = false
            labelPressureSafety.isHidden = false
        } else {
            labelSafetyHelium.isHidden = true
            labelPressureSafety.isHidden = true
        }
        if(padStatus.pressureThree == 99999) {
            labelSafetyHelium.text = String("ERR")
        } else {
            labelSafetyHelium.text = String(padStatus.pressureThree)
        }
        if(padStatus.pressureThree > padConfig.PPSalarm || padStatus.pressureThree == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        if(padConfig.PRSenabled == 1){
            labelSafetyPRS.isHidden = false
            labelSafetyPRSvalue.isHidden = false
        } else {
            labelSafetyPRS.isHidden = true
            labelSafetyPRSvalue.isHidden = true
        }
        if(padStatus.pressureFour == 99999) {
            labelSafetyPRSvalue.text = String("ERR")
        } else {
            labelSafetyPRSvalue.text = String(padStatus.pressureFour)
        }
        if(padStatus.pressureFour > padConfig.PRSalarm || padStatus.pressureFour == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        
        //====== END HEADER
        
        gauge1.value = padStatus.pressureOne
        gauge2.value = padStatus.pressureTwo
        gauge3.value = padStatus.pressureThree
        
        
        
        if(padStatus.pressureOne >= padConfig.POXalarm && working.oxAlarm == 0) {
            //sound the ox pressure alarm
            speakNow(theMessage: "Tank Pressure Alert, Oxidizer")
            working.oxAlarm = 2
        }
        if(padStatus.pressureOne < padConfig.POXalarm && working.oxAlarm > 0) {
            working.oxAlarm = 0 // resets the oxAlarm
        }
        if(padStatus.pressureTwo >= padConfig.PFLalarm && working.fuelAlarm == 0) {
            //sound the fuel pressure alarm
            speakNow(theMessage: "Tank Pressure Alert, Fuel")
            working.fuelAlarm = 2
        }
        if(padStatus.pressureTwo < padConfig.PFLalarm && working.fuelAlarm > 0) {
            working.fuelAlarm = 0 // resets the oxAlarm
        }
        
        
    }
    

    
    func playSound(theFile: String) {
        if(configuration.mute == false) {
            guard let url = Bundle.main.url(forResource: theFile, withExtension: "mp3") else { return }

            do {
                try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
                try AVAudioSession.sharedInstance().setActive(true)
                player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
                guard let player = player else { return }
                player.play()
            } catch let error {
                print(error.localizedDescription)
            }
        }
    }
    
    @IBAction func buttonStatus(_ sender: Any) {
        
        working.radioMessage = "#S,033,!"
        working.radioSend = true
        working.status = "Sent Status Request..."
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
    }
    
    @IBAction func buttonHopper(_ sender: Any) {
        speakNow(theMessage: "Do you know my friend Hopper?")
    }
    
    @IBAction func buttonErrorsAction(_ sender: Any) {
        tabBarController?.selectedIndex = 5
    }
    
    
    
    //====================================================  BLE PROCESSING  =================================================================
        
        
        func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
            //cycles through all visible bluetooth devices
            let BLEitem: String = advertisementData[CBAdvertisementDataLocalNameKey] as? String ?? "nil"
            
            if(working.BLEsearch && configuration.BLEdevice == "null") {
                if(BLEitem.contains("RocketTalk")) {
                    working.BLEdevices.append(BLEitem)
                    print("BLE core found one")
                }
            }
            if (advertisementData[CBAdvertisementDataLocalNameKey] as? String ?? "nil") == configuration.BLEdevice {
                myPeripheal = peripheral
                myPeripheal?.delegate = self
                manager?.connect(myPeripheal!, options: nil)
                manager?.stopScan()
            }
        }
        
        func centralManagerDidUpdateState(_ central: CBCentralManager) {
            switch central.state {
            case .poweredOff:
                print("Bluetooth is switched off")
            case .poweredOn:
                print("Bluetooth is switched on")
                manager?.stopScan()
                print("Waiting for a connection...0")
                manager?.scanForPeripherals(withServices: nil, options: nil)
            case .unsupported:
                print("Bluetooth is not supported")
            default:
                print("Unknown state")
            }
        }
       
        
        func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
            peripheral.discoverServices([serviceUUID])
            print("Connected to " +  peripheral.name!)
            
            labelNoBLE.isHidden = true
            imageRadioStatus.image = UIImage(named: "good")!
            working.radioConnected = true
            working.BLEstatus = true
            
            
        }
        
        func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
            print("Disconnected from " +  peripheral.name!)
            myPeripheal = nil
            myCharacteristic = nil
            
            labelNoBLE.isHidden = false
            imageRadioStatus.image = UIImage(named: "bad")!
            working.radioConnected = false
            working.BLEstatus = false
            manager?.stopScan()
            print("Waiting for a connection...2")
            manager?.scanForPeripherals(withServices: nil, options: nil)
            
        }
        
        func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
            print(error!)
        }
        
    
    
    
    
    /*
    func deviceDetected(_ thePort: RedSerialPort) {
        
        imageRadioStatus.image = UIImage(named: "good")!
        working.radioConnected = true
        myPort = thePort
        myPort.delegate = self
        myPort.baudRate = 19200;
        myPort.dataConfiguration = kDataConfig_8N1;
        self.doReceive()
    }
    
    func deviceDisconnected(_ thePort: RedSerialPort) {
        imageRadioStatus.image = UIImage(named: "bad")!
        working.radioConnected = false
        myPort = nil
    }
    */
    
  
    
    
}  // end view controller 






// ============================================  BLE EXTENSION =============================================================

extension Summary2View: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard let services = peripheral.services else { return }
        for service in services {
            peripheral.discoverCharacteristics(nil, for: service)
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard let characteristics = service.characteristics else { return }
        myCharacteristic = characteristics[1]
        myCharacteristicRX = characteristics[0]
        print("Evaluating Characteristics / count:  " + String(characteristics.count))
        //print(myCharacteristic?.uuid.uuidString)
        //print(myCharacteristicRX?.uuid.uuidString)
        //print("Found \(characteristics.count) characteristics.")
        for characteristic in characteristics {
            //print(characteristic.uuid)
          if (characteristic.uuid.uuidString.uppercased() == BLE_Characteristic_uuid_Rx.uppercased())  {
            rxCharacteristic = characteristic
            peripheral.setNotifyValue(true, for: rxCharacteristic!)
            peripheral.readValue(for: characteristic)
            print("RX Characteristic: \(rxCharacteristic.uuid)")
          }
          if (characteristic.uuid.uuidString.uppercased() == BLE_Characteristic_uuid_Tx.uppercased()){
            txCharacteristic = characteristic
            print("TX Characteristic: \(txCharacteristic.uuid)")
          }
        }
    }
    
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {

      var characteristicASCIIValue = NSString()
      guard characteristic == rxCharacteristic,
      let characteristicValue = characteristic.value,
      let ASCIIstring = NSString(data: characteristicValue, encoding: String.Encoding.utf8.rawValue) else { return }
      characteristicASCIIValue = ASCIIstring
        print("RX: ")
      print(((characteristicASCIIValue as String)))
        
      radioReceive(BLEstring: String(ASCIIstring))
    }

}
