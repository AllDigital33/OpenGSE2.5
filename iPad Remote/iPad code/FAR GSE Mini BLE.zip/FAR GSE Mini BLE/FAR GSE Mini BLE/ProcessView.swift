//
//  ProcessView.swift
//  FAR Biprop Remote
//
//  Created by Brinker, Mike on 3/23/21.
//


import Foundation
import AVFoundation
import UIKit

class ProcessView: UIViewController {

    @IBOutlet weak var labelOneStatus: UILabel!
    @IBOutlet weak var labelTwoStatus: UILabel!
    @IBOutlet weak var labelThreeStatus: UILabel!
    @IBOutlet weak var labelFourStatus: UILabel!

    @IBOutlet weak var labelSixStatus: UILabel!

    @IBOutlet weak var labelAbortStatus: UILabel!
    @IBOutlet weak var labelAbortCancelStatus: UILabel!
    @IBOutlet weak var buttonOneSend: UIButton!
    @IBOutlet weak var buttonTwoSend: UIButton!
    @IBOutlet weak var buttonThreeSend: UIButton!
    @IBOutlet weak var buttonFourSend: UIButton!

    @IBOutlet weak var buttonSixSend: UIButton!

    @IBOutlet weak var buttonAbortSend: UIButton!
    @IBOutlet weak var buttonAbortCancelSend: UIButton!
    @IBOutlet weak var switchOne: UISwitch!
    @IBOutlet weak var switchTwo: UISwitch!
    @IBOutlet weak var switchThree: UISwitch!
    @IBOutlet weak var switchFour: UISwitch!
 
    @IBOutlet weak var switchSix: UISwitch!

    @IBOutlet weak var switchAbort: UISwitch!
    @IBOutlet weak var switchAbortCancel: UISwitch!

    @IBOutlet weak var labelStatus: UILabel!
    
    @IBOutlet weak var labelSafetyPad: UILabel!
    @IBOutlet weak var labelSafetyLox: UILabel!
    @IBOutlet weak var labelSafetyFuel: UILabel!
    @IBOutlet weak var labelSafetyHelium: UILabel!
    @IBOutlet weak var labelOxSafety: UILabel!
    @IBOutlet weak var labelFuelSafety: UILabel!
    @IBOutlet weak var labelPressureSafety: UILabel!
    @IBOutlet weak var imageArmedIcon: UIImageView!
    @IBOutlet weak var buttonArm: UIButton!
    @IBOutlet weak var labelArmStatus: UILabel!
    @IBOutlet weak var switchArm: UISwitch!
    
    @IBOutlet weak var labelFuelTank: UILabel!
    @IBOutlet weak var labelPressurizeFuelTank: UILabel!
    @IBOutlet weak var labelDepressurizeFuel: UILabel!
    @IBOutlet weak var labelOpenFuelLine: UILabel!
    @IBOutlet weak var labelLoxTank: UILabel!
    @IBOutlet weak var labelPressurizeLoxTank: UILabel!
    @IBOutlet weak var labelDepressurizeLox: UILabel!
    @IBOutlet weak var labelOpenLoxLine: UILabel!
    @IBOutlet weak var labelRadioTimer: UILabel!
    
    @IBOutlet weak var labelLOXdetail: UILabel!
    @IBOutlet weak var labelFuelDetail: UILabel!
    @IBOutlet weak var labelSafetyPRS: UILabel!
    @IBOutlet weak var labelSafetyPRSvalue: UILabel!
    @IBOutlet weak var imageNoSync: UIImageView!
    @IBOutlet weak var buttonErrors: UIButton!
    @IBOutlet weak var buttonReset: UIButton!
    @IBOutlet weak var sliderFuel: UISlider!
    @IBOutlet weak var textFuelpsi: UITextField!
    @IBOutlet weak var buttonFuelUpdate: UIButton!
    @IBOutlet weak var sliderLOX: UISlider!
    @IBOutlet weak var textLOXpsi: UITextField!
    @IBOutlet weak var buttonLOXupdate: UIButton!
    @IBOutlet weak var buttonFuelSettings: UIButton!
    @IBOutlet weak var buttonLOXsettings: UIButton!
    
    
    var player: AVAudioPlayer?
    var timerOne: Timer?


    
    override func viewDidLoad() {
        super.viewDidLoad()
        buttonOneSend.layer.cornerRadius = 6
        buttonTwoSend.layer.cornerRadius = 6
        buttonThreeSend.layer.cornerRadius = 6
        buttonFourSend.layer.cornerRadius = 6
        buttonArm.layer.cornerRadius = 6
        buttonSixSend.layer.cornerRadius = 6
        buttonReset.layer.cornerRadius = 6
        buttonLOXupdate.layer.cornerRadius = 6
        buttonFuelUpdate.layer.cornerRadius = 6
        
        buttonAbortSend.layer.cornerRadius = 6
        buttonAbortCancelSend.layer.cornerRadius = 6
        labelStatus.text = ""
        //----------------------------------------------
        sliderFuel.isHidden = true
        textFuelpsi.isHidden = true
        buttonFuelUpdate.isHidden = true
        sliderLOX.isHidden = true
        textLOXpsi.isHidden = true
        buttonLOXupdate.isHidden = true
        buttonFuelSettings.isHidden = false
        buttonLOXsettings.isHidden = false
        labelLOXdetail.isHidden = false
        labelFuelDetail.isHidden = false
        
        //housekeeping timer
        timerOne = Timer.scheduledTimer(timeInterval: 0.25, target: self, selector: #selector(self.housekeepingTimer), userInfo: nil, repeats: true)
        refreshView()
        refreshData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(false)
        refreshView()
        refreshData()

        
    }
    
    @objc func housekeepingTimer() {
        
        if(working.viewProcessRefreshScreen) {refreshView()}
        if(working.viewProcessRefreshData) {refreshData()}
        
        // clear status
        if(working.statusTimeout < Date() && labelStatus.text != "") {
             labelStatus.text = ""
         }
         //update status
        if(working.statusTimeout > Date()) {
             labelStatus.text = working.status
         }
        radioLast() // update radio last counter
        
        if(errors.errorCount > 0) {
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
    }

    //===================================  REFRESH HERE ================================================
    
    func radioLast() {
        
        if(working.firstContact) {
            let theDiff: Int = getDateDiff(start: working.radioLastClock, end: Date())
            labelRadioTimer.text = String(theDiff)
        } else {
            labelRadioTimer.text = String("N/A")
        }
    }
    func getDateDiff(start: Date, end: Date) -> Int  {
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([Calendar.Component.second], from: start, to: end)
        let seconds = dateComponents.second
        return Int(seconds!)
    }
    
    func refreshView() {
        labelOxSafety.text = configuration.oxTankName
        labelFuelSafety.text = configuration.fuelTankName
        labelPressureSafety.text = configuration.pressureTankName
        labelSafetyPRS.text = configuration.rspareTankName
        //tank name refresh
        labelFuelTank.text = configuration.fuelTankName.uppercased() + " TANK"
        labelPressurizeFuelTank.text = "Pressurize " + configuration.fuelTankName + " Tank to " + String(padStatus.fuelFill) + " psi"

        labelDepressurizeFuel.text = "QD Disconnect " + configuration.fuelTankName + " Umbilical"
        labelOpenFuelLine.text = "Open " + configuration.fuelTankName + " line vent valve then disconnect umbilical"
        labelLoxTank.text = configuration.oxTankName.uppercased() + " TANK"
        labelPressurizeLoxTank.text = "Pressurize " + configuration.oxTankName + " Tank to " + String(padStatus.oxFill) + " psi"
        labelDepressurizeLox.text = "QD Disconnect " + configuration.oxTankName + " Umbilical"
        labelOpenLoxLine.text = "Open " + configuration.fuelTankName + " line vent valve then disconnect umbilical"
        
        //------- Refresh Sliders and text boxes ---------------
        sliderFuel.minimumValue = 0
        sliderFuel.maximumValue = Float(padConfig.PFLrange)
        sliderFuel.value = Float(padStatus.fuelFill)
        textFuelpsi.text = String(padStatus.fuelFill)
        sliderLOX.minimumValue = 0
        sliderLOX.maximumValue = Float(padConfig.POXrange)
        sliderLOX.value = Float(padStatus.oxFill)
        textLOXpsi.text = String(padStatus.oxFill)
        
        sliderFuel.isHidden = true
        textFuelpsi.isHidden = true
        buttonFuelUpdate.isHidden = true
        sliderLOX.isHidden = true
        textLOXpsi.isHidden = true
        buttonLOXupdate.isHidden = true
        buttonFuelSettings.isHidden = false
        buttonLOXsettings.isHidden = false
        labelLOXdetail.isHidden = false
        labelFuelDetail.isHidden = false
        working.viewProcessRefreshScreen = false
        
        
    }
    
    func refreshData() {
        
        updatePressure()
        working.viewProcessRefreshData = false
        
        // ---------------- Standard Header
        if(padStatus.padHot) {
            labelSafetyPad.text = "HOT"
            labelSafetyPad.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        } else {
            labelSafetyPad.text = "SAFE"
            labelSafetyPad.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.padArmed) {
            imageArmedIcon.image = UIImage(named: "armed")
        } else {
            imageArmedIcon.image = UIImage(named: "disarm2")
        }
        if(errors.errorCount > 0) {
            buttonErrors.setTitle(" ", for: .normal)
            buttonErrors.isHidden = false
        } else {
            buttonErrors.isHidden = true
        }
        if(padConfig.updated == 1) {
            imageNoSync.isHidden = true
        } else {
            imageNoSync.isHidden = false
        }
        // ---------------- end standard header
        
        
        if(padStatus.padArmed) {
            labelArmStatus.text = "ARMED"
            labelArmStatus.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
            buttonArm.setTitle("DISARM", for: .normal)
        } else {
            labelArmStatus.text = "DISARMED"
            labelArmStatus.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
            buttonArm.setTitle("ARM", for: .normal)
        }
        // Update process status
        // can be 0- not run, 1 - complete, 2 - running, 3-stopped
        // zzz add new psi variables
        
        //------------ C1 Close all valves --------------------------
        if(padStatus.processC1 == 0) {
            buttonOneSend.setTitle("Initiate", for: .normal)
            labelOneStatus.text = ""
        }
        if(padStatus.processC1 == 1) {
            buttonOneSend.setTitle("Resend", for: .normal)
            labelOneStatus.text = "Complete"
            labelOneStatus.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.processC1 == 2) {
            buttonOneSend.setTitle("Resend", for: .normal)
            labelOneStatus.text = "In progress"
            labelOneStatus.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        }
        if(padStatus.processC1 == 3) {
            buttonOneSend.setTitle("Resend", for: .normal)
            labelOneStatus.text = "Stopped"
            labelOneStatus.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        }
        //------------ F1 Pressurize Fuel Tank --------------------------
        if(padStatus.processF1 == 0) {
            buttonTwoSend.setTitle("Initiate", for: .normal)
            labelTwoStatus.text = ""
        }
        if(padStatus.processF1 == 1) {
            buttonTwoSend.setTitle("Resend", for: .normal)
            labelTwoStatus.text = "Complete"
            labelTwoStatus.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.processF1 == 2) {
            buttonTwoSend.setTitle("Cancel", for: .normal)
            labelTwoStatus.text = "In progress"
            labelTwoStatus.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        }
        if(padStatus.processF1 == 3) {
            buttonTwoSend.setTitle("Resend", for: .normal)
            labelTwoStatus.text = "Stopped"
            labelTwoStatus.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        }
        //------------ F2 Depressurize and Disconnect --------------------------
        if(padStatus.processF2 == 0) {
            buttonFourSend.setTitle("Initiate", for: .normal)
            labelFourStatus.text = ""
        }
        if(padStatus.processF2 == 1) {
            buttonFourSend.setTitle("Resend", for: .normal)
            labelFourStatus.text = "Complete"
            labelFourStatus.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.processF2 == 2) {
            buttonFourSend.setTitle("Resend", for: .normal)
            labelFourStatus.text = "In progress"
            labelFourStatus.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        }
        if(padStatus.processF2 == 3) {
            buttonFourSend.setTitle("Resend", for: .normal)
            labelFourStatus.text = "Stopped"
            labelFourStatus.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        }
        //------------ O1 Pressurize Ox Tank --------------------------
        if(padStatus.processO1 == 0) {
            buttonThreeSend.setTitle("Initiate", for: .normal)
            labelThreeStatus.text = ""
        }
        if(padStatus.processO1 == 1) {
            buttonThreeSend.setTitle("Resend", for: .normal)
            labelThreeStatus.text = "Complete"
            labelThreeStatus.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.processO1 == 2) {
            buttonThreeSend.setTitle("Cancel", for: .normal)
            labelThreeStatus.text = "In progress"
            labelThreeStatus.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        }
        if(padStatus.processO1 == 3) {
            buttonThreeSend.setTitle("Resend", for: .normal)
            labelThreeStatus.text = "Stopped"
            labelThreeStatus.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        }
        //------------ O2 Depressurize and Disconnect --------------------------
        if(padStatus.processO2 == 0) {
            buttonSixSend.setTitle("Initiate", for: .normal)
            labelSixStatus.text = ""
        }
        if(padStatus.processO2 == 1) {
            buttonSixSend.setTitle("Resend", for: .normal)
            labelSixStatus.text = "Complete"
            labelSixStatus.textColor = UIColor(red: 0, green: 144/255, blue: 81/255, alpha: 1)
        }
        if(padStatus.processO2 == 2) {
            buttonSixSend.setTitle("Resend", for: .normal)
            labelSixStatus.text = "In progress"
            labelSixStatus.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        }
        if(padStatus.processO2 == 3) {
            buttonSixSend.setTitle("Resend", for: .normal)
            labelSixStatus.text = "Stopped"
            labelSixStatus.textColor = UIColor(red: 255/255, green: 0, blue: 0, alpha: 1)
        }
        //------------ Abort and cancel --------------------------
        labelAbortStatus.text = ""
        labelAbortCancelStatus.text = ""
        

    }
    
    func updatePressure() {
        
        // =====================================   Standard header
        if(padConfig.POXenabled == 1){
            labelSafetyLox.isHidden = false
            labelOxSafety.isHidden = false
        } else {
            labelSafetyLox.isHidden = true
            labelOxSafety.isHidden = true
        }
        if(padStatus.pressureOne == 99999) {
            labelSafetyLox.text = String("ERR")
        } else {
            labelSafetyLox.text = String(padStatus.pressureOne)
        }
        if(padStatus.pressureOne > padConfig.POXalarm || padStatus.pressureOne == 99999) {
            labelSafetyLox.textColor = .red
        } else {
            labelSafetyLox.textColor = .black
        }
        //-----
        if(padConfig.PFLenabled == 1){
            labelSafetyFuel.isHidden = false
            labelFuelSafety.isHidden = false
        } else {
            labelSafetyFuel.isHidden = true
            labelFuelSafety.isHidden = true
        }
        if(padStatus.pressureTwo == 99999) {
            labelSafetyFuel.text = String("ERR")
        } else {
            labelSafetyFuel.text = String(padStatus.pressureTwo)
        }
        if(padStatus.pressureTwo > padConfig.PFLalarm || padStatus.pressureTwo == 99999) {
            labelSafetyFuel.textColor = .red
        } else {
            labelSafetyFuel.textColor = .black
        }
        //------
        if(padConfig.PPSenabled == 1){
            labelSafetyHelium.isHidden = false
            labelPressureSafety.isHidden = false
        } else {
            labelSafetyHelium.isHidden = true
            labelPressureSafety.isHidden = true
        }
        if(padStatus.pressureThree == 99999) {
            labelSafetyHelium.text = String("ERR")
        } else {
            labelSafetyHelium.text = String(padStatus.pressureThree)
        }
        if(padStatus.pressureThree > padConfig.PPSalarm || padStatus.pressureThree == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        if(padConfig.PRSenabled == 1){
            labelSafetyPRS.isHidden = false
            labelSafetyPRSvalue.isHidden = false
        } else {
            labelSafetyPRS.isHidden = true
            labelSafetyPRSvalue.isHidden = true
        }
        if(padStatus.pressureFour == 99999) {
            labelSafetyPRSvalue.text = String("ERR")
        } else {
            labelSafetyPRSvalue.text = String(padStatus.pressureFour)
        }
        if(padStatus.pressureFour > padConfig.PRSalarm || padStatus.pressureFour == 99999) {
            labelSafetyHelium.textColor = .red
        } else {
            labelSafetyHelium.textColor = .black
        }
        //----
        
        //====== END HEADER
        
    }

    
    @IBAction func buttonErrorsAction(_ sender: Any) {
        tabBarController?.selectedIndex = 5
    }
    
    @IBAction func buttonArmAction(_ sender: Any) {
        if(switchArm.isOn) {
            if(padStatus.padHot){
              if(padStatus.padArmed) {
                working.radioMessage = "#ARM0,033,!"
                working.radioSend = true
                working.status = "Sent Disarm Request..."
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
              } else {
                working.radioMessage = "#ARM1,033,!"
                working.radioSend = true
                working.status = "Sent Arm Request..."
                working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
              }
            } else {
                notHot(); // pad is not hot
            }
            switchArm.isOn = false
        } else {
            denySend()
        }
    }
   
    /* send commands
    #PC1 - close all valves
    #PF1 -
    #PF2 -
    #PO1 -
    #PO2 -
    */
    
    //--------------- Reset / Recycle all processes --------------------
    
    @IBAction func buttonRestAction(_ sender: Any) {
        if(switchArm.isOn) {
            working.radioMessage = "#RSET,033,!"
            working.radioSend = true
            working.status = "Sending Reset/Recycle Request..."
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            switchArm.isOn = false
        } else {
            denySend()
        }
    }
    
    
    
    
    
    //--------------- C1 Close All Valves --------------------
    @IBAction func buttonOneAction(_ sender: Any) {
        if(switchOne.isOn) {
            working.radioMessage = "#PC1,33,!"
            working.radioSend = true
            working.status = "Sent Close Request..."
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            switchOne.isOn = false
            working.lastStep = "C1 Close All Valves"
        } else {
          denySend()
        }
    }
    
    //--------------- F1 Fuel Pressurize --------------------
    @IBAction func buttonTwoAction(_ sender: Any) {
        if(switchTwo.isOn) {
            if(padStatus.padArmed) {
                if(padStatus.padHot){
                    if(padStatus.processF1 == 2) { // it is a cancel not an initiate
                        working.radioMessage = "#PF1S,033,!"
                        working.radioSend = true
                        working.status = "Sent Fuel Cancel Request..."
                        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
                        working.lastStep = "F1 Fuel Cancel"
                    } else {
                      working.radioMessage = "#PF1,033,!"
                      working.radioSend = true
                      working.status = "Sent Fuel Pressurize Request..."
                      working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
                      working.lastStep = "F1 Fuel Pressurize"
                    }
                } else {
                    notHot();
                }
                } else {
                  denyArmed()
                }
              switchTwo.isOn = false
        } else {
          denySend()
        }
    }
    
    //--------------- F2 Fuel Disconnect --------------------
    @IBAction func buttonFourAction(_ sender: Any) {
        if(switchFour.isOn) {
          working.radioMessage = "#PF2,033,!"
          working.radioSend = true
          working.status = "Sent Fuel Disconnect Request..."
          working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
          switchFour.isOn = false
          working.lastStep = "F2 Fuel Disconnect"
        } else {
          denySend()
        }
    }
    
    //--------------- O1 Ox Pressurize --------------------
    @IBAction func buttonThreeAction(_ sender: Any) {
        if(switchThree.isOn) {
            if(padStatus.padArmed) {
                if(padStatus.padHot){
                    if(padStatus.processO1 == 2) { // it is a cancel not an initiate
                        working.radioMessage = "#PO1S,033,!"
                        working.radioSend = true
                        working.status = "Sent Ox Cancel Request..."
                        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
                        working.lastStep = "O1 Ox Cancel"
                    } else {
                      working.radioMessage = "#PO1,033,!"
                      working.radioSend = true
                      working.status = "Sent Ox Pressurize Request..."
                      working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
                      working.lastStep = "O1 Ox Pressurize"
                    }
                } else {
                    notHot()
                }
                
            } else {
              denyArmed()
            }
              switchThree.isOn = false
        } else {
          denySend()
        }
    }

    //--------------- O2 Ox Disconnect --------------------
    @IBAction func buttonSixAction(_ sender: Any) {
        if(switchSix.isOn) {
            working.radioMessage = "#PO2,033,!"
            working.radioSend = true
            working.status = "Sent Ox Disconnect Request..."
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            switchSix.isOn = false
            working.lastStep = "O2 Ox Disconnect"
        } else {
          denySend()
        }
    }
    

    //--------------- ABORT --------------------
    @IBAction func buttonAbortAction(_ sender: Any) {
        if(switchAbort.isOn) {
            working.radioMessage = "#ABORT,33,!"
            working.radioSend = true
            working.status = "Sent ABORT Request..."
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            switchAbort.isOn = false
            working.lastStep = "Abort"
        } else {
          denySend()
        }
    }
    
    @IBAction func buttonAbortCancelAction(_ sender: Any) {
        if(switchAbortCancel.isOn) {
            working.radioMessage = "#AC,33,!"
            working.radioSend = true
            working.status = "Sent ABORT Cancel Request..."
            working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
            switchAbortCancel.isOn = false
        } else {
          denySend()
        }
    }
    
    //-----------------------  FILL and SLIDER DATA ------------------------------
    
    @IBAction func sliderFuelAction(_ sender: Any) {
        textFuelpsi.text = String(Int(sliderFuel.value))
    }
    
    @IBAction func sliderLOXaction(_ sender: Any) {
        textLOXpsi.text = String(Int(sliderLOX.value))
        
    }
    
    @IBAction func buttonFuelSettingsAction(_ sender: Any) {
        sliderFuel.isHidden = false
        textFuelpsi.isHidden = false
        buttonFuelUpdate.isHidden = false
        buttonFuelSettings.isHidden = true
        labelFuelDetail.isHidden = true
        
    }
    @IBAction func buttonLOXSettingsAction(_ sender: Any) {
        
        sliderLOX.isHidden = false
        textLOXpsi.isHidden = false
        buttonLOXupdate.isHidden = false
        buttonLOXsettings.isHidden = true
        labelLOXdetail.isHidden = true
        
    }
    @IBAction func buttonFuelSendUpdateAction(_ sender: Any) {
       sendFill()
    }
    
    
    @IBAction func buttonLOXsendUpdateAction(_ sender: Any) {
        sendFill()
    }
    
    func sendFill() {
        
        var thes: String = ""
        working.radioMessage = "#SCFG,"
        
        thes = textLOXpsi.text ?? "0"
        thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
        if(Int(thes) ?? 0 < 0 || Int(thes) ?? 0 > padConfig.POXrange) {
            denyRange()
            return
        }
        working.radioMessage = working.radioMessage + thes + ","
        thes = textFuelpsi.text ?? "0"
        thes = thes.trimmingCharacters(in: .whitespacesAndNewlines)
        if(Int(thes) ?? 0 < 0 || Int(thes) ?? 0 > padConfig.PFLrange) {
            denyRange()
            return
        }
        working.radioMessage = working.radioMessage + thes + ",!"
        working.radioSend = true
        working.status = "Sent Fill Update Request..."
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
        
    }
    
    
    func denySend() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "You must unlock the safety before sending the request", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    func notHot() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "The pad controller is not hot. Insert Safety Plug.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    func denyRange() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "Values are out of range", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    @IBAction func buttonStatus(_ sender: Any) {
        
        working.radioMessage = "#S,033,!"
        working.radioSend = true
        working.status = "Sent Status Request..."
        working.statusTimeout = (Date() + TimeInterval(configuration.statusTimeout))
        
    }
    
    func denyArmed() { // popup alert
        
        let alert = UIAlertController(title: "Denied", message: "The pad must be ARMED before sending the request", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    
    
}


